package com.newgen.iforms.user;

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

public class DSR_DCB_IntroDone extends DSR_DCBCommon
{
	public String onIntroduceDone(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn="";
		DSR_DCB.mLogger.debug("This is DSR_DCB_IntroDone_Event");
		
		return strReturn;
	}
}