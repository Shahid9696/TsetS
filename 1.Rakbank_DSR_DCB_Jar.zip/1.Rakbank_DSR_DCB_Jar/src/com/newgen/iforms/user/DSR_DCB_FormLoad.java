package com.newgen.iforms.user;

import java.util.Calendar;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

public class DSR_DCB_FormLoad extends DSR_DCBCommon
{
	public String formLoadEvent(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn=""; 
	
		DSR_DCB.mLogger.debug("This is DSR_DCB_FormLoad_Event"+event+" controlName :"+controlName);
		
		//DSR_DCB.mLogger.debug("SELECT DECISION FROM USR_0_DSR_DCB_DECISION_MASTER WHERE WORKSTEP_NAME= '"+iform.getActivityName()"' and ISACTIVE='Y'");
		
                if (controlName.equalsIgnoreCase("BranchName") && event.equalsIgnoreCase("FormLoad") )
		{
			String actname = iform.getActivityName();
			//DSR_DCB.mLogger.debug(actname);
			List lstDecisions = iform.getDataFromDB("select BRANCHNAME,branchid from rb_branch_details");
			
			String value="";
			
			DSR_DCB.mLogger.debug(lstDecisions);
			
			 iform.clearCombo("BTD_OBC_BN");
			
			for(int i=0;i<lstDecisions.size();i++)
			 {
				List<String> arr1=(List)lstDecisions.get(i);
				value=arr1.get(0);
				iform.addItemInCombo("BTD_OBC_BN",value,value);
				strReturn="Brnach value loaded";
			 }		
		}
                
                return strReturn;
        }
}
