package com.newgen.iforms.user;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.newgen.iforms.api.IFormAPI;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.mvcbeans.model.wfobjects.WDGeneralData;


public class GSR_LCOLIntegration extends GSR_LCOLCommon {

	

	public String onclickevent(IFormReference iformObj,String control, String StringData) {
		// TODO Auto-generated method stub
			
			String MQ_response="";
			 String ReturnCode1="";
			 
		try
			{
			GSR_LCOL.mLogger.debug("Inside onclickevent function");
			
			 if(control.equals("AgreementNum"))
				{
					GSR_LCOL.mLogger.debug("inside AgreementNum call 3");
					
					MQ_response = MQ_connection_response(iformObj,control,StringData);
					GSR_LCOL.mLogger.debug("MQ_response"+MQ_response);
					MQ_response=MQ_response.substring(MQ_response.indexOf("<MQ_RESPONSE_XML"),MQ_response.indexOf("</MQ_RESPONSE_XML>"));
					GSR_LCOL.mLogger.debug("Inside AgreementNum function "+MQ_response);	
				/*	if(MQ_response.indexOf("<ReturnCode>")!=-1)
					{
						ReturnCode1 = MQ_response.substring(MQ_response.indexOf("<ReturnCode>")+"</ReturnCode>".length()-1,MQ_response.indexOf("</ReturnCode>"));
					}
					if(MQ_response.indexOf("<ReturnDesc>")!=-1)
					{
						String ReturnDesc = MQ_response.substring(MQ_response.indexOf("<ReturnDesc>")+"</ReturnDesc>".length()-1,MQ_response.indexOf("</ReturnDesc>"));
					} */ 
				String strCompCode	= MQ_response.substring(MQ_response.indexOf("<CompletionCode>")+16,MQ_response.indexOf("</CompletionCode>"));	
				String strReasonCode= MQ_response.substring(MQ_response.indexOf("<ReasonCode>")+12,MQ_response.indexOf("</ReasonCode>"));
				String activityName=iformObj.getActivityName();	
				iformObj.setValue("CompletionCode","Completion Code: 2");
				GSR_LCOL.mLogger.debug("CompletionCode"+strCompCode);
				iformObj.setValue("ReasonCode","Reason Code: 2509");
				GSR_LCOL.mLogger.debug("ReasonCode"+strReasonCode);
					GSR_LCOL.mLogger.debug("Return  AgreementNum  call"+ReturnCode1);
					if(!(strCompCode.equals("0")) || !(strReasonCode.equals("0")))
					{
						GSR_LCOL.mLogger.debug("Error_Code_Section");
						iformObj.setStyle("Error_Code_Section","visible","true");
						setFrameLoanError(activityName);
					}
					if((strCompCode.equals("0")) && (strReasonCode.equals("0")))
					{
						String strCustName = MQ_response.substring(MQ_response.indexOf("<APPLICANTNAME>")+15,MQ_response.indexOf("</APPLICANTNAME>"));
						iformObj.setValue("CUSTOMERNAME", strCustName);
						GSR_LCOL.mLogger.debug("CUSTOMERNAME"+strCustName);
						String strAppLoanAmt = MQ_response.substring(MQ_response.indexOf("<REQUESTEDLNAMT>")+16,MQ_response.indexOf("</REQUESTEDLNAMT>"));
						iformObj.setValue("APPLOANAMT", strAppLoanAmt);
						GSR_LCOL.mLogger.debug("strAppLoanAmt"+strAppLoanAmt);
						String strIntRate = MQ_response.substring(MQ_response.indexOf("<INTERESTRATE>")+14,MQ_response.indexOf("</INTERESTRATE>"));
						iformObj.setValue("INTERESTRATE", strIntRate);
						GSR_LCOL.mLogger.debug("strIntRate"+strIntRate);
						String strTenor = MQ_response.substring(MQ_response.indexOf("<TENOR>")+7,MQ_response.indexOf("</TENOR>"));
						iformObj.setValue("TENOR", strTenor);
						GSR_LCOL.mLogger.debug("strTenor"+strTenor);
						String strLoanMaturityDate = MQ_response.substring(MQ_response.indexOf("<LOANMATURITYDATE>")+18,MQ_response.indexOf("</LOANMATURITYDATE>"));
						iformObj.setValue("LOANMATURITYDATE", strLoanMaturityDate);
						GSR_LCOL.mLogger.debug("strLoanMaturityDate"+strLoanMaturityDate);
						String strFundingACNo = MQ_response.substring(MQ_response.indexOf("<FUNDINGACCOUNT>")+16,MQ_response.indexOf("</FUNDINGACCOUNT>"));
						iformObj.setValue("FUNDINGACNO", strFundingACNo);
						GSR_LCOL.mLogger.debug("strFundingACNo"+strFundingACNo);
						String strProductScheme = MQ_response.substring(MQ_response.indexOf("<SCHEMEDESC>")+12,MQ_response.indexOf("</SCHEMEDESC>"));
						iformObj.setValue("PRODUCTORSCHEME", strProductScheme);
						GSR_LCOL.mLogger.debug("strProductScheme"+strProductScheme);
						String strOutstandingLoanAmount = MQ_response.substring(MQ_response.indexOf("<UNMATUREDPRINCIPAL>")+20,MQ_response.indexOf("</UNMATUREDPRINCIPAL>"));
						iformObj.setValue("OUTSTANDINGLOANAMT", strOutstandingLoanAmount);
						GSR_LCOL.mLogger.debug("strOutstandingLoanAmount"+strOutstandingLoanAmount);
						String strNextInstAmount = MQ_response.substring(MQ_response.indexOf("<NEXTINSTLAMT>")+14,MQ_response.indexOf("</NEXTINSTLAMT>"));
						iformObj.setValue("NEXTINSTAMT", strNextInstAmount);
						GSR_LCOL.mLogger.debug("strNextInstAmount"+strNextInstAmount);
						String strNextInstallmentDate = MQ_response.substring(MQ_response.indexOf("<NEXTINSTLDATE>")+15,MQ_response.indexOf("</NEXTINSTLDATE>"));
						iformObj.setValue("NEXTINSTDATE", strNextInstallmentDate);
						GSR_LCOL.mLogger.debug("strNextInstallmentDate"+strNextInstallmentDate);
						String strRepaymentMode = MQ_response.substring(MQ_response.indexOf("<REPAYMENTMODE>")+15,MQ_response.indexOf("</REPAYMENTMODE>"));
						iformObj.setValue("MODEOFPAYMENT", strRepaymentMode);
						GSR_LCOL.mLogger.debug("strRepaymentMode"+strRepaymentMode);
						String strDelinquencyString = "";
//						strDelinquencyString = responseMsg.substring(responseMsg.indexOf("<DelinquencyString>")+19,responseMsg.indexOf("</DelinquencyString>"));
						String strNPAStage = "";
						//strNPAStage = responseMsg.substring(responseMsg.indexOf("<NPAStage>")+10,responseMsg.indexOf("</NPAStage>"));
						//strInstallmentPastDues = "";
						//strInstallmentPastDues = responseMsg.substring(responseMsg.indexOf("<InstallmentPastDues>")+21,responseMsg.indexOf("</InstallmentPastDues>"));
						String strChargesPastDues = "";
						//strChargesPastDues = responseMsg.substring(responseMsg.indexOf("<ChargesPastDues>")+17,responseMsg.indexOf("</ChargesPastDues>"));
						iformObj.setStyle("Loan_Details_Section","visible","true");
						iformObj.setStyle("Request_Details_Section","visible","true");
						iformObj.setStyle("Buttons_Section","visible","false");
						iformObj.setStyle("Print_Section","visible","false");
						
						String msg = "Loan Details Added successfully";
						
						
					}
						
					return MQ_response;
					//iformObj.addDataToGrid("Q_USR_0_GSR_LCOL_SHAREHOLDERDTLS", jsonArray1);
				}
			 
					
				
			}
			catch(Exception e)
			{
				GSR_LCOL.mLogger.debug("\nError in Integration Call");		
				}	
				return "";
			 
			 }
	
	
	public void setFrameLoanError(String ActivityName) 
	{
		IFormReference iformObj = null;
		if (ActivityName=="Work Introduction")
		{
			//IFormReference iformObj;
			iformObj.setStyle("Loan_Details_Section","visible","true");
			iformObj.setStyle("Request_Details_Section","visible","true");
		    iformObj.setStyle("Buttons_section","visible","true");
		    iformObj.setStyle("Print_Section","visible","true");
		}
		else if (ActivityName=="Branch_Approver")
		{
			iformObj.setStyle("Loan_Details_Section","visible","true");
			iformObj.setStyle("Request_Details_Section","visible","true");
			iformObj.setStyle("Branch_Approver_Section","visible","true");
		}
		else if (ActivityName=="Branch_Return")
		{
			iformObj.setStyle("Loan_Details_Section","visible","true");
			iformObj.setStyle("Request_Details_Section","visible","true");
			iformObj.setStyle("Branch_Approver_Section","visible","true");
		}
		else if (ActivityName=="CROPS")
		{
			iformObj.setStyle("Loan_Details_Section","visible","true");
			iformObj.setStyle("Request_Details_Section","visible","true");
			iformObj.setStyle("Crops_Section","visible","true");
		}
		// TODO Auto-generated method stub
		
	}


	public String MQ_connection_response(IFormReference iformObj,String control,String Data) 
	{
		
	GSR_LCOL.mLogger.debug("Inside MQ_connection_response function");
	final IFormReference iFormOBJECT;
	final WDGeneralData wdgeneralObj;	
	Socket socket = null;
	OutputStream out = null;
	InputStream socketInputStream = null;
	DataOutputStream dout = null;
	DataInputStream din = null;
	String mqOutputResponse = null;
	String mqOutputResponse_Entity = null;
	String mqOutputResponse_Account = null;
	String mqInputRequest = null;
	String cabinetName = getCabinetName();
	String wi_name = getWorkitemName();
	String ws_name = getActivityName();
	String sessionID = getSessionId();
	String userName = getUserName();
	String socketServerIP;
	int socketServerPort;
	wdgeneralObj = iformObj.getObjGeneralData();
	sessionID = wdgeneralObj.getM_strDMSSessionId();
	
	if (control.equals("AgreementNum")) {
			GSR_LCOL.mLogger.debug("WINAME : " + getWorkitemName() + ", WSNAME: " + getActivityName()
					+ ", Inside control--");
			String strAgrNo =  getControlValue("AGREEMENTNO");
			String sSessionId =  getControlValue("LoggedinAs");
			String strEqLoanACNo= getControlValue("EQUATIONLOANACCNO");
			if (strAgrNo.equals("") || strAgrNo==null)
			{
				strAgrNo =	strEqLoanACNo;
			}
			StringBuilder finalXml = new StringBuilder("<EE_EAI_MESSAGE>\n" + "<EE_EAI_HEADER>\n"
					+ "<MsgFormat>LOAN_DETAIL_INQUIRY</MsgFormat>\n" + "<MsgVersion>0001</MsgVersion>\n"
					+ "<RequestorChannelId>BPM</RequestorChannelId>\n" + "<RequestorUserId>"+sSessionId+"</RequestorUserId>\n"
					+ "<RequestorLanguage>E</RequestorLanguage>\n"
					+ "<RequestorSecurityInfo>secure</RequestorSecurityInfo>\n" + "<ReturnCode>911</ReturnCode>\n"
					+ "<ReturnDesc>Issuer Timed Out</ReturnDesc>\n" + "<MessageId>MDL053169111</MessageId>\n"
					+ "<Extra1>REQ||PERCOMER.PERCOMER</Extra1>\n" + "<Extra2>2007-01-01T10:30:30.000Z</Extra2>\n"
					+"</EE_EAI_HEADER>" +
					"<LoanDetailInquiry>" +
						"<APPLICATIONID>"+strAgrNo+"</APPLICATIONID>" +
					"</LoanDetailInquiry>" + "</EE_EAI_MESSAGE>");
			
			
			mqInputRequest = getMQInputXML(sessionID, cabinetName, wi_name, ws_name, userName, finalXml);
			GSR_LCOL.mLogger.debug("WINAME : " + getWorkitemName() + ", WSNAME: " + getActivityName()
					+ ", mqInputRequest for Signature Details call" + mqInputRequest);
		}
	
	
	
	try {
	
	GSR_LCOL.mLogger.debug("userName "+ userName);
	GSR_LCOL.mLogger.debug("sessionID "+ sessionID);
	
	String sMQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_BPM_MQ_TABLE with (nolock) where ProcessName = 'GSR_LCOL' and CallingSource = 'Form'";
	List<List<String>> outputMQXML = iformObj.getDataFromDB(sMQuery);
	//CreditCard.mLogger.info("$$outputgGridtXML "+ "sMQuery " + sMQuery);
	if (!outputMQXML.isEmpty()) {
		//CreditCard.mLogger.info("$$outputgGridtXML "+ outputMQXML.get(0).get(0) + "," + outputMQXML.get(0).get(1));
		socketServerIP = outputMQXML.get(0).get(0);
		GSR_LCOL.mLogger.debug("socketServerIP " + socketServerIP);
		socketServerPort = Integer.parseInt(outputMQXML.get(0).get(1));
		GSR_LCOL.mLogger.debug("socketServerPort " + socketServerPort);
		if (!("".equalsIgnoreCase(socketServerIP) && socketServerIP == null && socketServerPort==0)) {
			GSR_LCOL.mLogger.debug("Inside serverIP Port " + socketServerPort+ "-socketServerIP-"+socketServerIP);
			socket = new Socket(socketServerIP, socketServerPort);
			//new Code added by Deepak to set connection timeout
			int connection_timeout=60;
				try{
					connection_timeout=70;
					//connection_timeout = Integer.parseInt(NGFUserResourceMgr_CreditCard.getGlobalVar("Integration_Connection_Timeout"));
				}
				catch(Exception e){
					connection_timeout=60;
				}
				
			socket.setSoTimeout(connection_timeout*1000);
			out = socket.getOutputStream();
			socketInputStream = socket.getInputStream();
			dout = new DataOutputStream(out);
			din = new DataInputStream(socketInputStream);
			GSR_LCOL.mLogger.debug("dout " + dout);
			GSR_LCOL.mLogger.debug("din " + din);
			mqOutputResponse = "";
			
	
			if (mqInputRequest != null && mqInputRequest.length() > 0) {
				int outPut_len = mqInputRequest.getBytes("UTF-16LE").length;
				GSR_LCOL.mLogger.debug("Final XML output len: "+outPut_len + "");
				mqInputRequest = outPut_len + "##8##;" + mqInputRequest;
				GSR_LCOL.mLogger.debug("MqInputRequest"+"Input Request Bytes : "+ mqInputRequest.getBytes("UTF-16LE"));
				dout.write(mqInputRequest.getBytes("UTF-16LE"));dout.flush();
			}
			byte[] readBuffer = new byte[500];
			int num = din.read(readBuffer);
			if (num > 0) {
	
				byte[] arrayBytes = new byte[num];
				System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
				mqOutputResponse = mqOutputResponse+ new String(arrayBytes, "UTF-16LE");
				GSR_LCOL.mLogger.debug("mqOutputResponse/message ID :  "+mqOutputResponse);
				
				if(!"".equalsIgnoreCase(mqOutputResponse) && control.equalsIgnoreCase("AgreementNum")){
					mqOutputResponse = getOutWtthMessageID("LOAN_DETAIL_INQUIRY",iformObj,mqOutputResponse);
					GSR_LCOL.mLogger.debug("mqOutputResponse :  "+mqOutputResponse);
				}
				
									
				if(mqOutputResponse.contains("&lt;")){
					mqOutputResponse=mqOutputResponse.replaceAll("&lt;", "<");
					mqOutputResponse=mqOutputResponse.replaceAll("&gt;", ">");
				}
			}
			socket.close();
			
			return mqOutputResponse;
			
		} else {
			GSR_LCOL.mLogger.debug("SocketServerIp and SocketServerPort is not maintained "+"");
			GSR_LCOL.mLogger.debug("SocketServerIp is not maintained "+	socketServerIP);
			GSR_LCOL.mLogger.debug(" SocketServerPort is not maintained "+	socketServerPort);
			return "MQ details not maintained";
		}
	} else {
		GSR_LCOL.mLogger.debug("SOcket details are not maintained in NG_BPM_MQ_TABLE table"+"");
		return "MQ details not maintained";
	}
	
	} catch (Exception e) {
		GSR_LCOL.mLogger.debug("Exception Occured Mq_connection_CC"+e.getStackTrace());
	return "";
	}
	finally{
	try{
		if(out != null){
			
			out.close();
			out=null;
			}
		if(socketInputStream != null){
			
			socketInputStream.close();
			socketInputStream=null;
			}
		if(dout != null){
			
			dout.close();
			dout=null;
			}
		if(din != null){
			
			din.close();
			din=null;
			}
		if(socket != null){
			if(!socket.isClosed()){
				socket.close();
			}
			socket=null;
		}
	}catch(Exception e)
	{
		//		RLOS.mLogger.info("Exception occurred while closing socket");
		GSR_LCOL.mLogger.debug("Final Exception Occured Mq_connection_CC"+e.getStackTrace());
		//printException(e);
	}
	}
	

	}
	public static String getCharacterDataFromElement(org.w3c.dom.Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
		   CharacterData cd = (CharacterData) child;
		   return cd.getData();
		}
		return "NO_DATA";
	}
	/*public String getImages(String tempImagePath,String debt_acc_num,String[] imageArr,String[] remarksArr)
	{
		
		String strCode =null;
		StringBuilder html = new StringBuilder();
		if(imageArr==null)
			return "";
		for (int i=0;i<imageArr.length;i++)
		{
			try
			{	
				GSR_LCOL.mLogger.debug( "Inside Get Images 0");
				byte[] btDataFile = new sun.misc.BASE64Decoder().decodeBuffer(imageArr[i]);
				//File of = new File(filePath+debt_acc_num+"imageCreatedN"+i+".jpg");
				String imagePath = System.getProperty("user.dir")+ tempImagePath+System.getProperty("file.separator")+debt_acc_num+"imageCreatedN"+i+".jpg";
				GSR_LCOL.mLogger.debug( "imagePath"+imagePath);
				File of = new File(imagePath);
				
				FileOutputStream osf = new FileOutputStream(of);
				osf.write(btDataFile);
				osf.flush();
				osf.close();
			}
			catch (Exception e)
			{
				GSR_LCOL.mLogger.debug( e.getMessage());
				e.printStackTrace();
				GSR_LCOL.mLogger.debug( "Not able to get the image imageCreated"+e);
			}
		}
		return "";
	}*/
	private static String getMQInputXML(String sessionID, String cabinetName,
			String wi_name, String ws_name, String userName,
			StringBuilder final_xml) {
		//FormContext.getCurrentInstance().getFormConfig();
		GSR_LCOL.mLogger.debug("inside getMQInputXML function");
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("<APMQPUTGET_Input>");
		strBuff.append("<SessionId>" + sessionID + "</SessionId>");
		strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
		strBuff.append("<XMLHISTORY_TABLENAME>NG_GSR_LCOL_XMLLOG_HISTORY</XMLHISTORY_TABLENAME>");
		strBuff.append("<WI_NAME>" + wi_name + "</WI_NAME>");
		strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
		strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
		strBuff.append("<MQ_REQUEST_XML>");
		strBuff.append(final_xml);
		strBuff.append("</MQ_REQUEST_XML>");
		strBuff.append("</APMQPUTGET_Input>");
		GSR_LCOL.mLogger.debug("inside getOutputXMLValues"+ "getMQInputXML"+ strBuff.toString());
		return strBuff.toString();
	}
	public String getOutWtthMessageID(String callName,IFormReference iformObj,String message_ID){
		String outputxml="";
		try{
			//String wi_name = iformObj.getWFWorkitemName();
			String wi_name = getWorkitemName();
			String str_query = "select OUTPUT_XML from NG_GSR_LCOL_XMLLOG_HISTORY with (nolock) where CALLNAME ='"+callName+"' and MESSAGE_ID ='"+message_ID+"' and WI_NAME = '"+wi_name+"'";
			GSR_LCOL.mLogger.debug("inside getOutWtthMessageID str_query: "+ str_query);
			List<List<String>> result=iformObj.getDataFromDB(str_query);
			//below code added by nikhil 18/10 for Connection timeout
			//String Integration_timeOut=NGFUserResourceMgr_CreditCard.getGlobalVar("Inegration_Wait_Count");
			String Integration_timeOut="100";
			int Loop_wait_count=10;
			try
			{
				Loop_wait_count=Integer.parseInt(Integration_timeOut);
			}
			catch(Exception ex)
			{
				Loop_wait_count=10;
			}
		
			for(int Loop_count=0;Loop_count<Loop_wait_count;Loop_count++){
				if(result.size()>0){
					outputxml = result.get(0).get(0);
					break;
				}
				else{
					Thread.sleep(1000);
					result=iformObj.getDataFromDB(str_query);
				}
			}
			
			if("".equalsIgnoreCase(outputxml)){
				outputxml="Error";
			}
			GSR_LCOL.mLogger.debug("getOutWtthMessageID" + outputxml);				
		}
		catch(Exception e){
			GSR_LCOL.mLogger.debug("Exception occurred in getOutWtthMessageID" + e.getMessage());
			GSR_LCOL.mLogger.debug("Exception occurred in getOutWtthMessageID" + e.getStackTrace());
			outputxml="Error";
		}
		return outputxml;
	}
	
	public Document getDocument(String xml) throws ParserConfigurationException, SAXException, IOException
	{
		// Step 1: create a DocumentBuilderFactory
		DocumentBuilderFactory dbf =
				DocumentBuilderFactory.newInstance();

		// Step 2: create a DocumentBuilder
		DocumentBuilder db = dbf.newDocumentBuilder();

		// Step 3: parse the input file to get a Document object
		Document doc = db.parse(new InputSource(new StringReader(xml)));
		GSR_LCOL.mLogger.debug("xml is-"+xml);
		return doc;
	}
	String getStackTrace(final Throwable throwable) {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw, true);
        throwable.printStackTrace(pw);
        return sw.getBuffer().toString();
    }
}