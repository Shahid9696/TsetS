package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormReference;

public class GSR_LCOL_Click {

	public String clickEvent(IFormReference iform, String controlName, String data)
	{
		GSR_LCOL.mLogger.debug("inside GSR_LCOL_click");
		 if(controlName.equals("AgreementNum"))
             return new GSR_LCOLIntegration().onclickevent(iform, controlName, data);
		// else if(controlName.equals("PrintButton"))
            // return new GSR_LCOLIntegration().onclickevent(iform, controlName, data);
         else
        	 return "";		
	}
}
