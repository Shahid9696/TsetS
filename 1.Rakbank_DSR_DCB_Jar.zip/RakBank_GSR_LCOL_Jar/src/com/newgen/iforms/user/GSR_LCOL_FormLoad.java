package com.newgen.iforms.user;

import java.util.Calendar;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

public class GSR_LCOL_FormLoad extends GSR_LCOLCommon
{
	public String formLoadEvent(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn=""; 
	
		GSR_LCOL.mLogger.debug("This is GSR_LCOL_FormLoad_Event"+event+" controlName :"+controlName);
		
		//GSR_LCOL.mLogger.debug("SELECT DECISION FROM USR_0_GSR_LCOL_DECISION_MASTER WHERE WORKSTEP_NAME= '"+iform.getActivityName()"' and ISACTIVE='Y'");
				
		if (controlName.equalsIgnoreCase("BranchName") && event.equalsIgnoreCase("FormLoad") )
		{
			String actname = iform.getActivityName();
			//GSR_LCOL.mLogger.debug(actname);
			List lstDecisions = iform.getDataFromDB("select BRANCHNAME,branchid from rb_branch_details");
			
			String value="";
			//iform.clearCombo("branchIdValue");
			
			for(int i=0;i<lstDecisions.size();i++)
			 {
				List<String> arr1=(List)lstDecisions.get(i);
				value=arr1.get(0);
				GSR_LCOL.mLogger.debug("value branch name :"+value);
				//iform.addItemInCombo("branchIdValue",value,value);
				iform.setValue("branchIdValue",value);
				GSR_LCOL.mLogger.debug("@@branchIdValue :"+iform.getValue("branchIdValue"));
				//GSR_LCOL.mLogger.debug("@@value :"+iform.getValue("value"));
				
				//iform.addItemInCombo("oth_cr_BN",value,value);
				//iform.addItemInCombo("oth_cdr_BN",value,value);
				//iform.addItemInCombo("oth_ecr_bn",value,value);
				//strReturn="Branch Value Loaded" ;
			 }	
			
		}
		else if(controlName.equalsIgnoreCase("setFormDetail"))
		{
			GSR_LCOL.mLogger.debug("@@CCI_CName :"+iform.getValue("CCI_CName"));
			GSR_LCOL.mLogger.debug("@@REQUEST_TYPE :"+iform.getValue("REQUEST_TYPE"));
			if ((!iform.getValue("CCI_CName").equals("")) && (iform.getValue("REQUEST_TYPE").toString().equalsIgnoreCase("Setup Suppl. Card Limit")))
			{
				try
				{
					HashMap CAPDataHT = new HashMap();
					String str1 = iform.getValue("CardDetails").toString();
					GSR_LCOL.mLogger.debug("@@str1 :"+str1);
					if (!str1.equals(""))
					{
						CAPDataHT.clear();
						int i = 0;
						int j = 0;
						int k = str1.indexOf("!");
						int m = 0;
						String str2 = "";
						String str3 = "";
						String str4 = "";
						j = Integer.parseInt(str1.substring(0, str1.indexOf("@")));
						str1 = str1.substring(str1.indexOf("@") + 1, str1.length());
						for (m = 1; m <= j; m++)
						{
							if (m == 1)
							{
								i = -1;
								k = str1.indexOf("!");
							}
							else
							{
								i = k;
								k = str1.indexOf("!", i + 1);
							}
							str2 = str1.substring(i + 1, k);
							CAPDataHT.put("RAKBankCard" + m, str2);
							i = k;
							k = str1.indexOf("!", i + 1);
							str3 = str1.substring(i + 1, k);
							CAPDataHT.put("CardType" + m, str3);
							i = k;
							k = str1.indexOf("!", i + 1);
							str4 = str1.substring(i + 1, k);
							CAPDataHT.put("ExpDate" + m, str4);
						}

						String str5 = iform.getValue("OTH_SSC_SCNO").toString();

						iform.clearCombo("OTH_SSC_SCNO");

						for (m = 1; m <= j; m++)
						{
							iform.addItemInCombo("OTH_SSC_SCNO", "OTH_SSC_SCNO", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
						}
						if (!str5.equals(""))
							setControlValue("OTH_SSC_SCNO", str5.substring(0, 4) + "-" + str5.substring(4, 8) + "-" + str5.substring(8, 12) + "-" + str5.substring(12, 16));
						else
							setControlValue("OTH_SSC_SCNO", "");
					}
					lockCAPSFrm(iform);
				} 
				catch (Exception localException) 
				{
					GSR_LCOL.mLogger.debug("card exception at form load==" + localException);
				}
			}
		}
		
		/*else if("DuplicateWI".equals(controlName))
		{
			try {
				GSR_LCOL.mLogger.debug("Duplicate WIs");
				GSR_LCOL.mLogger.debug("WI Name duplicate is "+getWorkitemName());
				GSR_LCOL.mLogger.debug("CIF id is "+iform.getValue("CIF_ID"));
				String strQuery="SELECT WI_NAME,CREATED_TIME, CREATED_BY, SOL_ID  FROM RB_GSR_LCOL_EXTTABLE WHERE CIF_ID='"+iform.getValue("CIF_ID")+"' AND WI_NAME NOT IN ('"+getWorkitemName()+"')";
				List<List<String>> lstDuplicateWIs = iform.getDataFromDB(strQuery);
				
				GSR_LCOL.mLogger.debug("strQuery "+strQuery);
				JSONArray jsonArray=new JSONArray();
				String value="";
				GSR_LCOL.mLogger.debug("lstDuplicateWIs.size() "+lstDuplicateWIs.size());
				for(int i=0;i<lstDuplicateWIs.size();i++)
				{
					//PC.mLogger.debug(" "+memoPad);
					JSONObject obj=new JSONObject();
					List<String> arr=(List)lstDuplicateWIs.get(i);
					value=arr.get(0);
					GSR_LCOL.mLogger.debug("WI is "+value);
					obj.put("Work-Item Number", value);
					value=arr.get(1);
					//GSR_LCOL.mLogger.debug("Date format Sajan "+value);
					//Date date1= new SimpleDateFormat("EE dd/MMM/yyyy HH:mm:ss",Locale.ENGLISH).parse(value);
					Date date1= new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss").parse(value);
					GSR_LCOL.mLogger.debug("date1 "+date1);
					SimpleDateFormat sdf1=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
					GSR_LCOL.mLogger.debug("Initiated date is "+sdf1.format(date1).toString());
					
					value=sdf1.format(date1).toString();
					obj.put("Initiated Date", value);
					value=arr.get(2);
					GSR_LCOL.mLogger.debug("Initiated by is "+value);
					obj.put("Initiated By", value);
					value=arr.get(3);
					GSR_LCOL.mLogger.debug("Sol id is "+value);
					obj.put("Sol Id", value);
					jsonArray.add(obj);
				}
				GSR_LCOL.mLogger.debug("JSON array is "+jsonArray.toString());
				iform.addDataToGrid("Q_USR_0_GSR_LCOL_DUPLICATE_WI", jsonArray);
				strReturn=strReturn+lstDuplicateWIs.size();
			} catch (Exception e) {
				GSR_LCOL.mLogger.debug("Exception in Duplicate WorkItem" + e.getMessage());
			}
		}*/
		
		return strReturn;
	}
	
	public void lockCAPSFrm(IFormReference iform) 
	{
		iform.setStyle("CCI_CName","disable","false");
		iform.setStyle("CCI_ExpD","disable","false");
		iform.setStyle("CCI_ExpD","disable","false");
		iform.setStyle("CCI_CrdtCN","disable","false");
		iform.setStyle("CCI_CCRNNo","disable","false");
		iform.setStyle("CCI_MONO","disable","false");
		iform.setStyle("CCI_AccInc","disable","false");
		iform.setStyle("CCI_CT","disable","false");
		iform.setStyle("CCI_CAPS_GENSTAT","disable","false");
		iform.setStyle("CCI_ELITECUSTNO","disable","false");
	}
	
}
