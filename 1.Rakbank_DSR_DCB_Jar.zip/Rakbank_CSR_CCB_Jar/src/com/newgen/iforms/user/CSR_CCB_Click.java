package com.newgen.iforms.user;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.newgen.iforms.custom.IFormReference;

import netscape.javascript.JSObject;

public class CSR_CCB_Click extends CSR_CCBCommon{

	HashMap CAPDataHT = new HashMap();
	public String clickEvent(IFormReference iformObj, String controlName, String data) {
		
		String strReturn = "";
		try {
	
		CSR_CCB.mLogger.debug("inside CSR_CCB_click");
		if(controlName.equalsIgnoreCase("CAPSMAIN_Query"))
			{
				String str1 = "Select LTRIM(RTRIM(FirstName)), LTRIM(RTRIM(MiddleName)), LTRIM(RTRIM(LastName)), substring(format(EXPIRYDATE,'dd/mm/yy'),4,LEN(format(EXPIRYDATE,'dd/mm/yy'))), CRNNO, MOBILE,ASSESSEDINCOME,CARDTYPE,generalstat,elitecustomerno  from rak_bpm.dbo.CAPSMAIN where  CREDITCARDNO='" + iformObj.getValue("CardNo").toString().replaceAll("-", "") + "'";
				String str3 = "";
				String str4 = "";
				String str5 = "";
				String str6 = "";
				String str7 = "";
				String str8 = "";
				String str9 = "";
				String str10 = "";
				String str11 = "";
				String str12 = "";
				CSR_CCB.mLogger.debug("str1 :"+str1);
				List lstDecisions = iformObj.getDataFromDB(str1);
				CSR_CCB.mLogger.debug("lstDecisions :"+lstDecisions);
				if (lstDecisions != null)
				{
					for(int i=0;i<lstDecisions.size();i++)
					{
						CSR_CCB.mLogger.debug(" loop i :"+i);
						List<String> arr1=(List)lstDecisions.get(i);
						str3=arr1.get(0);
						str4=arr1.get(1);
						str5=arr1.get(2);
						str6=arr1.get(3);
						str7=arr1.get(4);
						str8=arr1.get(5);
						str9=arr1.get(6);
						str10=arr1.get(7);
						str11=arr1.get(8);
						str12=arr1.get(9);
					}

					setControlValue("CCI_CName", str3 + " " + str4 + " " + str5);
					setControlValue("CCI_ExpD", str6);
					setControlValue("CCI_ExpD", "Masked");
					setControlValue("CCI_CCRNNo", str7);
					setControlValue("CCI_MONO", str8);
					setControlValue("CCI_AccInc", str9);
					setControlValue("CCI_CT", str10);
					setControlValue("CCI_CAPS_GENSTAT", str11);
					setControlValue("CCI_ELITECUSTNO", str12);
					//setControlValue("CCI_ELITECUSTNO", str13);
					strReturn="Data Loaded";
					
					
				}				
			}
		else if (controlName.equalsIgnoreCase("PrintButton")) {
			

			CSR_CCB.mLogger.debug("inside Print_Button :");
				
			

			 Object localJSObject = "";
			 CSR_CCB.mLogger.debug("Print Button inside");
			 CSR_CCB.mLogger.debug("localJSObject ::"+localJSObject.toString());
			String str2 = "";
			String str3 = "";
			String str4 = "";
			str2 = ((String) iformObj.getValue("Cards_Remarks")).replace("&", "ampersand");
			str2 = str2.replace("=", "equalsopt");
			str2 = str2.replace("%", "percentageopt");
			str3 = ((String) iformObj.getValue("BA_Remarks")).replace("&", "ampersand");
			str3 = str3.replace("=", "equalsopt");
			str3 = str3.replace("%", "percentageopt");
                        str4 = ((String) iformObj.getValue("REMARKS")).replace("&", "ampersand");
			str4 = str4.replace("=", "equalsopt");
			str4 = str4.replace("%", "percentageopt");
			CSR_CCB.mLogger.debug("arrayOfString ::"+str2+ " "+ str3 + " "+str4);
			String[] arrayOfString = new String[1];
			 arrayOfString[0] = ("CCI_CrdtCN=" +
			 ((String)iformObj.getValue("CCI_CrdtCN")) + "&" + "CCI_CName="
			 + ((String)iformObj.getValue("CCI_CName")) + "&" + "CCI_ExpD="
			 + ((String)iformObj.getValue("CCI_ExpD")) + "&" + "CCI_CCRNNo="
			 + ((String)iformObj.getValue("CCI_CCRNNo")) + "&" + "CCI_ExtNo=" +
			 ((String)iformObj.getValue("CCI_ExtNo")) + "&" + "CCI_SC=" +
			 ((String)iformObj.getValue("CCI_SC")) + "&" + "CCI_MONO=" +
			 ((String)iformObj.getValue("CCI_MONO")) + "&" + "CCI_AccInc=" +
			 ((String)iformObj.getValue("CCI_AccInc")) + "&" + "CCI_CAPS_GENSTAT=" +
			 ((String)iformObj.getValue("CCI_CAPS_GENSTAT")) + "&" +
			 "CCI_ELITECUSTNO=" + ((String)iformObj.getValue("CCI_ELITECUSTNO")) + "&"
			 + "CCI_CT=" + ((String)iformObj.getValue("CCI_CT")) + "&" +
			 "VD_TINCheck=" + ((String)iformObj.getValue("VD_TINCheck")) + "&" +
			 "VD_MoMaidN=" + ((String)iformObj.getValue("VD_MoMaidN")) + "&" + "VD_DOB=" +
			 ((String)iformObj.getValue("VD_DOB")) + "&" + "VD_StaffId=" +
			 ((String)iformObj.getValue("VD_StaffId")) + "&" + "VD_PassNo=" +
			 ((String)iformObj.getValue("VD_PassNo")) + "&" + "VD_POBox=" +
			 ((String)iformObj.getValue("VD_POBox")) + "&" + "VD_Oth=" +
			 ((String)iformObj.getValue("VD_Oth")) + "&" + "VD_MRT=" +
			 ((String)iformObj.getValue("VD_MRT")) + "&" + "VD_EDC=" +
			 ((String)iformObj.getValue("VD_EDC")) + "&" + "VD_NOSC=" +
			 ((String)iformObj.getValue("VD_NOSC")) + "&" + "VD_TELNO=" +
			 ((String)iformObj.getValue("VD_TELNO")) + "&" + "VD_SD=" +
			 ((String)iformObj.getValue("VD_SD")) + "&" + "REASON_HOTLIST="+
                         ((String)iformObj.getValue("REASON_HOTLIST")) + "&" + "HOST_OTHER="+ 
			 ((String)iformObj.getValue("HOST_OTHER")) + "&" + "EMAIL_FROM="+
			 ((String)iformObj.getValue("EMAIL_FROM")) + "&" + "EMBOSING_NAME="+
			 ((String)iformObj.getValue("EMBOSING_NAME")) + "&" + "CB_DATETIME="+
			 ((String)iformObj.getValue("CB_DATETIME")) + "&" + "PLACE="+
			 ((String)iformObj.getValue("PLACE")) + "&" + "AVAILABLE_BALANCE="+
			 ((String)iformObj.getValue("AVAILABLE_BALANCE")) + "&" + "C_STATUS_B_BLOCK="+
			 ((String)iformObj.getValue("C_STATUS_B_BLOCK")) + "&" + "C_STATUS_A_BLOCK="+
			 ((String)iformObj.getValue("C_STATUS_A_BLOCK")) + "&" + "ACTION_TAKEN="+
			 ((String)iformObj.getValue("ACTION_TAKEN")) + "&" + "ACTION_OTHER="+
			 ((String)iformObj.getValue("ACTION_OTHER")) + "&" + "DELIVER_TO="+
			 ((String)iformObj.getValue("DELIVER_TO")) + "&" + "BRANCH="+
			 ((String)iformObj.getValue("BRANCH")) + "&" + "BRANCH_NAME="+
			 ((String)iformObj.getValue("BRANCH_NAME")) + "&" + "wi_name=" +
			 ((String)iformObj.getValue("wi_name")) + "&" + "processname=DSR_DCB" + "&"
			 + "IntroductionDateTime=" + (String)iformObj.getValue("IntroductionDateTime") + "&"  
			 + "BU_UserName=" + iformObj.getValue("IntroducedBy") + "&"
			 + "Cards_Decision=" + ((String)iformObj.getValue("Cards_Decision")) + "&" 
			 + "Cards_Remarks=" + str2 + "&" 
                         + "BA_Decision=" + ((String)iformObj.getValue("BA_Decision")) + "&"
			 + "BA_Remarks=" + str3 + "&" + "REMARKS=" + str4);
			 CSR_CCB.mLogger.debug("arrayOfString ::"+arrayOfString[0]);
			 localJSObject = arrayOfString[0];
			 CSR_CCB.mLogger.debug("localJSObject ::"+localJSObject.toString());
			// ((JSObject) localJSObject).call("callPrintJSPCSRBT", arrayOfString);
			 CSR_CCB.mLogger.debug("localJSObject ::"+localJSObject.toString());
			 strReturn = localJSObject.toString();
			 
			 
		
			 
			 
		}
	/*	else if (controlName.equalsIgnoreCase("VD_TINCheck")) 
		{
			String msg = "";
			if (iformObj.getValue("VD_TINCheck").toString().equals("true")) {
				DSR_DCB.mLogger.debug("VD_TINCheck ::");
				iformObj.setStyle("VD_MoMaidN", "disable", "false");
				iformObj.setStyle("VD_MoMaidN", "disable", "false");
				iformObj.setStyle("VD_POBox", "disable", "false");
				iformObj.setStyle("VD_TELNO", "disable", "false");
				iformObj.setStyle("VD_PassNo", "disable", "false");
				iformObj.setStyle("VD_MRT", "disable", "false");
				iformObj.setStyle("VD_Oth", "disable", "false");
				iformObj.setStyle("VD_SD", "disable", "false");
				iformObj.setStyle("VD_EDC", "disable", "false");
				iformObj.setStyle("VD_StaffId", "disable", "false");
				iformObj.setStyle("VD_DOB", "disable", "false");
				iformObj.setStyle("VD_NOSC", "disable", "false");
				msg= "tincheck is true.";
				
			}
			else if (iformObj.getValue("VD_TINCheck").toString().equals("false")) {
				//alert("inside VD_TINCheck");
				iformObj.setStyle("VD_MoMaidN", "disable", "true");
				iformObj.setStyle("VD_POBox", "disable", "true");
				iformObj.setStyle("VD_TELNO", "disable", "true");
				iformObj.setStyle("VD_PassNo", "disable", "true");
				iformObj.setStyle("VD_MRT", "disable", "true");
				iformObj.setStyle("VD_Oth", "disable", "true");
				iformObj.setStyle("VD_SD", "disable", "true");
				iformObj.setStyle("VD_EDC", "disable", "true");
				iformObj.setStyle("VD_StaffId", "disable", "true");
				iformObj.setStyle("VD_DOB", "disable", "true");
				iformObj.setStyle("VD_NOSC", "disable", "true");
				msg= "tincheck is false.";
			}
				
				
		} */
	
		
	
	}
		catch(Exception exc)
		{
			CSR_CCB.printException(exc);
			CSR_CCB.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception 2 - "+exc);
		}
		return strReturn;
	}

	public String validateCCNo(String paramString1) {

		String str = paramString1.replaceAll("-", "");
		int[] arrayOfInt = new int[str.length()];
		int i = 0;
		int j = 0;
		for (i = 0; i < str.length(); i++) {
			arrayOfInt[i] = Integer.parseInt(str.charAt(i) + "");
		}
		for (i = arrayOfInt.length - 2; i >= 0; i -= 2) {
			arrayOfInt[i] *= 2;
			if (arrayOfInt[i] > 9) {
				arrayOfInt[i] -= 9;
			}
		}
		for (i = 0; i < arrayOfInt.length; i++) {
			j += arrayOfInt[i];
		}

		if (j % 10 == 0) {
			return "ValidCard";
		}

		return "Invalid Debit Card No. Format";
	}
	
	public void setFormDetail(IFormReference iform) {
		//((Object) iform).setControlValue("","");
		 CSR_CCB.mLogger.debug("setFormDetail inside method=====");
	    if (!iform.getValue("DCI_CName").equals(""))
	      try
	      {
	        String str1 = (String) iform.getValue("cardDetails");
	        if (!str1.equals("")) {
	          CAPDataHT.clear();
	          int i = 0;
	          int j = 0;
	          int k = str1.indexOf("!");
	          int m = 0;
	          String str2 = "";
	          String str3 = "";
	          String str4 = "";
	          j = Integer.parseInt(str1.substring(0, str1.indexOf("@")));
	          str1 = str1.substring(str1.indexOf("@") + 1, str1.length());
	          for (m = 1; m <= j; m++)
	          {
	            if (m == 1)
	            {
	              i = -1;
	              k = str1.indexOf("!");
	            }
	            else
	            {
	              i = k;
	              k = str1.indexOf("!", i + 1);
	            }
	            CSR_CCB.mLogger.debug("saaa=======" + k);
	            str2 = str1.substring(i + 1, k);

	            CAPDataHT.put("RAKBankCard" + m, str2);
	            CSR_CCB.mLogger.debug("RAKBankCard" + m + "----" + str2);
	            i = k;
	            k = str1.indexOf("!", i + 1);
	            str3 = str1.substring(i + 1, k);
	            CAPDataHT.put("CardType" + m, str3);
	            CSR_CCB.mLogger.debug("CardType" + m + "-----" + str3);
	            i = k;
	            k = str1.indexOf("!", i + 1);
	            str4 = str1.substring(i + 1, k);
	            CAPDataHT.put("ExpDate" + m, str4);
	            CSR_CCB.mLogger.debug("ExpDate" + m + "---" + str4);
	          }

	          String str5 = (String) iform.getValue("BTD_RBC_RBCN1");
	          String str6 = (String) iform.getValue("BTD_RBC_RBCN2");
	          String str7 = (String) iform.getValue("BTD_RBC_RBCN3");
	          iform.clearCombo("BTD_RBC_RBCN1");
	          iform.clearCombo("BTD_RBC_RBCN2");
	          iform.clearCombo("BTD_RBC_RBCN3");
	          for (m = 1; m <= j; m++)
	          {
	        	 iform.addItemInCombo("BTD_RBC_RBCN1", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
	        	 iform.addItemInCombo("BTD_RBC_RBCN2", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
	        	 iform.addItemInCombo("BTD_RBC_RBCN3", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
	          }
	          if (!str5.equals(""))
	        	  iform.setValue("BTD_RBC_RBCN1", str5.substring(0, 4) + "-" + str5.substring(4, 8) + "-" + str5.substring(8, 12) + "-" + str5.substring(12, 16));
	          else
	        	  iform.setValue("BTD_RBC_RBCN1", "");
	          if (!str6.equals(""))
	        	  iform.setValue("BTD_RBC_RBCN2", str6.substring(0, 4) + "-" + str6.substring(4, 8) + "-" + str6.substring(8, 12) + "-" + str6.substring(12, 16));
	           else
	        	   iform.setValue("BTD_RBC_RBCN2", "");
	           if (!str7.equals(""))
	        	   iform.setValue("BTD_RBC_RBCN3", str7.substring(0, 4) + "-" + str7.substring(4, 8) + "-" + str7.substring(8, 12) + "-" + str7.substring(12, 16));
	           else
	        	   iform.setValue("BTD_RBC_RBCN3", "");
	           CSR_CCB.mLogger.debug("tetet443434etew==4545663-");
	         }
	 
	         //lockCAPSFrm();
	       } catch (Exception localException) {
	         CSR_CCB.mLogger.debug("card exception at form load==" + localException.toString());
	       }
	   }
}