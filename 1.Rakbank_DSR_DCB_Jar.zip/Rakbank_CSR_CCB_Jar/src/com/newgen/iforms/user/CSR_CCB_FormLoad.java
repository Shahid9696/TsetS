package com.newgen.iforms.user;

import java.util.Calendar;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

public class CSR_CCB_FormLoad extends CSR_CCBCommon
{
	public String formLoadEvent(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn=""; 
	
		CSR_CCB.mLogger.debug("This is DSR_DCB_FormLoad_Event"+event+" controlName :"+controlName);
		
		//DSR_DCB.mLogger.debug("SELECT DECISION FROM USR_0_DSR_DCB_DECISION_MASTER WHERE WORKSTEP_NAME= '"+iform.getActivityName()"' and ISACTIVE='Y'");
		
                if (controlName.equalsIgnoreCase("BranchName") && event.equalsIgnoreCase("FormLoad") )
		{
			String actname = iform.getActivityName();
			//DSR_DCB.mLogger.debug(actname);
			List lstDecisions = iform.getDataFromDB("select BRANCHNAME,branchid from rb_branch_details");
			
			String value="";
			
			CSR_CCB.mLogger.debug(lstDecisions);
			
			 iform.clearCombo("BTD_OBC_BN");
			
			for(int i=0;i<lstDecisions.size();i++)
			 {
				List<String> arr1=(List)lstDecisions.get(i);
				value=arr1.get(0);
				iform.addItemInCombo("BTD_OBC_BN",value,value);
				strReturn="Brnach value loaded";
			 }		
		}
                
                return strReturn;
        }
}
