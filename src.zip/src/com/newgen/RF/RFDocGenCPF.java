package com.newgen.RF;


import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonExecuteAPI;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.excp.NGException;

public class RFDocGenCPF extends RFMain {

	private static String cabinetName = "";
	private static String jtsIP = "";
	private static String jtsPort = "";
	final private static String ws_name = "Sys_Doc_Generate_CPF";
	Logger RFLogger;

	public RFDocGenCPF() throws NGException {

		RFLog.setLogger(getClass().getSimpleName());
		RFLogger = RFLog.getLogger(getClass().getSimpleName());
	}

	RFMain obj = new RFMain();

	protected void docGenCPF(String sessionID) {

		try {

			RFLog.setLogger(getClass().getSimpleName());
			String queueID = "";
			String apiResponse = "";
			String postURL = "";

			RFLogger.debug("Connecting to Cabinet.");

			cabinetName = CommonConnection.getCabinetName();
			RFLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			RFLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			RFLogger.debug("JTSPORT: " + jtsPort);

			queueID = RFMain.RFConfigParamMap.get("DocGenQueueID");
			RFLogger.debug("QueueID: " + queueID);

			postURL = RFMain.RFConfigParamMap.get("DocGenEndPoint");
			RFLogger.debug("Doc Upload URL: " + postURL);
			
			authURL = RFConfigParamMap.get("AuthURL");
			RFLogger.debug("KongAuthURL: " + authURL);
			
			authBody = RFConfigParamMap.get("AuthBody");
			RFLogger.debug("AuthBody: " + authBody);

			// sessionID = CommonConnection.getSessionID(RFLogger, false);

			if (sessionID.trim().equalsIgnoreCase("")) {
				RFLogger.debug("Could Not Connect to Server!");
				return;
			} else {
				RFLogger.debug("Session ID found: " + sessionID);
				sessionID = CommonConnection.getSessionID(RFLogger, false);
				RFLogger.debug("RF Doc Gen API to CPF ...123.");
				executeDocGenAPI(postURL, queueID, sessionID);
				RFLogger.debug("apiResponse : " + apiResponse);

			}
		} catch (Exception e) {
			RFLogger.error("Exception occured in docGenCPF: " + obj.customException(e));
		}

	}

	@SuppressWarnings("unchecked")
	private void executeDocGenAPI(String URL, String queueID, String sessionID) {

		try {
			// Fetch all Work-Items on given queueID.
			RFLogger.debug("Fetching all Workitems on awaitNotifyCPF queue");
			String fetchWorkitemListInputXML = CommonMethods.fetchWorkItemsInput(cabinetName, sessionID, queueID);
			RFLogger.debug("InputXML for fetchWorkList Call: " + fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML = CommonMethods.WFNGExecute(fetchWorkitemListInputXML, jtsIP, jtsPort, 1);

			RFLogger.debug("WMFetchWorkList DocGen CPF OutputXML: " + fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			RFLogger.debug("FetchWorkItemListMainCode: " + fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
			RFLogger.debug("RetrievedCount for WMFetchWorkList Call: " + fetchWorkitemListCount);

			RFLogger.debug("Number of workitems retrieved on DocGen CPF: " + fetchWorkitemListCount);

			System.out.println("Number of workitems retrieved on DocGen CPF: " + fetchWorkitemListCount);
			
			String authToken = CommonExecuteAPI.getAuthToken(RFLogger);
			RFLogger.debug("KongAuthToken: " + authToken);

			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0) {
				for (int i = 0; i < fetchWorkitemListCount; i++) {
					String fetchWorkItemlistData = xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData = fetchWorkItemlistData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

					RFLogger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: " + fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

					String processInstanceID = xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					RFLogger.debug("Current ProcessInstanceID: " + processInstanceID);

					RFLogger.debug("Processing Workitem: " + processInstanceID);
					System.out.println("\nProcessing Workitem: " + processInstanceID);

					String WorkItemID = xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					RFLogger.debug("Current WorkItemID: " + WorkItemID);

					String entryDateTime = xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					RFLogger.debug("Current EntryDateTime: " + entryDateTime);

					String ActivityName = xmlParserfetchWorkItemData.getValueOf("ActivityName");
					RFLogger.debug("ActivityName: " + ActivityName);

					String ActivityID = xmlParserfetchWorkItemData.getValueOf("WorkStageId");
					RFLogger.debug("ActivityID: " + ActivityID);
					String ActivityType = xmlParserfetchWorkItemData.getValueOf("ActivityType");
					RFLogger.debug("ActivityType: " + ActivityType);
					String ProcessDefId = xmlParserfetchWorkItemData.getValueOf("RouteId");
					RFLogger.debug("ProcessDefId: " + ProcessDefId);
					
					
					String DBQuery = "select e.ITEMINDEX,e.CIF_Num,e.Agreement_No,e.Sub_Product_Type,e.CPF_Missing_Docs,e.Product_Type,e.Cross_Sell_Product_Applicable,"
							+ "e.Cross_Sell_Product,e.ECRN_No,wf.VAR_STR3 as NotifyStage, e.Place_of_Issue, wf.var_str1 as ProductName from RB_PL_EXTTABLE e WITH(nolock) INNER JOIN WFINSTRUMENTTABLE wf WITH(nolock)"
							+ "on wf.ProcessInstanceID = e.WI_NAME where e.WI_NAME='"+processInstanceID+"' and workitemid = '"+WorkItemID+"'";
					String extTabDataIPXML = CommonMethods.apSelectWithColumnNames(DBQuery, cabinetName,sessionID);
					RFLogger.debug("extTabDataIPXML: " + extTabDataIPXML);
					String extTabDataOPXML = CommonMethods.WFNGExecute(extTabDataIPXML, jtsIP, jtsPort, 1);
					RFLogger.debug("extTabDataOPXML: " + extTabDataOPXML);

					XMLParser xmlParserData = new XMLParser(extTabDataOPXML);
					int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));				
					
					String userQuery = "select top 1 UserName,PersonalName from PDBUser WITH(nolock) where username IN (select User_Name from NG_RF_Decision_History WITH(nolock) where "
							+ "Workstep IN ('PB_Credit_Checker','Reschedulement_Credit') and winame ='"+processInstanceID+"' and (Decision ='Approve Subject to Clearance' OR  Decision = 'Approve'))";
					String userIPXML = CommonMethods.apSelectWithColumnNames(userQuery, cabinetName,sessionID);
					RFLogger.debug("userIPXML: " + userIPXML);
					String userOPXML = CommonMethods.WFNGExecute(userIPXML, jtsIP, jtsPort, 1);
					RFLogger.debug("userOPXML: " + userOPXML);

					XMLParser userXmlParser = new XMLParser(userOPXML);
					String creditOfficerID = "";
					String creditOfficerName = "";
					int totalRet = Integer.parseInt(userXmlParser.getValueOf("TotalRetrieved"));
					if (userXmlParser.getValueOf("MainCode").equalsIgnoreCase("0") && totalRet > 0) {
						creditOfficerID = userXmlParser.getValueOf("UserName").trim();
						creditOfficerName = userXmlParser.getValueOf("PersonalName").trim();
					}
					
					RFLogger.debug("creditOfficerID: " + creditOfficerID);
					RFLogger.debug("creditOfficerName: " + creditOfficerName);
					
					Gson gson = new GsonBuilder().setPrettyPrinting().create();
					JsonObject subReqBody = new JsonObject();
					String requestJSON = "";
					String responseJSON = "";
					String reqDateTime ="";
					String responseDateTime="";
					

					if (xmlParserData.getValueOf("MainCode").equalsIgnoreCase("0") && iTotalrec > 0) {

						// Making request JSON here
						String customerType = xmlParserData.getValueOf("Product_Type").trim();
						String crossSell = xmlParserData.getValueOf("Cross_Sell_Product_Applicable");
						String subProdType = xmlParserData.getValueOf("Sub_Product_Type");
						String crossSellProd = xmlParserData.getValueOf("Cross_Sell_Product").trim();
						String ecrn = xmlParserData.getValueOf("ECRN_No").trim();
						String prodName = xmlParserData.getValueOf("ProductName").trim();
						String notifyStage = xmlParserData.getValueOf("NotifyStage").trim();
						
						RFLogger.debug("Product Name from WFINSTRUMENT: " + prodName);

						subReqBody.addProperty("workItemId", processInstanceID);
						subReqBody.addProperty("cifId", xmlParserData.getValueOf("CIF_Num").trim());
						subReqBody.addProperty("accountId", xmlParserData.getValueOf("Account_No").trim());
						subReqBody.addProperty("agreementId", xmlParserData.getValueOf("Agreement_No").trim());
						subReqBody.addProperty("processName", "Retail Finance");
						subReqBody.addProperty("subProcessName", "RF_CPF");
						subReqBody.addProperty("productType", prodName);
						subReqBody.addProperty("subProductType", xmlParserData.getValueOf("Sub_Product_Type").trim());
						subReqBody.addProperty("folderIndex", xmlParserData.getValueOf("ITEMINDEX").trim());
						subReqBody.addProperty("creditOfficerId", creditOfficerID);
						subReqBody.addProperty("creditOfficerName", creditOfficerName);
						subReqBody.addProperty("custType", customerType.substring(0, 1));
						if (!"Reschedule Collections".equalsIgnoreCase(subProdType)) {
							if ("Yes".equalsIgnoreCase(crossSell) && !"AO".equalsIgnoreCase(crossSellProd)) {
								subReqBody.addProperty("crossSell", "Y");
								subReqBody.addProperty("crossSellAgreementId", ecrn);
							} else {
								subReqBody.addProperty("crossSell", "N");
							}
						}
						else {
							subReqBody.addProperty("crossSell", "N");
						}
						subReqBody.addProperty("placeOfIssue",xmlParserData.getValueOf("Place_of_Issue"));

						String cpfDocs = xmlParserData.getValueOf("CPF_Missing_Docs");
						RFLogger.debug("cpfDocsList: " + cpfDocs);
						try {
							if (cpfDocs.length() != 0) {
								String[] docArr = cpfDocs.split(",");
								RFLogger.debug("cpfDocsArr: " + Arrays.toString(docArr));
								JsonArray docs = new JsonArray();
								for (int j = 0; j < docArr.length; j++) {
									JsonObject docObj = new JsonObject();
									docObj.addProperty("type", docArr[j].trim());
									docs.add(docObj);
								}

								subReqBody.add("documents", docs);
								RFLogger.debug("Final Req JSON: " + gson.toJson(subReqBody));
								requestJSON = gson.toJson(subReqBody);
								
								reqDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
							}
						} catch (Exception e) {
							RFLogger.error("Exception occured in fetching CPF Missing docs: " + obj.customException(e));
						}
					}

					JsonObject response = null;
					int returnCode=0;
					try {
						responseJSON = CommonExecuteAPI.postOnboardAPI(URL, requestJSON, authToken, RFLogger);
						returnCode = CommonExecuteAPI.getRetCode();
						responseDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
						response = JsonParser.parseString(responseJSON).getAsJsonObject();
						if(returnCode>=500) {
							RFLogger.debug("Response from CPF Doc API: " + responseJSON);
							RFLogger.debug("ReturnCode from CPF Doc API: " + returnCode);	
						}
						else {
							JsonObject errRes = new JsonObject();
							errRes.addProperty("ErrCode", returnCode);
							errRes.addProperty("raw_response", responseJSON.toString());
						}
					} catch (Exception e) {
						RFLogger.error("Exception occured in POST CPF Onboard Docs API: " + obj.customException(e));
					}
					
					if(returnCode==201) {
						obj.DoneWI(processInstanceID, WorkItemID, "Success", "CPF Document Call Successfull", ActivityID, ActivityType,entryDateTime, ws_name, RFLogger);
					}
					else {
						JsonArray errorArr = response.getAsJsonArray("errors");
						String description = errorArr.get(0).getAsJsonObject().get("message").getAsString().replace("'", "''");
						RFLogger.debug("description: " + description);
						obj.DoneWI(processInstanceID, WorkItemID, "Failure", "Error "+description, ActivityID, ActivityType,entryDateTime, ws_name, RFLogger);
					}
					
					obj.insertIntoLogHistory(processInstanceID, ws_name, reqDateTime, "onboarding-documents", CommonExecuteAPI.uuid, requestJSON, responseJSON, responseDateTime, RFLogger);
					
				}
			}

		} catch (Exception e)

		{
			RFLogger.error("Exception occured in executeDocGenAPI method: " + obj.customException(e));
		}
	}

}
