package com.newgen.RF;

import com.newgen.common.CommonMethods;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.util.Arrays;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.JsonReader;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonExecuteAPI;
import com.newgen.omni.jts.cmgr.XMLParser;

import com.newgen.omni.wf.util.excp.NGException;

import ISPack.*;
import ISPack.ISUtil.*;
import Jdts.DataObject.JPDBString;

public class RFNotifyCPF extends RFMain {
	private static String cabinetName = "";
	private static String jtsIP = "";
	private static String jtsPort = "";
	final private static String ws_name = "Sys_Notify_CPF";
	private static String notifyStage="";
	private static String authToken="";
	private static String postURL = "";
	Logger RFLogger;
	RFMain obj = new RFMain();

	public RFNotifyCPF() throws NGException {

		RFLog.setLogger(getClass().getSimpleName());
		RFLogger = RFLog.getLogger(getClass().getSimpleName());
	}

	protected void notifyCPF(String sessionID) {

		try {

			String queueID = "";

			RFLogger.debug("Connecting to Cabinet.");

			cabinetName = CommonConnection.getCabinetName();
			RFLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			RFLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			RFLogger.debug("JTSPORT: " + jtsPort);

			queueID = RFMain.RFConfigParamMap.get("NotifyQueueID");
			RFLogger.debug("QueueID: " + queueID);

			postURL = RFMain.RFConfigParamMap.get("NotifyEndPoint");
			RFLogger.debug("Notify URL: " + postURL);

			if (sessionID.trim().equalsIgnoreCase("")) {
				RFLogger.debug("Could Not Connect to Server!");
				return;
			} else {
				RFLogger.debug("Session ID found: " + sessionID);
				sessionID = CommonConnection.getSessionID(RFLogger, false);
				RFLogger.debug("RF Notify to CPF ...123.");
				executeNotify(queueID, sessionID);
				//delayedNotify();

			}
		} catch (Exception e) {
			RFLogger.error("Exception occured in NotifyCPF: " + obj.customException(e));
		}

	}

	private void executeNotify(String queueID, String sessionID) {

		try {

			// Fetch all Work-Items on given queueID.
			RFLogger.debug("Fetching all Workitems on awaitNotifyCPF queue");
			// System.out.println("Fetching all Workitems on Notify CPF queue");
			String fetchWorkitemListInputXML = CommonMethods.fetchWorkItemsInput(cabinetName, sessionID, queueID);
			RFLogger.debug("InputXML for fetchWorkList Call: " + fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML = CommonMethods.WFNGExecute(fetchWorkitemListInputXML, jtsIP, jtsPort, 1);

			RFLogger.debug("WMFetchWorkList Notify CPF OutputXML: " + fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			RFLogger.debug("FetchWorkItemListMainCode: " + fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
			RFLogger.debug("RetrievedCount for WMFetchWorkList Call: " + fetchWorkitemListCount);

			RFLogger.debug("Number of workitems retrieved on Notify CPF: " + fetchWorkitemListCount);

			System.out.println("Number of workitems retrieved on Notify CPF: " + fetchWorkitemListCount);
			
			String kongToken = CommonExecuteAPI.getAuthToken(RFLogger);
			RFLogger.debug("KongAuthToken: " + kongToken);
			authToken = kongToken;

			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0) {
				for (int i = 0; i < fetchWorkitemListCount; i++) {
					String fetchWorkItemlistData = xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData = fetchWorkItemlistData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

					RFLogger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: " + fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

					String processInstanceID = xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					RFLogger.debug("Current ProcessInstanceID: " + processInstanceID);

					RFLogger.debug("Processing Workitem: " + processInstanceID);
					System.out.println("\nProcessing Workitem: " + processInstanceID);

					String WorkItemID = xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					RFLogger.debug("Current WorkItemID: " + WorkItemID);

					String entryDateTime = xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					RFLogger.debug("Current EntryDateTime: " + entryDateTime);

					String ActivityName = xmlParserfetchWorkItemData.getValueOf("ActivityName");
					RFLogger.debug("ActivityName: " + ActivityName);

					String ActivityID = xmlParserfetchWorkItemData.getValueOf("WorkStageId");
					RFLogger.debug("ActivityID: " + ActivityID);
					String ActivityType = xmlParserfetchWorkItemData.getValueOf("ActivityType");
					RFLogger.debug("ActivityType: " + ActivityType);
					String ProcessDefId = xmlParserfetchWorkItemData.getValueOf("RouteId");
					RFLogger.debug("ProcessDefId: " + ProcessDefId);

					String getDataRes = getNotifyData(processInstanceID, WorkItemID);
					RFLogger.debug("getNotify Request Body: "+getDataRes);
					
					String requestJSON = "";
					String responseJSON = "";
					String reqDateTime = "";
					String responseDateTime = "";
					
					if(!"Error".equalsIgnoreCase(getDataRes)) {
						try {
							requestJSON = getDataRes;
							reqDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
							responseJSON = CommonExecuteAPI.postOnboardAPI(postURL, requestJSON, authToken, RFLogger);
							RFLogger.debug("CPF Notify Response: "+responseJSON);
							JsonObject response = JsonParser.parseString(responseJSON).getAsJsonObject();
							responseDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
							int returnCode = CommonExecuteAPI.getRetCode();
							RFLogger.debug("ReturnCode from CPF Notify API: " + returnCode);
							if(returnCode==202) {
								obj.DoneWI(processInstanceID, WorkItemID, "Success", "CPF Notify Call Successfull", ActivityID, ActivityType,entryDateTime, ws_name, RFLogger);
							}
							else {
								JsonArray errorArr = response.getAsJsonArray("errors");
								String description = errorArr.get(0).getAsJsonObject().get("message").getAsString().replace("'", "''");
								RFLogger.debug("description: " + description);
								obj.DoneWI(processInstanceID, WorkItemID, "Failure", "Error: "+description, ActivityID, ActivityType,entryDateTime, ws_name, RFLogger);
							}

							obj.insertIntoLogHistory(processInstanceID, ws_name, reqDateTime, "onboard-notification", CommonExecuteAPI.uuid, requestJSON, responseJSON, responseDateTime, RFLogger);
						} catch (Exception e) {
							RFLogger.error("Exception occured in processing WI: " + obj.customException(e));
						}
					}
				}
			}

		} catch (Exception e)

		{
			RFLogger.error("Exception occured in executeNotify method: " + obj.customException(e));
		}
	}

	private String getNotifyData(String processInstanceID, String WorkItemID) throws IOException, Exception {
		String DBQuery = "select top 1 CIF_Num,Customer_Name,EmailID,Mobile_Num,DOB,w.var_Str3 as NotifyStage,"
				+ "Cross_Sell_Product_Applicable,Cross_Sell_Product,Product_Type,Account_No,Agreement_No,"
				+ "Sub_Product_Type,Loan_Amt,Credit_Card_Lt,Application_Date,CPF_Missing_Docs,Cooling_Period,"
				+ "w.var_str1 as ProductName,e.Application_Date from RB_PL_EXTTABLE e "
				+ "with(nolock) JOIN WFINSTRUMENTTABLE w with(nolock) ON e.WI_NAME=w.ProcessInstanceID "
				+ "where e.WI_NAME='" + processInstanceID + "' and w.workitemid='"+WorkItemID+"'";
		String extTabDataIPXML = CommonMethods.apSelectWithColumnNames(DBQuery, cabinetName,
				CommonConnection.getSessionID(RFLogger, false));
		RFLogger.debug("extTabDataIPXML: " + extTabDataIPXML);
		String extTabDataOPXML = CommonMethods.WFNGExecute(extTabDataIPXML, jtsIP, jtsPort, 1);
		RFLogger.debug("extTabDataOPXML: " + extTabDataOPXML);
		
		XMLParser xmlParserData = new XMLParser(extTabDataOPXML);
		JsonObject subReqBody = new JsonObject();
		String notifyStageFromWI = "";
		int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));

		notifyStageFromWI = xmlParserData.getValueOf("NotifyStage");
		if (xmlParserData.getValueOf("MainCode").equalsIgnoreCase("0") && iTotalrec > 0) {
			if(!"Delayed".equalsIgnoreCase(notifyStageFromWI) && (!"".equalsIgnoreCase(notifyStageFromWI) || notifyStageFromWI.length()!=0)) {
				notifyStage = notifyStageFromWI;
			}
			
			RFLogger.debug("Notify Stage: " + notifyStage);
			String crossSellProd = xmlParserData.getValueOf("Cross_Sell_Product");
			String subProdType = xmlParserData.getValueOf("Sub_Product_Type");
			String crossSell = xmlParserData.getValueOf("Cross_Sell_Product_Applicable");
			String custType = xmlParserData.getValueOf("Product_Type");
			String prodType = xmlParserData.getValueOf("ProductName").trim();
			String coolingPeriod = xmlParserData.getValueOf("Cooling_Period");
			if(coolingPeriod.length()==0) {
				coolingPeriod = "No";
			}
//			String prodType = "";
//			
			subReqBody.addProperty("workItemId",processInstanceID);
			subReqBody.addProperty("cifId",xmlParserData.getValueOf("CIF_Num"));
			subReqBody.addProperty("customerName",xmlParserData.getValueOf("Customer_Name"));
			subReqBody.addProperty("mailId",xmlParserData.getValueOf("EmailID"));
			subReqBody.addProperty("mobileNo",xmlParserData.getValueOf("Mobile_Num"));
			subReqBody.addProperty("dateOfBirth",xmlParserData.getValueOf("DOB").substring(0, 10));
			subReqBody.addProperty("stage",notifyStage);
			subReqBody.addProperty("segment","PBG");
//			if ("Yes".equalsIgnoreCase(crossSell) && !"AO".equalsIgnoreCase(crossSellProd)) {
//				subReqBody.addProperty("crossSell", "Y");
//			} else {
//				subReqBody.addProperty("crossSell", "N");
//			}
			subReqBody.addProperty("custType",custType.substring(0, 1));
			if("Approval".equalsIgnoreCase(notifyStage)) {
				subReqBody.addProperty("coolingOffWaived",coolingPeriod.substring(0, 1));
				subReqBody.addProperty("consentRequired","Y");
			}
			else {
				subReqBody.addProperty("consentRequired","N");
			}
			subReqBody.addProperty("accountId",xmlParserData.getValueOf("Account_No"));
			subReqBody.addProperty("agreementId",xmlParserData.getValueOf("Agreement_No"));
			subReqBody.addProperty("processName","Retail Finance");
			subReqBody.addProperty("subProcessName","RF_CPF");
			subReqBody.addProperty("productType",prodType);
			subReqBody.addProperty("subProductType",subProdType);
			if ("Yes".equalsIgnoreCase(crossSell) && !"AO".equalsIgnoreCase(crossSellProd)) {
				subReqBody.addProperty("crossSellProductType", "Credit Card");
				subReqBody.addProperty("crossSell", "Y");
			} else {
				subReqBody.addProperty("crossSell", "N");
			}
			subReqBody.addProperty("amount",xmlParserData.getValueOf("Loan_Amt"));
			subReqBody.addProperty("creditLimit",xmlParserData.getValueOf("Credit_Card_Lt"));
			if("Disbursal".equalsIgnoreCase(notifyStage)) {
				subReqBody.addProperty("disbursalDate","2025-08-06");
			}
			subReqBody.addProperty("approvalDate","2025-08-06");
			subReqBody.addProperty("creditApprovalDate","2025-08-05");
			subReqBody.addProperty("submissionDate",xmlParserData.getValueOf("Application_Date").substring(0, 10));
			
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			if("Approval".equalsIgnoreCase(notifyStage) || "Disbursal".equalsIgnoreCase(notifyStage)) {
				String notifyDocs="";
				if("No".equalsIgnoreCase(crossSell) || "AO".equalsIgnoreCase(crossSellProd)) {
					notifyDocs = RFMain.RFConfigParamMap.get(notifyStage+"Docs");	
				}
				if("Yes".equalsIgnoreCase(crossSell) && !"AO".equalsIgnoreCase(crossSellProd)){
					notifyDocs = RFMain.RFConfigParamMap.get("CC"+notifyStage+"Docs");
				}
				if("Reschedule Collections".equalsIgnoreCase(subProdType)) {
					notifyDocs = RFMain.RFConfigParamMap.get("RC"+notifyStage+"Docs");
				}
				RFLogger.debug("NotifyDoc List: " + notifyDocs);
			
			
				String folderIndex = "";
				folderIndex = RFMain.RFConfigParamMap.get(custType+"DocIndex");
				RFLogger.debug("folderIndex for "+custType+": " + folderIndex);
				//Fetch docs index and name//				
				JsonArray docs = null;
				try {
					String docQuery="select Name as documentType,DocumentIndex as documentIndex from PDBDocument "
							+ "with(nolock) where DocumentIndex in (select DocumentIndex from PDBDocumentContent "
							+ "with(nolock) where ParentFolderIndex = (select FolderIndex From PDBFolder with(nolock) "
							+ "where Name='"+processInstanceID+"')) and Name in "+notifyDocs + " UNION ALL"
							+ " select Name as documentType,DocumentIndex as documentIndex from PDBDocument with(nolock) where DocumentIndex in "
							+ "(select DocumentIndex from PDBDocumentContent with(nolock) where ParentFolderIndex = "+folderIndex+")";
					String docIndexIPXML = CommonMethods.apSelectWithColumnNames(docQuery, cabinetName,
							CommonConnection.getSessionID(RFLogger, false));
					RFLogger.debug("docIndexIPXML: " + docIndexIPXML);
					String docIndexOPXML = CommonMethods.WFNGExecute(docIndexIPXML, jtsIP, jtsPort, 1);
					RFLogger.debug("docIndexOPXML: " + docIndexOPXML);

					XMLParser xmlParserDoc = new XMLParser(docIndexOPXML);

					int docTotalRet = Integer.parseInt(xmlParserDoc.getValueOf("TotalRetrieved"));
					if(xmlParserDoc.getValueOf("MainCode").equalsIgnoreCase("0") && docTotalRet > 0) {
						docs = getRecordsJsonArray(docIndexOPXML);
						subReqBody.add("documents", docs);
						RFLogger.debug("Final Req JSON: " + gson.toJson(subReqBody));
						return gson.toJson(subReqBody);
					}
				} catch (Exception e) {
					RFLogger.error("Exception occured in getting docs for Notify: " + obj.customException(e));
					return "Error";
				}
			}
			return gson.toJson(subReqBody);
		}
		return "Error";
	}
	
	private String delayedNotify() {
		//Calculate TAT here from introDateTime till WI has not reached Disbursal Checker
		//If TAT hits 10 days delayed comms are sent.
		try {
			String TAT_Query = "SELECT w.ProcessInstanceID FROM WFINSTRUMENTTABLE w WITH (NOLOCK) INNER JOIN RB_PL_EXTTABLE e ON w.ProcessInstanceID = e.WI_NAME "
					+ "WHERE w.ProcessName = 'RF' AND w.WorkItemId = 1 AND (DATEDIFF(DAY, w.IntroductionDATETIME, GETDATE()) "
					+ "- (DATEDIFF(WEEK, w.IntroductionDATETIME, GETDATE()) * 2) "
					+ "- CASE WHEN DATENAME(WEEKDAY, w.IntroductionDATETIME) = 'Saturday' THEN 1 ELSE 0  END "
					+ "- CASE WHEN DATENAME(WEEKDAY, GETDATE()) = 'Sunday' THEN 1 ELSE 0 END) > 1 "
					+ "and w.IntroductionDATETIME is not null and w.ProcessInstanceID NOT IN "
					+ "(select WINAME from NG_RF_Decision_History with(nolock) where Workstep='Disbursal_Checker') and "
					+ "(e.DelayedNotifySent = '' OR e.DelayedNotifySent is null OR e.DelayedNotifySent = 'N')";
			
			String tatIPXML = CommonMethods.apSelectWithColumnNames(TAT_Query, cabinetName,CommonConnection.getSessionID(RFLogger, false));
			RFLogger.debug("extTabDataIPXML: " + tatIPXML);
			String tatOPXML = CommonMethods.WFNGExecute(tatIPXML, jtsIP, jtsPort, 1);
			RFLogger.debug("extTabDataOPXML: " + tatOPXML);

			XMLParser xmlParserData = new XMLParser(tatOPXML);
			int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));

			if (xmlParserData.getValueOf("MainCode").equalsIgnoreCase("0") && iTotalrec > 0) {
				String[] wiNames;
				String reqDateTime = "";
				String responseJSON = "";
				String responseDateTime = "";
				String remarks = "";
				String decision = "";
				wiNames = CommonMethods.extractRecordValues(tatOPXML);
				RFLogger.debug("List of WIs: " + Arrays.toString(wiNames));
				for(String wiName: wiNames) {
					String delayedPayload = "";
					setNotifyStage("Delayed");
					System.out.println("\nProcessing Workitem for Delayed Notify: " + wiName);
					RFLogger.debug("Notify Stage: " + notifyStage);
					try {
						delayedPayload = getNotifyData(wiName,"1");
					} catch (Exception e) {
						RFLogger.error("Exception occured in creating delayed JSON payload: " + obj.customException(e));
					}
					RFLogger.debug("Final Delayed Payload: " + delayedPayload);
					
					try {
						reqDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
						responseJSON = CommonExecuteAPI.postOnboardAPI(postURL, delayedPayload, authToken, RFLogger);
						RFLogger.debug("CPF Notify Response: "+responseJSON);
						JsonObject response = null;
						try {
							response = JsonParser.parseString(responseJSON).getAsJsonObject();
						} catch (JsonSyntaxException e) {
							e.printStackTrace();
						}
						responseDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
						int returnCode = CommonExecuteAPI.getRetCode();
						RFLogger.debug("ReturnCode from CPF Notify API: " + returnCode);
						if(returnCode==202) {
							decision = "Delayed Notify Sent";
							insertIntoDecHistory(responseDateTime, remarks, decision, wiName);
						}
						else {
							decision = "Delayed Notify Failed";
							JsonArray errorArr = response.getAsJsonArray("errors");
							String description = errorArr.get(0).getAsJsonObject().get("message").getAsString().replace("'", "''");
							RFLogger.debug("description: " + description);
							insertIntoDecHistory(responseDateTime, "Error "+description, decision, wiName);
						}

						obj.insertIntoLogHistory(wiName, ws_name, reqDateTime, "onboard-notification", CommonExecuteAPI.uuid, delayedPayload, responseJSON, responseDateTime, RFLogger);
						
					} catch (Exception e) {
						RFLogger.error("Exception occured in processing WI: " + obj.customException(e));
					}
					
					String sentFlag = "'N'";
					if(decision.contains("Failed")) {
						sentFlag = "'N'";
					}
					else {
						sentFlag = "'Y'";
					}
					String updateIPXML = CommonMethods.apUpdateInput(cabinetName, sessionID, "RB_PL_EXTTABLE", "DelayedNotifySent", sentFlag, "WI_NAME = '"+wiName+"'");
					RFLogger.debug("extTabDataIPXML: " + updateIPXML);
					String updateOPXML = CommonMethods.WFNGExecute(updateIPXML, jtsIP, jtsPort, 1);
					RFLogger.debug("extTabDataOPXML: " + updateOPXML);
					XMLParser xParserUpdate = new XMLParser(updateOPXML);
					int rows = Integer.parseInt(xParserUpdate.getValueOf("Output"));
					if(rows==1) {
						RFLogger.debug("Updated DB Flag: ");
					}
				}
			}
			
			
		} catch (IOException e) {
			RFLogger.error("Exception occured in delayedNotify method: " + obj.customException(e));
		} catch (Exception e) {
			RFLogger.error("Exception occured in delayedNotify method: " + obj.customException(e));
		}
		return "";
	}
	
	private String getStaticDocs() {

		return "";
	}

	protected void insertIntoDecHistory(String responseDateTime, String remarks, String decision, String wiName)
			throws IOException, Exception {
		String columnNames = "WINAME,Date_Time,WORKSTEP,USER_NAME,DECISION,REMARKS";
		String columnValues = "'" + wiName + "','" + responseDateTime + "','" + ws_name
				+ "','" + CommonConnection.getUsername() + "','" + decision + "','"
				+ remarks + "'";

		String apInsertInputXML = CommonMethods.apInsert(cabinetName,CommonConnection.getSessionID(RFLogger, false), 
				columnNames, columnValues,"NG_RF_Decision_History");
		RFLogger.debug("APInsertInputXML: " + apInsertInputXML);

		String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
		RFLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

		XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
		String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
		RFLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
	}
	
	
	public static JsonArray getRecordsJsonArray(String xmlString) {
		JsonArray jsonArray = new JsonArray();
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			ByteArrayInputStream input = new ByteArrayInputStream(xmlString.getBytes("UTF-8"));
			Document doc = builder.parse(input);
			doc.getDocumentElement().normalize();
			NodeList recordNodes = doc.getElementsByTagName("Record");
			for (int i = 0; i < recordNodes.getLength(); i++) {
				Element recordElement = (Element) recordNodes.item(i);
				JsonObject jsonObject = new JsonObject();
				NodeList childNodes = recordElement.getChildNodes();
				for (int j = 0; j < childNodes.getLength(); j++) {
					Node child = childNodes.item(j);
					if (child.getNodeType() == Node.ELEMENT_NODE) {
						String key = child.getNodeName();
						String value = child.getTextContent().trim();
						jsonObject.addProperty(key, value);
					}
				}
				jsonArray.add(jsonObject);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonArray;
	}

	protected static void setNotifyStage(String notifyStage) {
		RFNotifyCPF.notifyStage = notifyStage;
	}
	
}
