package com.newgen.RF;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonExecuteAPI;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;

public class RFMain implements Runnable {

	public static Map<String, String> RFConfigParamMap = new HashMap<String, String>();
	static String sessionID = "";
	static String cabinetName = "";
	static String jtsIP = "";
	static String jtsPort = "";
	int sleepIntervalInMin = 0;
	static String authURL = "";
	static String authBody = "";
	private static NGEjbClient ngEjbClientConnection;
	private static org.apache.log4j.Logger RFLogger;

	static {
		try {
			ngEjbClientConnection = NGEjbClient.getSharedInstance();
		} catch (NGException e) {
			e.printStackTrace();
		}
	}
	public RFMain() throws NGException {
		RFLog.setLogger(getClass().getSimpleName());
		RFLogger = RFLog.getLogger(getClass().getSimpleName());
	}
	@Override
	public void run() {

		try {
			RFLog.setLogger(getClass().getSimpleName());
			int configReadStatus = readConfig();
			RFLogger.debug("configReadStatus " + configReadStatus);
			if (configReadStatus != 0) {
				RFLogger.error("Could not Read Config Properties [RF]");
				// return;
			}

			cabinetName = CommonConnection.getCabinetName();
			RFLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			RFLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			RFLogger.debug("JTSPORT: " + jtsPort);

			sleepIntervalInMin = Integer.parseInt(RFConfigParamMap.get("SleepIntervalInMin"));
			RFLogger.debug("SleepIntervalInMin: " + sleepIntervalInMin);
			
			authURL = RFConfigParamMap.get("AuthURL");
			RFLogger.debug("KongAuthURL: " + authURL);
			
			authBody = RFConfigParamMap.get("AuthBody");
			RFLogger.debug("AuthBody: " + authBody);

			sessionID = CommonConnection.getSessionID(RFLogger, false);

			if (sessionID.trim().equalsIgnoreCase("")) {
				RFLogger.debug("Could Not Connect to Server!");
			} else {
				RFLogger.debug("Session ID found: " + sessionID);

				RFLogger.debug("RF Process Starting...");
				sessionID = CommonConnection.getSessionID(RFLogger, false);
				RFNotifyCPF notifyObj = new RFNotifyCPF();
				RFDocGenCPF docGenObj = new RFDocGenCPF();
				RFDocStamping docStampingObj = new RFDocStamping();

				// Call our methods here
				while(true) {
					notifyObj.notifyCPF(sessionID);
					docGenObj.docGenCPF(sessionID);
					docStampingObj.docStamp(sessionID);
					
					RFLogger.debug("No More RF Case to Process, Sleeping!");
					System.out.println("No More RF Case to Process, Sleeping!");
					Thread.sleep(sleepIntervalInMin * 60 * 1000);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			RFLogger.error("Exception Occurred in RF Main: " + e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			RFLogger.error("Exception Occurred in RF Main: " + result);
		}

	}

	private int readConfig() {
		Properties p = null;
		try {
			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir") + File.separator + "ConfigFiles"
					+ File.separator + "RF_Config.properties")));

			Enumeration<?> names = p.propertyNames();

			while (names.hasMoreElements()) {
				String name = (String) names.nextElement();
				RFConfigParamMap.put(name, p.getProperty(name));
			}
		} catch (Exception e) {
			return -1;
		}
		return 0;
	}

	public String customException(Exception e) {
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		String exception = sw.toString();
		try {
			sw.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return exception;
	}

	public String DoneWI(String processInstanceID, String WorkItemID, String decision, String Remarks,
			String ActivityID, String ActivityType, String entryDateTime, String ws_name, Logger logger) {
		String retValue = "";
		try {
			// Lock WorkItem
			String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName,
					CommonConnection.getSessionID(logger, false), processInstanceID, WorkItemID);
			String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP, jtsPort, 1);
			logger.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);
			XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
			String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
			logger.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);
			
			String processdefQuery = "SELECT PROCESSDEFID from PROCESSDEFTABLE WHERE PROCESSNAME='RF'";
			String defidInXML = CommonMethods.apSelectWithColumnNames(processdefQuery, cabinetName, CommonConnection.getSessionID(logger, false));
			String defidOpXML = CommonMethods.WFNGExecute(defidInXML, jtsIP, jtsPort, 1);
			XMLParser xmlParserdefID = new XMLParser(defidOpXML);
			int defIdMC = Integer.parseInt(xmlParserdefID.getValueOf("MainCode"));
			String ProcessDefId = "";
			if(defIdMC==0) {
				ProcessDefId = xmlParserdefID.getValueOf("PROCESSDEFID");
				logger.debug("ProcessDefId:  " + ProcessDefId);
			}
			
			if (getWorkItemMainCode.trim().equals("0")) {
				logger.debug("WMgetWorkItemCall Successful: " + getWorkItemMainCode);

				String attributesTag = "<Decision>" + decision + "</Decision>";

				logger.info("get Workitem call successfull for " + processInstanceID);
				String completeWIFlag = "D";
				logger.debug("WMgetWorkItemCall Successful: " + getWorkItemMainCode);
				if(Integer.parseInt(WorkItemID)>1) {
					attributesTag = "<Decision_Child>" + decision + "</Decision_Child>";
				}
				// Move Workitem to next Workstep
				// String completeWorkItemInputXML =
				// CommonMethods.assignWorkitemAttributeInput(cabinetName,
				// CommonConnection.getSessionID(logger, false), processInstanceID,
				// WorkItemID,ActivityID,ActivityType, attributesTag,completeWIFlag);
				String completeWorkItemInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
						+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + CommonConnection.getCabinetName() + "</EngineName>"
						+ "<SessionId>" + CommonConnection.getSessionID(logger, false) + "</SessionId>" + "<ProcessInstanceId>" + processInstanceID
						+ "</ProcessInstanceId>" + "<WorkItemId>" + WorkItemID + "</WorkItemId>" + "<ActivityId>"
						+ ActivityID + "</ActivityId>" + "<ProcessDefId>" + ProcessDefId + "</ProcessDefId>"
						+ "<LastModifiedTime></LastModifiedTime>" + "<ActivityType>" + ActivityType + "</ActivityType>"
						+ "<complete>D</complete>" + "<AuditStatus></AuditStatus>" + "<Comments></Comments>"
						+ "<UserDefVarFlag>Y</UserDefVarFlag>" + "<Attributes>" + attributesTag + "</Attributes>"
						+ "</WMAssignWorkItemAttributes_Input>";

				String completeWorkItemOutputXML = CommonMethods.WFNGExecute(completeWorkItemInputXML, jtsIP, jtsPort,
						1);
				logger.debug("Output XML for wmcompleteWorkItem: " + completeWorkItemOutputXML);

				XMLParser xmlParserCompleteWorkitem = new XMLParser(completeWorkItemOutputXML);
				String completeWorkitemMaincode = xmlParserCompleteWorkitem.getValueOf("MainCode");
				logger.debug("Status of wmcompleteWorkItem  " + completeWorkitemMaincode);

				if (completeWorkitemMaincode.trim().equalsIgnoreCase("0")) {
					logger.debug("assignWorkitemAttributeInput successful: " + completeWorkitemMaincode);
					SimpleDateFormat inputDateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					// SimpleDateFormat outputDateFormat=new SimpleDateFormat("dd-MMM-yyyy
					// hh:mm:ss");

					Date entryDatetimeFormat = inputDateformat.parse(entryDateTime);
					String formattedEntryDatetime = inputDateformat.format(entryDatetimeFormat);
					logger.debug("FormattedEntryDatetime: " + formattedEntryDatetime);

					Date actionDateTime = new Date();
					String formattedActionDateTime = inputDateformat.format(actionDateTime);
					logger.debug("FormattedActionDateTime: " + formattedActionDateTime);

					// Insert in WIHistory Table.
					String columnNames = "WINAME,Date_Time,WORKSTEP,USER_NAME,DECISION,REMARKS";
					String columnValues = "'" + processInstanceID + "','" + formattedActionDateTime + "','" + ws_name
							+ "','" + CommonConnection.getUsername() + "','" + decision + "','"
							+ Remarks + "'";

					String apInsertInputXML = CommonMethods.apInsert(cabinetName,
							CommonConnection.getSessionID(logger, false), columnNames, columnValues,
							"NG_RF_Decision_History"); // toDo
					logger.debug("APInsertInputXML: " + apInsertInputXML);

					String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
					logger.debug("APInsertOutputXML: " + apInsertOutputXML);

					XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
					String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
					logger.debug("Status of apInsertMaincode  " + apInsertMaincode);

					logger.debug("Completed On " + ws_name);

					if (apInsertMaincode.equalsIgnoreCase("0")) {
						logger.debug("ApInsert successful: " + apInsertMaincode);
						logger.debug("Inserted in WiHistory table successfully.");
					} else {
						logger.debug("ApInsert failed: " + apInsertMaincode);
					}
				} else {
					completeWorkitemMaincode = "";
					logger.debug("WMCompleteWorkItem failed: " + completeWorkitemMaincode);
				}

			}
		} catch (Exception e) {
			logger.debug("Exception: " + e.getMessage());
		}
		return retValue;
	}
	
	protected void insertIntoLogHistory(String winame, String wsname, String reqDateTime, String callName, String UUID, String reqJSON, 
			String responseJSON, String resDateTime, Logger logger) {
		String columnNames = "WI_NAME,WORKSTEP_NAME,ACT_DATE_TIME,CALLNAME,USER_NAME,MESSAGE_ID,INPUT_JSON,OUTPUT_JSON,REQ_DATE_TIME";
		String columnValues = "'" + winame + "','" + wsname + "','" + resDateTime+ "','" + callName + "','" + CommonConnection.getUsername() + "','" + UUID + "','"
				+ reqJSON + "','" + responseJSON + "','"+ reqDateTime + "'";

		try {
			String apInsertInputXML = CommonMethods.apInsert(cabinetName,
					CommonConnection.getSessionID(logger, false), columnNames, columnValues, "NG_RF_JSON_LOG_HISTORY"); // toDo
			logger.debug("APInsertInputXML: " + apInsertInputXML);

			String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
			logger.debug("APInsertOutputXML: " + apInsertOutputXML);

			XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
			String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
			logger.debug("Status of apInsertMaincode  " + apInsertMaincode);

			logger.debug("Completed On " + wsname);

			if (apInsertMaincode.equalsIgnoreCase("0")) {
				logger.debug("ApInsert successful: " + apInsertMaincode);
				logger.debug("Inserted in WiHistory table successfully.");
			} else {
				logger.debug("ApInsert failed: " + apInsertMaincode);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
