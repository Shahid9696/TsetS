package com.newgen.common;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import org.apache.log4j.Logger;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.newgen.RF.RFMain;
import com.newgen.omni.jts.cmgr.XMLParser;



public class CommonExecuteAPI {
	
	public static int retCode = 0;
	public static String uuid = "";
	public static String authURL = "";
	public static String authBody = "";
	
	public static String postKongToken(String URL, String requestBody, Logger logger) {
		try {
			// Load SSL certs or custom trust settings
			loadSSL(logger);

			// Open URL connection
			URL postUrl = new URL(URL);
			HttpURLConnection postConnection = (HttpURLConnection) postUrl.openConnection();
			logger.info("After URL connection:");

			// Set request method and headers
			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("Accept", "application/json");
			postConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			postConnection.setDoOutput(true);

			// Send request
			//logger.info("After JSON Request Construction: " + requestBody);
			try (DataOutputStream outputStream = new DataOutputStream(postConnection.getOutputStream())) {
				outputStream.writeBytes(requestBody);
				outputStream.flush();
			}

			logger.info("After Output Stream flush");

			// Read response
			int postResponseCode = postConnection.getResponseCode();
			logger.info("Response Code: " + postResponseCode);

			setRetCode(postResponseCode);
			StringBuilder postResponse = new StringBuilder();
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(
					postResponseCode >= 400 ? postConnection.getErrorStream() : postConnection.getInputStream()))) {
				logger.info("Inside Response from Input Stream");
				String inputLine;
				while ((inputLine = reader.readLine()) != null) {
					postResponse.append(inputLine);
				}
			}

			logger.info("Final JSON Response: " + postResponse);
			postConnection.disconnect();

			return postResponse.toString();

		} catch (IOException ioEx) {
			logger.error("HTTP Connection Error: " + ioEx.getMessage(), ioEx);
			return "Failure" + ioEx.getMessage(); // indicate connection failure
		}
	}
	
	public static void loadSSL(Logger logger) {
		String certFilePass = RFMain.RFConfigParamMap.get("certFilePass");
		String workingDirectory = System.getProperty("user.dir");
		logger.debug("certFilePass: " + certFilePass);
		String cacertsFile = workingDirectory + File.separator + "Certificates" + File.separator + "KongSSL.jks";
		logger.info("CacertsFile: " + cacertsFile);
		
		String packageHndStr = "javax.net.ssl";
		java.lang.System.setProperty("java.protocol.handler.pkgs", packageHndStr);
		java.lang.System.setProperty("Content-Type", "text/html");
		java.lang.System.setProperty("Content-Type", "application/soap+xml; charset=utf-8");
		java.lang.System.setProperty("javax.net.ssl.keyStore", cacertsFile);
		java.lang.System.setProperty("javax.net.ssl.keyStoreType", java.security.KeyStore.getDefaultType());
		java.lang.System.setProperty("javax.net.ssl.keyStorePassword", certFilePass);
		java.lang.System.setProperty("javax.net.ssl.trustStore", cacertsFile);
		java.lang.System.setProperty("javax.net.ssl.trustStoreType", java.security.KeyStore.getDefaultType());
		java.lang.System.setProperty("javax.net.ssl.trustStorePassword", certFilePass);
	}
	
	public static String postOnboardAPI(String URL, String requestBody, String authToken, Logger logger) {
		try {
			// Load SSL certs or custom trust settings
			loadSSL(logger);

			// Open URL connection
			URL postUrl = new URL(URL);
			HttpURLConnection postConnection = (HttpURLConnection) postUrl.openConnection();
			logger.info("After URL connection:");

			// Set request method and headers
			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("Authorization", "Bearer "+ authToken);
			postConnection.setRequestProperty("x-correlation-id", getUUID());
			postConnection.setRequestProperty("Accept", "application/json");
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setDoOutput(true);
			
			logger.info("Generated UUID: " + uuid);
			// Send request
			logger.info("After JSON Request Construction: " + requestBody);
			try (DataOutputStream outputStream = new DataOutputStream(postConnection.getOutputStream())) {
				outputStream.writeBytes(requestBody);
				outputStream.flush();
			}

			logger.info("After Output Stream flush");

			// Read response
			int postResponseCode = postConnection.getResponseCode();
			logger.info("Response Code: " + postResponseCode);

			StringBuilder postResponse = new StringBuilder();
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(
					postResponseCode >= 400 ? postConnection.getErrorStream() : postConnection.getInputStream()))) {
				logger.info("Inside Response from Input Stream");
				String inputLine;
				while ((inputLine = reader.readLine()) != null) {
					postResponse.append(inputLine);
				}
			}
			
			setRetCode(postResponseCode);
			logger.info("Final JSON Response: " + postResponse);
			postConnection.disconnect();

			return postResponse.toString();

		} catch (IOException ioEx) {
			logger.error("HTTP Connection Error: " + ioEx.getMessage(), ioEx);
			return "Failure" + ioEx.getMessage(); // indicate connection failure
		}
	}
	
	protected static String getUUID() {
		UUID uid = UUID.randomUUID();
		uuid = uid.toString();
		return uuid;
	}
	
	public static String getAuthToken(Logger logger) {
		JsonObject root;
		String token = "";
		String expiry = "";
		token  = getExistingAuthToken(logger);
		if(token.equalsIgnoreCase("") && token.length()==0) {
		String output = CommonExecuteAPI.postKongToken(getAuthURL(),getAuthBody(),logger);
		root = JsonParser.parseString(output).getAsJsonObject();
		
		logger.debug("Response from CPF Doc API: " + output);
		logger.debug("ReturnCode from CPF Doc API: " + getRetCode());
		
		if(getRetCode()==200) {
			root = JsonParser.parseString(output).getAsJsonObject();
			token = root.get("access_token").getAsString();
			expiry = root.get("expires_in").getAsString();
		}
		
		String colNames = "AuthToken,GenDateTime,ExpiryDateTime";
		String colValues = "'"+token+"',getDate(),DATEADD(second,"+expiry+",getDate())";
		
		try {
			String apInsertInputXML = CommonMethods.apInsert(CommonConnection.getCabinetName(),
					CommonConnection.getSessionID(logger, false), colNames, colValues, "NG_CPF_AUTH_TOKEN"); // toDo
			logger.debug("APInsertInputXML: " + apInsertInputXML);

			String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(), 1);
			logger.debug("APInsertOutputXML: " + apInsertOutputXML);

			XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
			String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
			logger.debug("Status of apInsertMaincode  " + apInsertMaincode);

			if (apInsertMaincode.equalsIgnoreCase("0")) {
				logger.debug("ApInsert successful: " + apInsertMaincode);
				logger.debug("Inserted in Auth table successfully.");
			} else {
				logger.debug("ApInsert failed: " + apInsertMaincode);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		return token;
	}
	
	public static String getExistingAuthToken(Logger logger) {
		
		String AuthToken = "";
		try {
			String tokenQuery = "SELECT AuthToken from NG_CPF_AUTH_TOKEN with(NOLOCK) where expiryDateTime>GETDATE()";
			String tokenIPXML = CommonMethods.apSelectWithColumnNames(tokenQuery, CommonConnection.getCabinetName(),
					CommonConnection.getSessionID(logger, false));;
			String tokenOPXML = CommonMethods.WFNGExecute(tokenIPXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(), 1);;
			XMLParser tokenXML = new XMLParser(tokenOPXML);
			int totalRet = Integer.parseInt(tokenXML.getValueOf("TotalRetrieved"));
			if (tokenXML.getValueOf("MainCode").equalsIgnoreCase("0") && totalRet > 0) {
				AuthToken = tokenXML.getValueOf("AuthToken");
			}
			logger.debug("Got exisiting token: "+ AuthToken);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return AuthToken;
	}

	public static int getRetCode() {
		return retCode;
	}

	public static void setRetCode(int returnCode) {
		retCode = returnCode;
	}

	public static void setAuthURL(String authURL) {
		CommonExecuteAPI.authURL = authURL;
	}

	public static void setAuthBody(String authBody) {
		CommonExecuteAPI.authBody = authBody;
	}

	public static String getAuthURL() {
		return authURL;
	}

	public static String getAuthBody() {
		return authBody;
	}
	
}


