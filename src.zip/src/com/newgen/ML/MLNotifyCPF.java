package com.newgen.ML;

import com.newgen.common.CommonMethods;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.time.DayOfWeek;
import java.time.format.DateTimeFormatterBuilder;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.JsonReader;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonExecuteAPI;
import com.newgen.omni.jts.cmgr.XMLParser;

import com.newgen.omni.wf.util.excp.NGException;

import ISPack.*;
import ISPack.ISUtil.*;
import Jdts.DataObject.JPDBString;

public class MLNotifyCPF extends MLMain {
	private static String cabinetName = "";
	private static String jtsIP = "";
	private static String jtsPort = "";
	final private static String ws_name = "Sys_Notify_CPF";
	private static String notifyStage = "";
	private static String authToken = "";
	private static String postURL = "";
	Logger MLLogger;
	MLMain obj = new MLMain();

	public MLNotifyCPF() throws NGException {

		MLLog.setLogger(getClass().getSimpleName());
		MLLogger = MLLog.getLogger(getClass().getSimpleName());
	}

	protected void notifyCPF(String sessionID) {

		try {

			String queueID = "";
			// String notifyResponse = "";
			// String postURL = "";

			MLLogger.debug("Connecting to Cabinet.");

			cabinetName = CommonConnection.getCabinetName();
			MLLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			MLLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			MLLogger.debug("JTSPORT: " + jtsPort);

			queueID = MLMain.MLConfigParamMap.get("NotifyQueueID");
			MLLogger.debug("QueueID: " + queueID);

			postURL = MLMain.MLConfigParamMap.get("NotifyEndPoint");
			MLLogger.debug("Notify URL: " + postURL);

			if (sessionID.trim().equalsIgnoreCase("")) {
				MLLogger.debug("Could Not Connect to Server!");
				return;
			} else {
				MLLogger.debug("Session ID found: " + sessionID);
				MLLogger.debug("ML Notify to CPF ...123.");
				MLLogger.debug("ML Notify to sessionID ...123." + sessionID);
				executeNotify(queueID, sessionID);
				PendingComm("1321", sessionID);
				newDelayedNotify1(sessionID);
				newDelayedNotify2(sessionID);

			}
		} catch (Exception e) {
			MLLogger.error("Exception occured in NotifyCPF: " + obj.customException(e));
		}

	}

	private void executeNotify(String queueID, String sessionID) {

		try {

			// Fetch all Work-Items on given queueID.
			MLLogger.debug("Fetching all Workitems on awaitNotifyCPF queue");
			// System.out.println("Fetching all Workitems on Notify CPF queue");
			String fetchWorkitemListInputXML = CommonMethods.fetchWorkItemsInput(cabinetName, sessionID, queueID);
			MLLogger.debug("InputXML for fetchWorkList Call: " + fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML = CommonMethods.WFNGExecute(fetchWorkitemListInputXML, jtsIP, jtsPort, 1);

			MLLogger.debug("WMFetchWorkList Notify CPF OutputXML: " + fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			MLLogger.debug("FetchWorkItemListMainCode: " + fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
			MLLogger.debug("RetrievedCount for WMFetchWorkList Call: " + fetchWorkitemListCount);

			MLLogger.debug("Number of workitems retrieved on Notify CPF: " + fetchWorkitemListCount);

			System.out.println("Number of workitems retrieved on Notify CPF: " + fetchWorkitemListCount);

			String kongToken = CommonExecuteAPI.getAuthToken(MLLogger);
			MLLogger.debug("KongAuthToken: " + kongToken);
			authToken = kongToken;

			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0) {
				for (int i = 0; i < fetchWorkitemListCount; i++) {
					String fetchWorkItemlistData = xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData = fetchWorkItemlistData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

					MLLogger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: " + fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

					String processInstanceID = xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					MLLogger.debug("Current ProcessInstanceID: " + processInstanceID);

					MLLogger.debug("Processing Workitem: " + processInstanceID);
					System.out.println("\nProcessing Workitem: " + processInstanceID);

					String WorkItemID = xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					MLLogger.debug("Current WorkItemID: " + WorkItemID);

					String entryDateTime = xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					MLLogger.debug("Current EntryDateTime: " + entryDateTime);

					String ActivityName = xmlParserfetchWorkItemData.getValueOf("ActivityName");
					MLLogger.debug("ActivityName: " + ActivityName);

					String ActivityID = xmlParserfetchWorkItemData.getValueOf("WorkStageId");
					MLLogger.debug("ActivityID: " + ActivityID);
					String ActivityType = xmlParserfetchWorkItemData.getValueOf("ActivityType");
					MLLogger.debug("ActivityType: " + ActivityType);
					String ProcessDefId = xmlParserfetchWorkItemData.getValueOf("RouteId");
					MLLogger.debug("ProcessDefId: " + ProcessDefId);

					String getDataRes = getNotifyData(processInstanceID, WorkItemID);
					MLLogger.debug("getNotify Request Body: " + getDataRes);

					String requestJSON = "";
					String responseJSON = "";
					String reqDateTime = "";
					String responseDateTime = "";
					if (!"Error".equalsIgnoreCase(getDataRes)) {

						try {
							requestJSON = getDataRes;
							reqDateTime = LocalDateTime.now()
									.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
							responseJSON = CommonExecuteAPI.postOnboardAPI(postURL, requestJSON, authToken, MLLogger);
							MLLogger.debug("CPF Notify Response: " + responseJSON);
							JsonObject response = JsonParser.parseString(responseJSON).getAsJsonObject();

							responseDateTime = LocalDateTime.now()
									.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
							int returnCode = CommonExecuteAPI.getRetCode();
							MLLogger.debug("ReturnCode from CPF Notify API: " + returnCode);
							if (returnCode == 202) {
								obj.DoneWI(processInstanceID, WorkItemID, "Success", "CPF Notify Call Successfull",
										ActivityID, ActivityType, entryDateTime, ws_name, MLLogger);

							} else {
								JsonArray errorArr = response.getAsJsonArray("errors");
								String description = errorArr.get(0).getAsJsonObject().get("message").getAsString()
										.replace("'", "''");

								MLLogger.debug("description: " + description);
								obj.DoneWI(processInstanceID, WorkItemID, "Failure", description, ActivityID,
										ActivityType, entryDateTime, ws_name, MLLogger);

							}

							obj.insertIntoLogHistory(processInstanceID, ws_name, reqDateTime, "onboard-notification",
									CommonExecuteAPI.uuid, requestJSON, responseJSON, responseDateTime, MLLogger);
						} catch (Exception e) {
							MLLogger.error("Exception occured in processing WI: " + obj.customException(e));
						}
					}

				}
			}

		} catch (Exception e)

		{
			MLLogger.error("Exception occured in executeNotify method: " + obj.customException(e));
		}

	}

	private String getNotifyData(String processInstanceID, String WorkItemID) throws IOException, Exception {
		String DBQuery = "select top 1 CIF,CUSTOMER_NAME,Email_ID,Mobile_No,DOB,w.VAR_STR15 as NotifyStage,"
				+ "ISLAMIC_OR_CONVENTIONAL,Cooling_Period_Waived_Off,ACCOUNT_NUMBER,AGREEMENT_NUMBER,"
				+ "CASE_TYPE,LOAN_AMOUNT,APPLICATION_DATE,CoolingPeriodFlag_SalesAttach from RB_ML_EXTTABLE e "
				+ "with(nolock) JOIN WFINSTRUMENTTABLE w with(nolock) ON e.WINAME=w.ProcessInstanceID "
				+ "where e.WINAME='" + processInstanceID + "' and w.workitemid='" + WorkItemID + "'";
		String extTabDataIPXML = CommonMethods.apSelectWithColumnNames(DBQuery, cabinetName,
				CommonConnection.getSessionID(MLLogger, false));
		MLLogger.debug("extTabDataIPXML: " + extTabDataIPXML);
		String extTabDataOPXML = CommonMethods.WFNGExecute(extTabDataIPXML, jtsIP, jtsPort, 1);
		MLLogger.debug("extTabDataOPXML: " + extTabDataOPXML);

		XMLParser xmlParserData = new XMLParser(extTabDataOPXML);
		JsonObject subReqBody = new JsonObject();
		String notifyStageFromWI = "";
		int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));

		notifyStageFromWI = xmlParserData.getValueOf("NotifyStage");
		if (xmlParserData.getValueOf("MainCode").equalsIgnoreCase("0") && iTotalrec > 0) {
			if ("Approval".equalsIgnoreCase(notifyStageFromWI) || "Disbursal".equalsIgnoreCase(notifyStageFromWI)
					|| "Rejection".equalsIgnoreCase(notifyStageFromWI)
					|| "Cancellation".equalsIgnoreCase(notifyStageFromWI)
					|| "Pending".equalsIgnoreCase(notifyStageFromWI)
					|| "Re-Approval".equalsIgnoreCase(notifyStageFromWI)
					|| "Delayed".equalsIgnoreCase(notifyStageFromWI)) {
				if ("Re-Approval".equalsIgnoreCase(notifyStageFromWI)) {
					notifyStage = "Post Approval";
				} else {
					notifyStage = notifyStageFromWI;
				}
			}
			MLLogger.debug("Notify Stage: " + notifyStage);

			String coolingOffWaived = null;
			if ("Yes".equalsIgnoreCase(xmlParserData.getValueOf("Cooling_Period_Waived_Off"))) {
				coolingOffWaived = "Y";
			} else if ("No".equalsIgnoreCase(xmlParserData.getValueOf("Cooling_Period_Waived_Off"))) {
				coolingOffWaived = "N";
			}
			String coolingOffActiveFlag = xmlParserData.getValueOf("CoolingPeriodFlag_SalesAttach");
			String custType = xmlParserData.getValueOf("ISLAMIC_OR_CONVENTIONAL");
			String dateOfBirth = xmlParserData.getValueOf("DOB");
			SimpleDateFormat iFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat oFormat = new SimpleDateFormat("yyyy-MM-dd");

			try {
				Date dDate = iFormat.parse(dateOfBirth);
				dateOfBirth = oFormat.format(dDate);
			} catch (Exception e) {
				MLLogger.debug("Exception occured in fetching credit ApprovalDate: " + obj.customException(e));
			}
			String submissionDate = xmlParserData.getValueOf("APPLICATION_DATE");
			String loanAmountStr = xmlParserData.getValueOf("LOAN_AMOUNT");
			loanAmountStr = loanAmountStr.replace(",", "");
			String integerPart = loanAmountStr.split("\\.")[0];

			String consentRequired = "Approval".equalsIgnoreCase(notifyStage) ? "Y" : "N";
			String queryCredit = "SELECT ACTION_DATE_TIME " + "FROM ( "
					+ "    SELECT e.WI_NAME, e.ACTION_DATE_TIME, e.DECISION, e.WORKSTEP, "
					+ "           ROW_NUMBER() OVER (PARTITION BY e.WI_NAME ORDER BY e.ACTION_DATE_TIME ASC) AS rn "
					+ "    FROM USR_0_ML_WIHISTORY e " + "    JOIN RB_ML_EXTTable r ON e.WI_NAME = r.WINAME "
					+ "    WHERE e.DECISION = 'Approve' " + "      AND e.WORKSTEP = 'Credit' "
					+ "      AND r.REQUEST_FOR = 'Final Offer Letter' " + "      AND e.WI_NAME = '" + processInstanceID
					+ "' " + ") RankedActions " + "WHERE rn = 1";

			String inputXML = CommonMethods.apSelectWithColumnNames(queryCredit, cabinetName, sessionID);
			String outputXML = CommonMethods.WFNGExecute(inputXML, jtsIP, jtsPort, 1);

			XMLParser parser = new XMLParser(outputXML);
			String mainCode = parser.getValueOf("MainCode");
			int TotalRet = Integer.parseInt(parser.getValueOf("TotalRetrieved"));
			String creditApprovalDate = null;
			if (parser.getValueOf("MainCode").equalsIgnoreCase("0") && TotalRet > 0) {
				// String creditApprovalDate =
				// parser.getNextValueOf("ACTION_DATE_TIME");
				String actionDateStr = parser.getNextValueOf("ACTION_DATE_TIME");
				SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");

				try {
					Date actionDate = inputFormat.parse(actionDateStr);
					creditApprovalDate = outputFormat.format(actionDate);
					// subReqBody.addProperty("creditApprovalDate",
					// creditApprovalDate);
				} catch (Exception e) {
					MLLogger.debug("Exception occured in fetching credit ApprovalDate: " + obj.customException(e));
				}

			}
			String queryDisbursal = "SELECT TOP 1 ACTION_DATE_TIME as actiondatetime " + "FROM USR_0_ML_WIHISTORY "
					+ "WHERE DECISION = 'Approve' " + "AND WORKSTEP = 'CROPS_Disbursal_Checker' " + "AND WI_NAME = '"
					+ processInstanceID + "' " + "ORDER BY ENTRY_DATE_TIME DESC";

			String inputXMLDis = CommonMethods.apSelectWithColumnNames(queryDisbursal, cabinetName, sessionID);
			String outputXMLDis = CommonMethods.WFNGExecute(inputXMLDis, jtsIP, jtsPort, 1);

			XMLParser parserDis = new XMLParser(outputXMLDis);
			String mainCodeDis = parserDis.getValueOf("MainCode");
			int DisTotalRet = Integer.parseInt(parserDis.getValueOf("TotalRetrieved"));
			String disbursalDate = null;
			if (mainCodeDis.equalsIgnoreCase("0") && DisTotalRet > 0) {
				String actionDateStr = parserDis.getNextValueOf("actiondatetime");
				SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
				try {
					Date actionDate = inputFormat.parse(actionDateStr);
					disbursalDate = outputFormat.format(actionDate);
				} catch (Exception e) {
					MLLogger.debug("Exception occured in fetching credit ApprovalDate: " + obj.customException(e));
				}

			}

			subReqBody.addProperty("workItemId", processInstanceID);
			subReqBody.addProperty("cifId", xmlParserData.getValueOf("CIF"));
			subReqBody.addProperty("customerName", xmlParserData.getValueOf("CUSTOMER_NAME"));
			subReqBody.addProperty("mailId", xmlParserData.getValueOf("Email_ID"));
			subReqBody.addProperty("mobileNo", xmlParserData.getValueOf("Mobile_No"));
			MLLogger.debug("MobileNo present: " + processInstanceID);
			subReqBody.addProperty("dateOfBirth", dateOfBirth);
			subReqBody.addProperty("stage", notifyStage);
			subReqBody.addProperty("segment", "PBG");
			subReqBody.addProperty("crossSell", "N");
			subReqBody.addProperty("custType", custType.substring(0, 1));
		
			if (notifyStage == "Post Approval") { 
				 subReqBody.addProperty("coolingOffWaived", coolingOffWaived);
				 //subReqBody.addProperty("coolingOffActiveFlag", coolingOffActiveFlag);
			 }
			 if ("Post Approval".equals(notifyStage) && "N".equals(coolingOffWaived)){ 
				 subReqBody.addProperty("coolingOffActiveFlag", coolingOffActiveFlag);
			 }
			subReqBody.addProperty("accountId", xmlParserData.getValueOf("ACCOUNT_NUMBER"));
			subReqBody.addProperty("agreementId", xmlParserData.getValueOf("AGREEMENT_NUMBER"));
			subReqBody.addProperty("processName", "Mortgage Loan");
			subReqBody.addProperty("subProcessName", "ML_CPF");
			subReqBody.addProperty("productType", "Mortgage Loan");
			subReqBody.addProperty("subProductType", xmlParserData.getValueOf("CASE_TYPE"));
			subReqBody.addProperty("amount", integerPart);
			if (disbursalDate == null) {
				MLLogger.debug("Disbursal date is null for WI_NAME: " + processInstanceID);
			}
			subReqBody.addProperty("disbursalDate", disbursalDate);
			if (creditApprovalDate == null) {
				MLLogger.debug("creditApproval Date is null for WI_NAME: " + processInstanceID);
			}
			subReqBody.addProperty("creditApprovalDate", creditApprovalDate);
			subReqBody.addProperty("submissionDate", submissionDate.substring(0, 10));
			subReqBody.addProperty("consentRequired", consentRequired);
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			if ("Approval".equalsIgnoreCase(notifyStage) || "Disbursal".equalsIgnoreCase(notifyStage)
					|| "Re-Approval".equalsIgnoreCase(notifyStage)) {
				String notifyDocs = "";
				notifyDocs = MLMain.MLConfigParamMap.get(notifyStage + "Docs");
				MLLogger.debug("NotifyDoc List: " + notifyDocs);

				String folderIndex = "";
				folderIndex = MLMain.MLConfigParamMap.get(custType + "DocIndex");
				MLLogger.debug("folderIndex for " + custType + ": " + folderIndex);
				JsonArray docs = null;
				try {
					String docQuery = "select Name as documentType,DocumentIndex as documentIndex from PDBDocument "
							+ "with(nolock) where DocumentIndex in (select DocumentIndex from PDBDocumentContent "
							+ "with(nolock) where ParentFolderIndex = (select FolderIndex From PDBFolder with(nolock) "
							+ "where Name='" + processInstanceID + "')) and Name in " + notifyDocs + " UNION ALL"
							+ " select Name as documentType,DocumentIndex as documentIndex from PDBDocument with(nolock) where DocumentIndex in "
							+ "(select DocumentIndex from PDBDocumentContent with(nolock) where ParentFolderIndex = "
							+ folderIndex + ")";
					String docIndexIPXML = CommonMethods.apSelectWithColumnNames(docQuery, cabinetName,
							CommonConnection.getSessionID(MLLogger, false));
					MLLogger.debug("docIndexIPXML: " + docIndexIPXML);
					String docIndexOPXML = CommonMethods.WFNGExecute(docIndexIPXML, jtsIP, jtsPort, 1);
					MLLogger.debug("docIndexOPXML: " + docIndexOPXML);

					XMLParser xmlParserDoc = new XMLParser(docIndexOPXML);

					int docTotalRet = Integer.parseInt(xmlParserDoc.getValueOf("TotalRetrieved"));
					if (xmlParserDoc.getValueOf("MainCode").equalsIgnoreCase("0") && docTotalRet > 0) {
						docs = getRecordsJsonArray(docIndexOPXML);
						subReqBody.add("documents", docs);
						MLLogger.debug("Final Req JSON: " + gson.toJson(subReqBody));
						return gson.toJson(subReqBody);
					}
				} catch (Exception e) {
					MLLogger.error("Exception occured in getting docs for Notify: " + obj.customException(e));
					return "Error";
				}
			}
			return gson.toJson(subReqBody);
		}
		return "Error";
	}

	// Shahid delay logic start- /21-09-2025
	private String newDelayedNotify1(String sessionID) {
		try {
			MLLogger.debug("Fetching all Workitems on credit and initiator_reject queue");
			String getWiQuery = "SELECT DISTINCT w.ProcessInstanceID, w.Queuename, r.Delay_comm_logi_1,  w.WorkItemId ,"
					+ "(SELECT TOP 1 h1.ACTION_DATE_TIME FROM USR_0_ML_WIHISTORY h1 "
					+ "WHERE h1.WI_NAME = w.ProcessInstanceID ORDER BY h1.ENTRY_DATE_TIME ASC) AS Earliest_Act_Date_Time "
					+ "FROM WFINSTRUMENTTABLE w " + "JOIN RB_ML_EXTTABLE r ON w.ProcessInstanceID = r.WINAME "
					+ "WHERE r.REQUEST_FOR IN ('IPA - Credit', 'IPA - Express') "
					+ "AND (w.Queuename = 'ML_Credit' OR (w.Queuename = 'ML_Initiator_Reject' AND w.VAR_STR4 = 'Credit')) "
					+ "AND NOT EXISTS (SELECT 1 FROM USR_0_ML_WIHISTORY h2 "
					+ "WHERE h2.WI_NAME = w.ProcessInstanceID AND h2.WORKSTEP = 'Credit' AND h2.DECISION = 'Approve')";
			String extTabDataIPXML = CommonMethods.apSelectWithColumnNames(getWiQuery, cabinetName, sessionID);
			String extTabDataOPXML = CommonMethods.WFNGExecute(extTabDataIPXML, jtsIP, jtsPort, 1);
			MLLogger.debug("log of getWiQuery: " + getWiQuery);
			MLLogger.debug("log of extTabDataIPXML: " + extTabDataIPXML);
			XMLParser parser = new XMLParser(extTabDataOPXML);
			MLLogger.debug("log value of extTabDataOPXML: " + extTabDataOPXML);
			String mainCodeValue = parser.getValueOf("MainCode");
			MLLogger.debug("SmainCodeValueS-mainCodeValue: " + mainCodeValue);
			XMLParser subparser = new XMLParser();

			String wiName = "";
			String WorkItemID = "";
			String currentWs = "";
			String starDateTime = "";
			String formattedCurrentTime = "";
			String Delaylogi1 = "";
			String updateIPXML2 = "";
			String updateOPXML2 = "";
			String updateIPXML1 = "";
			String updateOPXML1 = "";
			int rows2 = 0;
			int rows1 = 0;
			String updateIPXML21 = "";
			String updateOPXML21 = "";
			String updateIPXML12 = "";
			String updateOPXML12 = "";
			int rows21 = 0;
			int rows12 = 0;
			int delayCommInt = 0;
			int totRece = Integer.parseInt(parser.getValueOf("TotalRetrieved"));
			MLLogger.debug("totRece no of record: " + totRece);
			if (parser.getValueOf("MainCode").equalsIgnoreCase("0") && totRece > 0) {
				int noOfFields = parser.getNoOfFields("Record");
				MLLogger.debug("noOfFields:: " + noOfFields);
				if (!(noOfFields == 0)) {
					for (int i = 0; i < noOfFields; i++) {
						subparser = new XMLParser(parser.getNextValueOf("Record"));
						wiName = subparser.getValueOf("ProcessInstanceID");
						currentWs = subparser.getValueOf("Queuename");
						Delaylogi1 = subparser.getValueOf("Delay_comm_logi_1");
						starDateTime = subparser.getValueOf("Earliest_Act_Date_Time");
						WorkItemID = subparser.getValueOf("WorkItemId");
						MLLogger.debug("WorkItemID::" + WorkItemID);
						MLLogger.debug("wiName:: " + wiName);
						MLLogger.debug("Delay_comm_logi_1:: " + Delaylogi1);
						MLLogger.debug("currentWs:: " + currentWs);
						MLLogger.debug("starDateTime:: " + starDateTime);

						if (starDateTime.contains(".")) {
							String[] parts = starDateTime.split("\\.");
							String millis = parts[1];
							while (millis.length() < 3) {
								millis += "0";
							}
							starDateTime = parts[0] + "." + millis;
						}

						DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
						LocalDateTime finalEntryDateTime = LocalDateTime.parse(starDateTime, format);

						MLLogger.debug("starDateTime entryDayTime final: " + finalEntryDateTime);

						LocalDateTime currentTime = LocalDateTime.now();
						formattedCurrentTime = currentTime.format(format);
						MLLogger.debug("CurrentTime: " + formattedCurrentTime);

						// Count only weekdays (Monday to Friday)
						long weekdayCount = 0;
						LocalDateTime tempDate = finalEntryDateTime.toLocalDate().atStartOfDay();
						while (tempDate.isBefore(currentTime)) {
							DayOfWeek day = tempDate.getDayOfWeek();
							if (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY) {
								weekdayCount++;
							}
							tempDate = tempDate.plusDays(1);
						}

						MLLogger.debug("Weekdays between dates weekdayCount: " + weekdayCount);
						// stat
						if (Delaylogi1 == "NULL" || Delaylogi1 == "" || Delaylogi1.equalsIgnoreCase("")) {
							if (weekdayCount >= 14) {
								MLLogger.debug("inisde theweekdayCount totalTAT >= 14:DelayComm value " + Delaylogi1);

								updateIPXML1 = CommonMethods.apUpdateInput(cabinetName, sessionID, "RB_ML_EXTTABLE",
										"Delay_comm_logi_1", "'1'", "WINAME = '" + wiName + "'");
								MLLogger.debug("updateIPXML-eweekdayCountxtTabDataIPXML:Delayed " + updateIPXML1);
								updateOPXML1 = CommonMethods.WFNGExecute(updateIPXML1, jtsIP, jtsPort, 1);
								MLLogger.debug("updateOPXML--weekdayCountextTabDataOPXML:Delayed " + updateOPXML1);
								XMLParser xParserUpdate1 = new XMLParser(updateOPXML1);
								rows1 = Integer.parseInt(xParserUpdate1.getValueOf("Output"));
								if (rows1 == 1) {
									MLLogger.debug(
											"Updated DB Flag:weekdayCount Delayed inisde the totalTAT >= 14:value of row:"
													+ rows1);
								}

								updateIPXML12 = CommonMethods.apUpdateInput(cabinetName, sessionID, "WFINSTRUMENTTABLE",
										"VAR_STR15", "'Delayed'",
										"Queuename='" + currentWs + "' AND ProcessInstanceID = '" + wiName + "'");
								MLLogger.debug("updateIPXML12-eweekdayCountxtTabDataIPXML:Delayed " + updateIPXML12);
								updateOPXML12 = CommonMethods.WFNGExecute(updateIPXML12, jtsIP, jtsPort, 1);
								MLLogger.debug("updateOPXML12--weekdayCountextTabDataOPXML:Delayed " + updateOPXML12);
								XMLParser xParserUpdate12 = new XMLParser(updateOPXML12);
								rows12 = Integer.parseInt(xParserUpdate12.getValueOf("Output"));
								if (rows12 == 1) {
									MLLogger.debug(
											"Updated DB rows12 Flag:weekdayCount Delayed inisde the totalTAT >= 14:value of row:"
													+ rows12);
								}
								// Api start
								try {
									String getDataRes = getNotifyData(wiName, WorkItemID);
									MLLogger.debug("getNotify Request Body weekdayCount >= 14: " + getDataRes);

									if (!"Error".equalsIgnoreCase(getDataRes)) {
										String requestJSON = getDataRes;
										String reqDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										String responseJSON = CommonExecuteAPI.postOnboardAPI(postURL, requestJSON,
												authToken, MLLogger);
										MLLogger.debug("CPF Notify Response: " + responseJSON);

										JsonObject response = JsonParser.parseString(responseJSON).getAsJsonObject();
										String responseDateTime = LocalDateTime.now()
												.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										int returnCode = CommonExecuteAPI.getRetCode();
										MLLogger.debug("ReturnCode from CPF Notify API: " + returnCode);

										if (returnCode == 202) {
											MLLogger.debug("CPF Notify API call successful for WINAME: " + wiName);
										} else {
											MLLogger.debug(
													"CPF Notify API call failed with return code: " + returnCode);
										}
										obj.insertIntoLogHistory(wiName, currentWs, reqDateTime, "onboard-notification",
										CommonExecuteAPI.uuid, requestJSON, responseJSON, responseDateTime, MLLogger);
									}
								} catch (Exception e) {
									MLLogger.debug("Exception during CPF Notify API call: " + e.getMessage());
								}

								// Api end
								MLLogger.debug("inisde the weekdayCount >= 14: weekdayCount value:" + weekdayCount);
							}
						} else {
							weekdayCount = weekdayCount - ((Integer.parseInt(Delaylogi1) + 1) * 7);
							MLLogger.debug("newTAT else: " + weekdayCount);
							if (weekdayCount >= 7) {

								delayCommInt = Integer.parseInt(Delaylogi1);
								delayCommInt += 1;
								Delaylogi1 = String.valueOf(delayCommInt);
								MLLogger.debug("inisde theweekdayCount weekdayCount >= 7DelayComm value " + Delaylogi1);
								updateIPXML2 = CommonMethods.apUpdateInput(cabinetName, sessionID, "RB_ML_EXTTABLE",
										"Delay_comm_logi_1", " '" + Delaylogi1 + "' ", "WINAME = '" + wiName + "'");
								MLLogger.debug("updateIPXML-exweekdayCounttTabDataIPXML:Delayed " + updateIPXML2);
								updateOPXML2 = CommonMethods.WFNGExecute(updateIPXML2, jtsIP, jtsPort, 1);
								MLLogger.debug("updateOPXML-weekdayCount-extTabDataOPXML:Delayed " + updateOPXML2);
								XMLParser xParserUpdate2 = new XMLParser(updateOPXML2);
								rows2 = Integer.parseInt(xParserUpdate2.getValueOf("Output"));
								if (rows2 == 1) {
									MLLogger.debug("Updated DB Flag: Delayed inisde the weekdayCount >= 7:" + rows2);
								}

								updateIPXML21 = CommonMethods.apUpdateInput(cabinetName, sessionID, "WFINSTRUMENTTABLE",
										"VAR_STR15", "'Delayed'",
										"Queuename='" + currentWs + "' AND ProcessInstanceID = '" + wiName + "'");
								MLLogger.debug("updateIPXML21-exweekdayCounttTabDataIPXML:Delayed " + updateIPXML21);
								updateOPXML21 = CommonMethods.WFNGExecute(updateIPXML21, jtsIP, jtsPort, 1);
								MLLogger.debug("updateOPXML21-weekdayCount-extTabDataOPXML:Delayed " + updateOPXML21);
								XMLParser xParserUpdate21 = new XMLParser(updateOPXML21);
								rows21 = Integer.parseInt(xParserUpdate21.getValueOf("Output"));
								if (rows21 == 1) {
									MLLogger.debug(
											"Updated DB Flag:rows21 Delayed inisde the weekdayCount >= 7:" + rows21);
								}
								MLLogger.debug("inisde the weekdayCount >= 7 weekdayCount value:" + weekdayCount);
								// Api start
								try {
									String getDataRes = getNotifyData(wiName, WorkItemID);
									MLLogger.debug("getNotify Request Body weekdayCount >= 7: " + getDataRes);

									if (!"Error".equalsIgnoreCase(getDataRes)) {
										String requestJSON = getDataRes;
										String reqDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										String responseJSON = CommonExecuteAPI.postOnboardAPI(postURL, requestJSON,
												authToken, MLLogger);
										MLLogger.debug("CPF Notify Response: " + responseJSON);

										JsonObject response = JsonParser.parseString(responseJSON).getAsJsonObject();
										String responseDateTime = LocalDateTime.now()
												.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										int returnCode = CommonExecuteAPI.getRetCode();
										MLLogger.debug("ReturnCode from CPF Notify API: " + returnCode);

										if (returnCode == 202) {
											MLLogger.debug("CPF Notify API call successful for WINAME: " + wiName);
										} else {
											MLLogger.debug(
													"CPF Notify API call failed with return code: " + returnCode);
										}
										obj.insertIntoLogHistory(wiName, currentWs, reqDateTime, "onboard-notification",
												CommonExecuteAPI.uuid, requestJSON, responseJSON, responseDateTime, MLLogger);
									}
								} catch (Exception e) {
									MLLogger.debug("Exception during CPF Notify API call: " + e.getMessage());
								}

								// Api end
							}
						}

					}
				}
			}
		} catch (Exception e) {
			MLLogger.debug("Exception: " + e.getMessage());
		}

		return "";
	}

	private String newDelayedNotify2(String sessionID) {
		try {
			MLLogger.debug("Fetching all Workitems of all queue for FOL stat");
			String getWiQuery = "SELECT DISTINCT "
					+ "w.ProcessInstanceID, w.VAR_STR1, w.EntryDATETIME, r.Delay_comm, r.Tat_flag, w.WorkItemId ,"
					+ "(SELECT TOP 1 h1.ACTION_DATE_TIME " + "FROM USR_0_ML_WIHISTORY h1 "
					+ "WHERE h1.WI_NAME = w.ProcessInstanceID "
					+ "ORDER BY h1.ENTRY_DATE_TIME ASC) AS Earliest_Act_Date_Time " + "FROM WFINSTRUMENTTABLE w "
					+ "JOIN RB_ML_EXTTABLE r ON w.ProcessInstanceID = r.WINAME "
					+ "WHERE r.REQUEST_FOR = 'Final Offer Letter' " + "AND r.Tat_flag IN ('1','2') "
					+ "AND ((w.VAR_STR1 IN ('Credit','Initiator_Reject','CROPS_Maker','CROPS_Checker','CROPS_Document_Checker','CROPS_Disbursal_Maker','CROPS_Disbursal_Checker')) "
					+ "OR (w.VAR_STR1 = 'Sales_Attach_Documents' AND r.Waiting_for_Customer IS NULL))";
			String extTabDataIPXML = CommonMethods.apSelectWithColumnNames(getWiQuery, cabinetName, sessionID);
			String extTabDataOPXML = CommonMethods.WFNGExecute(extTabDataIPXML, jtsIP, jtsPort, 1);
			MLLogger.debug("log of extTabDataIPXML: " + extTabDataIPXML);
			XMLParser parser = new XMLParser(extTabDataOPXML);
			MLLogger.debug("log value of extTabDataOPXML: " + extTabDataOPXML);
			String mainCodeValue = parser.getValueOf("MainCode");
			MLLogger.debug("SmainCodeValueS-mainCodeValue: " + mainCodeValue);
			XMLParser subparser = new XMLParser();
			String wi_name = "";
			String currentWS = "";
			String DelayComm = "";
			String Entrydatetime = "";
			String formattedCurrentTime = "";
			String updateIPXML1 = "";
			String updateOPXML1 = "";
			String updateIPXML2 = "";
			String updateOPXML2 = "";
			String tatFlag = "";
			String tatFlagTime = "";
			String updateIPXML21 = "";
			String updateOPXML21 = "";
			String updateIPXML12 = "";
			String updateOPXML12 = "";
			String WorkItemID = "";
			int rows12 = 0;
			int rows21 = 0;
			int rows2 = 0;
			int rows1 = 0;
			int delayCommInt = 0;
			int totalHistTAT = 0;
			int totalTAT = 0;
			String getWiHistQuery = "";
			String extTabHistIPXML = "";
			String extTabHistOPXML = "";
			String mainHistValue = "";
			String tat = "";
			double totalHistTATDays = 0.0;
			double newTAT = 0.0;
			int iTotalrec = Integer.parseInt(parser.getValueOf("TotalRetrieved"));
			if ((parser.getValueOf("MainCode").equalsIgnoreCase("0") && iTotalrec > 0)) {
				MLLogger.debug("SmiTotalrecSnew-iTotalrec: " + iTotalrec);
				// start
				int noOfFields = parser.getNoOfFields("Record");
				if (!(noOfFields == 0)) {
					MLLogger.debug("noOfFields :: " + parser.getNoOfFields("Record"));

					int tothistrece = 0;
					int noOfHistFields = 0;
					long weekdayCount = 0;
					XMLParser histParser = null;
					for (int j = 0; j < noOfFields; j++) {
						// Iterating each Document under specific Document Index
						subparser = new XMLParser(parser.getNextValueOf("Record"));
						wi_name = subparser.getValueOf("ProcessInstanceID");
						currentWS = subparser.getValueOf("VAR_STR1");
						Entrydatetime = (String) subparser.getValueOf("EntryDATETIME");
						tatFlag = subparser.getValueOf("Tat_flag");
						tatFlagTime = (String) subparser.getValueOf("Earliest_Act_Date_Time");
						DelayComm = subparser.getValueOf("Delay_comm");
						WorkItemID = subparser.getValueOf("WorkItemId");
						MLLogger.debug("wi_name::" + wi_name);
						MLLogger.debug("WorkItemID::" + WorkItemID);
						MLLogger.debug("currentWS::" + currentWS);
						MLLogger.debug("DelayComm::" + DelayComm);
						MLLogger.debug("EntryDATETIME::" + Entrydatetime);
						MLLogger.debug("tatFlag::" + tatFlag);
						MLLogger.debug("ACT_dateTime as tatflagtime for flag 1::" + tatFlagTime);
						// start
						if (tatFlag.equalsIgnoreCase("1")) {
							if (tatFlagTime.contains(".")) {
								String[] parts = tatFlagTime.split("\\.");
								String millis = parts[1];
								while (millis.length() < 3) {
									millis += "0";
								}
								tatFlagTime = parts[0] + "." + millis;
								MLLogger.debug("EntryDATETIME:tatFlagTime:" + tatFlagTime);
							}
							DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
							LocalDateTime finalEntryDateTime = LocalDateTime.parse(tatFlagTime, format);

							MLLogger.debug("tatFlagTime entryDayTime final: " + finalEntryDateTime);

							LocalDateTime currentTime = LocalDateTime.now();
							formattedCurrentTime = currentTime.format(format);
							MLLogger.debug("CurrentTime : " + formattedCurrentTime);

							// Count only weekdays (Monday to Friday)
							weekdayCount = 0;
							LocalDateTime tempDate = finalEntryDateTime.toLocalDate().atStartOfDay();
							while (tempDate.isBefore(currentTime)) {
								DayOfWeek day = tempDate.getDayOfWeek();
								if (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY) {
									weekdayCount++;
								}
								tempDate = tempDate.plusDays(1);
							}
							MLLogger.debug("Weekdays between dates: " + weekdayCount);
							totalTAT = (int) weekdayCount;
							MLLogger.debug("totalTAT between dates in days: " + totalTAT);

						} else {
							if (Entrydatetime.contains(".")) {
								String[] parts = Entrydatetime.split("\\.");
								String millis = parts[1];
								while (millis.length() < 3) {
									millis += "0";
								}
								Entrydatetime = parts[0] + "." + millis;
							}

							getWiHistQuery = "select tat as TAT from USR_0_ML_WIHISTORY where WI_NAME = '" + wi_name
									+ "' and tat is not null";
							extTabHistIPXML = CommonMethods.apSelectWithColumnNames(getWiHistQuery, cabinetName,
									sessionID);
							MLLogger.debug("log of extTabHistIPXML: " + extTabHistIPXML);
							extTabHistOPXML = CommonMethods.WFNGExecute(extTabHistIPXML, jtsIP, jtsPort, 1);
							MLLogger.debug("log of extTabHistOPXML: " + extTabHistOPXML);
							histParser = new XMLParser(extTabHistOPXML);
							mainHistValue = histParser.getValueOf("MainCode");
							MLLogger.debug("SmainCodeValueS-mainHistValue: " + mainHistValue);
							tothistrece = Integer.parseInt(histParser.getValueOf("TotalRetrieved"));
							MLLogger.debug("tothistrece: " + tothistrece);
							if (histParser.getValueOf("MainCode").equalsIgnoreCase("0")) {
								noOfHistFields = histParser.getNoOfFields("Record");
								if (!(noOfHistFields == 0)) {
									totalHistTAT = 0;
									for (int i = 0; i < noOfHistFields; i++) {
										tat = histParser.getNextValueOf("TAT");
										MLLogger.debug("tatnew:: " + tat);
										totalHistTAT = totalHistTAT + Integer.parseInt(tat);
									}
								} else {
									totalHistTAT = 0;
								}

								MLLogger.debug("totalHistTAT:: " + totalHistTAT);

								totalHistTATDays = (double) totalHistTAT / 24;
								MLLogger.debug("totalHistTATDays: " + totalHistTATDays);

								DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
								LocalDateTime finalEntryDateTime = LocalDateTime.parse(Entrydatetime, format);

								MLLogger.debug("EntryDateTime entryDayTime final: " + finalEntryDateTime);

								LocalDateTime currentTime = LocalDateTime.now();
								formattedCurrentTime = currentTime.format(format);
								MLLogger.debug("CurrentTime: " + formattedCurrentTime);

								// Count only weekdays (Monday to Friday)
								weekdayCount = 0;
								LocalDateTime tempDate = finalEntryDateTime.toLocalDate().atStartOfDay();
								while (tempDate.isBefore(currentTime)) {
									DayOfWeek day = tempDate.getDayOfWeek();
									if (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY) {
										weekdayCount++;
									}
									tempDate = tempDate.plusDays(1);
								}

								MLLogger.debug("Weekdays between dates: " + weekdayCount);
								totalTAT = (int) (totalHistTATDays + weekdayCount);
								MLLogger.debug("totalTAT in days :: " + totalTAT);
							}
						}
						// end

						if (DelayComm == "NULL" || DelayComm == "" || DelayComm.equalsIgnoreCase("")) {
							MLLogger.debug("totalTAT in days :: " + totalTAT);
							if (totalTAT >= 14) {
								MLLogger.debug("inisde theweekdayCount totalTAT >= 14:DelayComm value " + DelayComm);
								updateIPXML1 = CommonMethods.apUpdateInput(cabinetName, sessionID, "RB_ML_EXTTABLE",
										"Delay_comm", "'1'", "WINAME = '" + wi_name + "'");
								MLLogger.debug("updateIPXML-eweekdayCountxtTabDataIPXML:Delayed " + updateIPXML1);
								updateOPXML1 = CommonMethods.WFNGExecute(updateIPXML1, jtsIP, jtsPort, 1);
								MLLogger.debug("updateOPXML--weekdayCountextTabDataOPXML:Delayed " + updateOPXML1);
								XMLParser xParserUpdate1 = new XMLParser(updateOPXML1);
								rows1 = Integer.parseInt(xParserUpdate1.getValueOf("Output"));
								if (rows1 == 1) {
									MLLogger.debug(
											"Updated DB Flag:weekdayCount Delayed inisde the totalTAT >= 14:value of row:"
													+ rows1);
								}

								updateIPXML12 = CommonMethods.apUpdateInput(cabinetName, sessionID, "WFINSTRUMENTTABLE",
										"VAR_STR15", "'Delayed'",
										"VAR_STR1='" + currentWS + "' AND ProcessInstanceID = '" + wi_name + "'");
								MLLogger.debug("updateIPXML12-eweekdayCountxtTabDataIPXML:Delayed " + updateIPXML12);
								updateOPXML12 = CommonMethods.WFNGExecute(updateIPXML12, jtsIP, jtsPort, 1);
								MLLogger.debug("updateOPXML12--weekdayCountextTabDataOPXML:Delayed " + updateOPXML12);
								XMLParser xParserUpdate12 = new XMLParser(updateOPXML12);
								rows12 = Integer.parseInt(xParserUpdate12.getValueOf("Output"));
								if (rows12 == 1) {
									MLLogger.debug(
											"Updated DB rows12 Flag:weekdayCount Delayed inisde the totalTAT >= 14:value of row:"
													+ rows12);
								}
								MLLogger.debug("inisde the weekdayCount >= 14 after update run: weekdayCount value:"
										+ weekdayCount);
								// Api start
								try {
									String getDataRes = getNotifyData(wi_name, WorkItemID);
									MLLogger.debug("getNotify Request Body totalTAT >= 14: " + getDataRes);

									if (!"Error".equalsIgnoreCase(getDataRes)) {
										String requestJSON = getDataRes;
										String reqDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										String responseJSON = CommonExecuteAPI.postOnboardAPI(postURL, requestJSON,
												authToken, MLLogger);
										MLLogger.debug("CPF Notify Response: " + responseJSON);

										JsonObject response = JsonParser.parseString(responseJSON).getAsJsonObject();
										String responseDateTime = LocalDateTime.now()
												.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										int returnCode = CommonExecuteAPI.getRetCode();
										MLLogger.debug("ReturnCode from CPF Notify API: " + returnCode);

										if (returnCode == 202) {
											MLLogger.debug("CPF Notify API call successful for WINAME: " + wi_name);
										} else {
											MLLogger.debug(
													"CPF Notify API call failed with return code: " + returnCode);
										}
										obj.insertIntoLogHistory(wi_name, currentWS, reqDateTime, "onboard-notification",
												CommonExecuteAPI.uuid, requestJSON, responseJSON, responseDateTime, MLLogger);
									}
								} catch (Exception e) {
									MLLogger.debug("Exception during CPF Notify API call: " + e.getMessage());
								}

								// Api end
							}
						} else {
							newTAT = 0.0;
							newTAT = totalTAT - ((Integer.parseInt(DelayComm) + 1) * 7);
							MLLogger.debug("newTAT else: " + newTAT);
							if (newTAT >= 7) {

								delayCommInt = Integer.parseInt(DelayComm);
								delayCommInt += 1;
								DelayComm = String.valueOf(delayCommInt);
								MLLogger.debug("inisde theweekdayCount weekdayCount >= 7DelayComm value " + DelayComm);
								updateIPXML2 = CommonMethods.apUpdateInput(cabinetName, sessionID, "RB_ML_EXTTABLE",
										"Delay_comm", " '" + DelayComm + "' ", "WINAME = '" + wi_name + "'");
								MLLogger.debug("updateIPXML-exweekday:Delayed " + updateIPXML2);
								updateOPXML2 = CommonMethods.WFNGExecute(updateIPXML2, jtsIP, jtsPort, 1);
								MLLogger.debug("updateOPXML-weekdayCount-:Delayed " + updateOPXML2);
								XMLParser xParserUpdate2 = new XMLParser(updateOPXML2);
								rows2 = Integer.parseInt(xParserUpdate2.getValueOf("Output"));
								if (rows2 == 1) {
									MLLogger.debug(
											"Updated DB Flag: Delayed inisde the weekdayCount >= 7 row 2:" + rows2);
								}

								updateIPXML21 = CommonMethods.apUpdateInput(cabinetName, sessionID, "WFINSTRUMENTTABLE",
										"VAR_STR15", "'Delayed'",
										"VAR_STR1='" + currentWS + "' AND ProcessInstanceID = '" + wi_name + "'");
								MLLogger.debug("updateIPXML21-Delayed " + updateIPXML21);
								updateOPXML21 = CommonMethods.WFNGExecute(updateIPXML21, jtsIP, jtsPort, 1);
								MLLogger.debug("updateOPXML21 Delayed : " + updateOPXML21);
								XMLParser xParserUpdate21 = new XMLParser(updateOPXML21);
								rows21 = Integer.parseInt(xParserUpdate21.getValueOf("Output"));
								if (rows21 == 1) {
									MLLogger.debug(
											"Updated DB Flag:rows21 Delayed inisde the weekdayCount >= 7:" + rows21);
								}
								MLLogger.debug("inisde the weekdayCount >= 7 weekdayCount value for update run:"
										+ weekdayCount);
								// Api start
								try {
									String getDataRes = getNotifyData(wi_name, WorkItemID);
									MLLogger.debug("getNotify Request Body weekdayCount >= 7: " + getDataRes);

									if (!"Error".equalsIgnoreCase(getDataRes)) {
										String requestJSON = getDataRes;
										String reqDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										String responseJSON = CommonExecuteAPI.postOnboardAPI(postURL, requestJSON,
												authToken, MLLogger);
										MLLogger.debug("CPF Notify Response: " + responseJSON);

										JsonObject response = JsonParser.parseString(responseJSON).getAsJsonObject();
										String responseDateTime = LocalDateTime.now()
												.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										int returnCode = CommonExecuteAPI.getRetCode();
										MLLogger.debug("ReturnCode from CPF Notify API: " + returnCode);

										if (returnCode == 202) {
											MLLogger.debug("CPF Notify API call successful for WINAME: " + wi_name);
										} else {
											MLLogger.debug(
													"CPF Notify API call failed with return code: " + returnCode);
										}
										obj.insertIntoLogHistory(wi_name, currentWS, reqDateTime, "onboard-notification",
												CommonExecuteAPI.uuid, requestJSON, responseJSON, responseDateTime, MLLogger);
									}
								} catch (Exception e) {
									MLLogger.debug("Exception during CPF Notify API call: " + e.getMessage());
								}

								// Api end
							}
						}

					}
				}
			}
		} catch (Exception e) {
			MLLogger.debug("Exception: " + e.getMessage());
		}

		return "";

	}
	// Shahid delay logic end- /29-09-2025

	protected void insertIntoDecHistory(String responseDateTime, String remarks, String decision, String wiName)
			throws IOException, Exception {
		String columnNames = "WINAME,Date_Time,WORKSTEP,USER_NAME,DECISION,REMARKS";
		String columnValues = "'" + wiName + "','" + responseDateTime + "','" + ws_name + "','"
				+ CommonConnection.getUsername() + "','" + decision + "','" + remarks + "'";

		String apInsertInputXML = CommonMethods.apInsert(cabinetName, CommonConnection.getSessionID(MLLogger, false),
				columnNames, columnValues, "USR_0_ML_WIHISTORY");
		MLLogger.debug("APInsertInputXML: " + apInsertInputXML);

		String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
		MLLogger.debug("APInsertOutputXML: " + apInsertOutputXML);

		XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
		String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
		MLLogger.debug("Status of apInsertMaincode  " + apInsertMaincode);
	}

	public static JsonArray getRecordsJsonArray(String xmlString) {
		JsonArray jsonArray = new JsonArray();
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			ByteArrayInputStream input = new ByteArrayInputStream(xmlString.getBytes("UTF-8"));
			Document doc = builder.parse(input);
			doc.getDocumentElement().normalize();
			NodeList recordNodes = doc.getElementsByTagName("Record");
			for (int i = 0; i < recordNodes.getLength(); i++) {
				Element recordElement = (Element) recordNodes.item(i);
				JsonObject jsonObject = new JsonObject();
				NodeList childNodes = recordElement.getChildNodes();
				for (int j = 0; j < childNodes.getLength(); j++) {
					Node child = childNodes.item(j);
					if (child.getNodeType() == Node.ELEMENT_NODE) {
						String key = child.getNodeName();
						String value = child.getTextContent().trim();
						jsonObject.addProperty(key, value);
					}
				}
				jsonArray.add(jsonObject);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonArray;
	}

	protected static void setNotifyStage(String notifyStage) {
		MLNotifyCPF.notifyStage = notifyStage;
	}

	private String PendingComm(String queueID, String sessionID) {
		try {
			MLLogger.debug("Fetching all Workitems on Initiator_Hold queue");

			String fetchWorkitemListInputXML = CommonMethods.fetchWorkItemsInput(cabinetName, sessionID, queueID);
			MLLogger.debug("InputXML for fetchWorkList Call: " + fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML = CommonMethods.WFNGExecute(fetchWorkitemListInputXML, jtsIP, jtsPort, 1);
			MLLogger.debug("WMFetchWorkList Initiator_Hold OutputXML: " + fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);
			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			MLLogger.debug("FetchWorkItemListMainCode: " + fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
			MLLogger.debug("RetrievedCount for WMFetchWorkList Call: " + fetchWorkitemListCount);
			System.out.println("Number of workitems retrieved on Initiator_Hold: " + fetchWorkitemListCount);

			String kongToken = CommonExecuteAPI.getAuthToken(MLLogger);
			MLLogger.debug("KongAuthToken: " + kongToken);
			authToken = kongToken;
			// authToken = getAuthToken(MLLogger);
			// MLLogger.debug("KongAuthToken: " + authToken);

			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0) {
				for (int i = 0; i < fetchWorkitemListCount; i++) {
					String fetchWorkItemlistData = xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData = fetchWorkItemlistData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

					MLLogger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: " + fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

					String processInstanceID = xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					MLLogger.debug("Current ProcessInstanceID: " + processInstanceID);

					String WorkItemID = xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					MLLogger.debug("Current WorkItemID: " + WorkItemID);
					String ActivityName = xmlParserfetchWorkItemData.getValueOf("ActivityName");
					MLLogger.debug("ActivityName: " + ActivityName);

					String ActivityID = xmlParserfetchWorkItemData.getValueOf("WorkStageId");
					MLLogger.debug("ActivityID: " + ActivityID);
					String ActivityType = xmlParserfetchWorkItemData.getValueOf("ActivityType");
					MLLogger.debug("ActivityType: " + ActivityType);

					String entryDateTimeStr = xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					MLLogger.debug("EntryDateTime: " + entryDateTimeStr);

					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
					LocalDateTime entryDateTime = LocalDateTime.parse(entryDateTimeStr, formatter);
					MLLogger.debug("EntryDateTime: " + entryDateTime);

					LocalDateTime currentTime = LocalDateTime.now();
					String formattedCurrentTime = currentTime.format(formatter);
					MLLogger.debug("CurrentTime: " + formattedCurrentTime);

					Duration duration = Duration.between(entryDateTime, currentTime);
					long millis = duration.toMillis();
					double diffInDays = millis / (1000.0 * 60 * 60 * 24);
					MLLogger.debug("Difference in days (fractional): " + diffInDays);

					String getDataRes = getNotifyData(processInstanceID, WorkItemID);
					MLLogger.debug("getNotify Request Body: " + getDataRes);

					String query = "SELECT Final_Offer_Letter_Signed FROM RB_ML_EXTTable WHERE WI_NAME='"
							+ processInstanceID + "'";
					String inputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
					String outputXML = CommonMethods.WFNGExecute(inputXML, jtsIP, jtsPort, 1);

					XMLParser parser = new XMLParser(outputXML);
					String mainCode = parser.getValueOf("MainCode");

					if ("0".equalsIgnoreCase(mainCode)) {
						int recordCount = Integer.parseInt(parser.getValueOf("TotalRetrieved"));

						for (int j = 0; j < recordCount; j++) {
							String folsigned = parser.getNextValueOf("Final_Offer_Letter_Signed");

							if (folsigned != null) {
								long roundedDays = Math.round(diffInDays);

								if ("Yes".equalsIgnoreCase(folsigned)) {
									if (roundedDays == 30 || roundedDays == 60) {
										MLLogger.debug(String.valueOf(roundedDays));
										String entryDate = entryDateTime
												.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										callCPFNotifyAPI(processInstanceID, WorkItemID, ActivityID, ActivityType,
												entryDate, ws_name, MLLogger, authToken, (int) roundedDays);

									} else if (roundedDays == 90) {
										MLLogger.debug("90");
										String entryDate = entryDateTime
												.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										callCPFNotifyAPI(processInstanceID, WorkItemID, ActivityID, ActivityType,
												entryDate, ws_name, MLLogger, authToken, (int) roundedDays);
										DoneWI(processInstanceID, WorkItemID, "Reject",
												"90 days on Initiator Hold completed", ActivityID, ActivityType,
												entryDate, ws_name, MLLogger);

									}
								} else if ("No".equalsIgnoreCase(folsigned)) {
									if (roundedDays == 3 || roundedDays == 6 || roundedDays == 9) {
										MLLogger.debug(String.valueOf(roundedDays));
										String entryDate = entryDateTime
												.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
										callCPFNotifyAPI(processInstanceID, WorkItemID, ActivityID, ActivityType,
												entryDate, ws_name, MLLogger, authToken, (int) roundedDays);

									} else if (roundedDays == 10) {
										DoneWI(processInstanceID, WorkItemID, "Reject",
												"10 days on Initiator Hold completed", ActivityID, ActivityType,
												entryDateTimeStr, "Ws_name", MLLogger);
									}
								}
							}
						}
					}
				}
			}

		} catch (Exception e) {
			MLLogger.debug("Exception: " + e.getMessage());
		}

		return "";
	}

	private void callCPFNotifyAPI(String processInstanceID, String WorkItemID, String ActivityID, String ActivityType,
			String entryDateTime, String ws_name, Logger MLLogger, String authToken, int roundedDays) {
		try {
			String getDataRes = getNotifyData(processInstanceID, WorkItemID);
			MLLogger.debug("getNotify Request Body: " + getDataRes);

			if (!"Error".equalsIgnoreCase(getDataRes)) {
				String requestJSON = getDataRes;
				String reqDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));

				String responseJSON = CommonExecuteAPI.postOnboardAPI(postURL, requestJSON, authToken, MLLogger);
				MLLogger.debug("CPF Notify Response: " + responseJSON);

				JsonObject response = JsonParser.parseString(responseJSON).getAsJsonObject();
				String responseDateTime = LocalDateTime.now()
						.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));

				int returnCode = CommonExecuteAPI.getRetCode();
				MLLogger.debug("ReturnCode from CPF Notify API: " + returnCode);

				if (returnCode == 202) {
					String notifyDay = "'" + roundedDays + "'";
					String updateDayXML = CommonMethods.apUpdateInput(cabinetName, sessionID, "RB_ML_EXTTABLE",
							"PendingComm_Flag", notifyDay, "WINAME = '" + processInstanceID + "'");

					MLLogger.debug("NotifyDay Update Request: " + updateDayXML);

					String updateDayOPXML = CommonMethods.WFNGExecute(updateDayXML, jtsIP, jtsPort, 1);
					MLLogger.debug("NotifyDay Update Response: " + updateDayOPXML);

					XMLParser xParserUpdate = new XMLParser(updateDayOPXML);
					int rows = Integer.parseInt(xParserUpdate.getValueOf("Output"));
					if (rows == 1) {
						MLLogger.debug("NotifyDay successfully updated for WINAME: " + processInstanceID);
					} else {
						MLLogger.debug("NotifyDay update failed for WINAME: " + processInstanceID);
					}
				}

			}
		} catch (Exception e) {
			MLLogger.debug("Exception during CPF Notify API call: " + e.getMessage());
		}
	}

}
