package com.newgen.ML;


import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonExecuteAPI;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.excp.NGException;

public class MLDocGenCPF extends MLMain {

	private static String cabinetName = "";
	private static String jtsIP = "";
	private static String jtsPort = "";
	final private static String ws_name = "Sys_Doc_Generate_CPF";
	Logger MLLogger;

	public MLDocGenCPF() throws NGException {

		MLLog.setLogger(getClass().getSimpleName());
		MLLogger = MLLog.getLogger(getClass().getSimpleName());
	}

	MLMain obj = new MLMain();

	protected void docGenCPF(String sessionID) {

		try {

			MLLog.setLogger(getClass().getSimpleName());
			String queueID = "";
			String apiResponse = "";
			String postURL = "";
			MLLogger.debug("Connecting to Cabinet.");

			cabinetName = CommonConnection.getCabinetName();
			MLLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			MLLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			MLLogger.debug("JTSPORT: " + jtsPort);

			queueID = MLMain.MLConfigParamMap.get("DocGenQueueID");
			MLLogger.debug("QueueID: " + queueID);

			postURL = MLMain.MLConfigParamMap.get("DocGenEndPoint");
			MLLogger.debug("Doc Upload URL: " + postURL);
			
			authURL = MLConfigParamMap.get("AuthURL");
			MLLogger.debug("KongAuthURL: " + authURL);
			
			authBody = MLConfigParamMap.get("AuthBody");
			MLLogger.debug("AuthBody: " + authBody);

			// sessionID = CommonConnection.getSessionID(MLLogger, false);

			if (sessionID.trim().equalsIgnoreCase("")) {
				MLLogger.debug("Could Not Connect to Server!");
				return;
			} else {
				MLLogger.debug("Session ID found: " + sessionID);
				if (sessionID == null || sessionID.trim().isEmpty()) {
				    MLLogger.debug("Session ID is empty, fetching new one.");
					sessionID = CommonConnection.getSessionID(MLLogger, false);
				}
				MLLogger.debug("Using Session ID: " + sessionID);

				MLLogger.debug("ML Doc Gen API to CPF ...123.");
				executeDocGenAPI(postURL, queueID, sessionID);
				MLLogger.debug("apiResponse : " + apiResponse);

			}
		} catch (Exception e) {
			MLLogger.error("Exception occured in docGenCPF: " + obj.customException(e));
		}

	}

	@SuppressWarnings("unchecked")
	private void executeDocGenAPI(String URL, String queueID, String sessionID) {

		try {
			// Fetch all Work-Items on given queueID.
			MLLogger.debug("Fetching all Workitems on awaitNotifyCPF queue");
			String fetchWorkitemListInputXML = CommonMethods.fetchWorkItemsInput(cabinetName, sessionID, queueID);
			MLLogger.debug("InputXML for fetchWorkList Call: " + fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML = CommonMethods.WFNGExecute(fetchWorkitemListInputXML, jtsIP, jtsPort, 1);

			MLLogger.debug("WMFetchWorkList DocGen CPF OutputXML: " + fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			MLLogger.debug("FetchWorkItemListMainCode: " + fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
			MLLogger.debug("RetrievedCount for WMFetchWorkList Call: " + fetchWorkitemListCount);

			MLLogger.debug("Number of workitems retrieved on DocGen CPF: " + fetchWorkitemListCount);

			System.out.println("Number of workitems retrieved on DocGen CPF: " + fetchWorkitemListCount);
			
			String authToken = CommonExecuteAPI.getAuthToken(MLLogger);
			MLLogger.debug("KongAuthToken: " + authToken);

			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0) {
				for (int i = 0; i < fetchWorkitemListCount; i++) {
					String fetchWorkItemlistData = xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData = fetchWorkItemlistData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

					MLLogger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: " + fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

					String processInstanceID = xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					MLLogger.debug("Current ProcessInstanceID: " + processInstanceID);

					MLLogger.debug("Processing Workitem: " + processInstanceID);
					System.out.println("\nProcessing Workitem: " + processInstanceID);

					String WorkItemID = xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					MLLogger.debug("Current WorkItemID: " + WorkItemID);

					String entryDateTime = xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					MLLogger.debug("Current EntryDateTime: " + entryDateTime);

					String ActivityName = xmlParserfetchWorkItemData.getValueOf("ActivityName");
					MLLogger.debug("ActivityName: " + ActivityName);

					String ActivityID = xmlParserfetchWorkItemData.getValueOf("WorkStageId");
					MLLogger.debug("ActivityID: " + ActivityID);
					String ActivityType = xmlParserfetchWorkItemData.getValueOf("ActivityType");
					MLLogger.debug("ActivityType: " + ActivityType);
					String ProcessDefId = xmlParserfetchWorkItemData.getValueOf("RouteId");
					MLLogger.debug("ProcessDefId: " + ProcessDefId);
					
					
					String DBQuery = "select e.ITEMINDEX,e.CIF,e.ACCOUNT_NUMBER,e.CASE_TYPE,e.CPF_Missing_Doc,e.ISLAMIC_OR_CONVENTIONAL,"
							+ "e.AGREEMENT_NUMBER,e.Place_of_Issue,wf.VAR_STR15 as NotifyStage from RB_ML_EXTTABLE e WITH(nolock) INNER JOIN WFINSTRUMENTTABLE wf WITH(nolock)"
							+ "on wf.ProcessInstanceID = e.WINAME where e.WINAME='"+processInstanceID+"' and wf.WorkItemId='"+WorkItemID+"'";
					String extTabDataIPXML = CommonMethods.apSelectWithColumnNames(DBQuery, cabinetName,sessionID);
							
					MLLogger.debug("extTabDataIPXML: " + extTabDataIPXML);
					String extTabDataOPXML = CommonMethods.WFNGExecute(extTabDataIPXML, jtsIP, jtsPort, 1);
					MLLogger.debug("extTabDataOPXML: " + extTabDataOPXML);

					XMLParser xmlParserData = new XMLParser(extTabDataOPXML);
					int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));				
					
					String userQuery = "select top 1 UserName,PersonalName from PDBUser WITH(nolock) where username IN (select User_Name from USR_0_ML_WIHISTORY WITH(nolock) where "
							+ "Workstep='Credit' and wi_name ='"+processInstanceID+"' and (Decision = 'Approve'))";
					String userIPXML = CommonMethods.apSelectWithColumnNames(userQuery, cabinetName,sessionID);
						
					MLLogger.debug("userIPXML: " + userIPXML);
					String userOPXML = CommonMethods.WFNGExecute(userIPXML, jtsIP, jtsPort, 1);
					MLLogger.debug("userOPXML: " + userOPXML);

					XMLParser userXmlParser = new XMLParser(userOPXML);
					String creditOfficerID = "";
					String creditOfficerName = "";
					int totalRet = Integer.parseInt(userXmlParser.getValueOf("TotalRetrieved"));
					if (userXmlParser.getValueOf("MainCode").equalsIgnoreCase("0") && totalRet > 0) {
						creditOfficerID = userXmlParser.getValueOf("UserName").trim();
						creditOfficerName = userXmlParser.getValueOf("PersonalName").trim();
					}
					
					MLLogger.debug("creditOfficerID: " + creditOfficerID);
					MLLogger.debug("creditOfficerName: " + creditOfficerName);
					
					Gson gson = new GsonBuilder().setPrettyPrinting().create();
					JsonObject subReqBody = new JsonObject();
					String requestJSON = "";
					String responseJSON = "";
					String reqDateTime ="";
					String responseDateTime="";
					

					if (xmlParserData.getValueOf("MainCode").equalsIgnoreCase("0") && iTotalrec > 0) {

						
						String subProdType = "";
						subProdType = xmlParserData.getValueOf("CASE_TYPE").trim();
						String custType = null;
						if ("Islamic".equalsIgnoreCase(xmlParserData.getValueOf("ISLAMIC_OR_CONVENTIONAL"))) {
							custType = "I";
						} else if ("Conventional".equalsIgnoreCase(xmlParserData.getValueOf("ISLAMIC_OR_CONVENTIONAL"))) {
							custType = "C";
						}

						subReqBody.addProperty("workItemId", processInstanceID);
						subReqBody.addProperty("cifId", xmlParserData.getValueOf("CIF").trim());
						subReqBody.addProperty("accountId", xmlParserData.getValueOf("ACCOUNT_NUMBER").trim());
						subReqBody.addProperty("agreementId", xmlParserData.getValueOf("AGREEMENT_NUMBER").trim());
						subReqBody.addProperty("processName","Mortgage Loan");
						subReqBody.addProperty("subProcessName","ML_CPF");
						subReqBody.addProperty("productType", "Mortgage Loan");
						subReqBody.addProperty("subProductType", subProdType);
						subReqBody.addProperty("folderIndex", xmlParserData.getValueOf("ITEMINDEX").trim());
						subReqBody.addProperty("creditOfficerId", creditOfficerID);
						subReqBody.addProperty("creditOfficerName", creditOfficerName);
						subReqBody.addProperty("crossSell","N");
						subReqBody.addProperty("custType", custType);
						subReqBody.addProperty("placeOfIssue",xmlParserData.getValueOf("Place_of_Issue"));

						String cpfDocs = xmlParserData.getValueOf("CPF_Missing_Doc");
						MLLogger.debug("cpfDocsList: " + cpfDocs);
						try {
							if (cpfDocs.length() != 0) {
								String[] docArr = cpfDocs.split(",");
								MLLogger.debug("cpfDocsArr: " + Arrays.toString(docArr));
								JsonArray docs = new JsonArray();
								for (int j = 0; j < docArr.length; j++) {
									JsonObject docObj = new JsonObject();
									docObj.addProperty("type", docArr[j].trim());
									docs.add(docObj);
								}

								subReqBody.add("documents", docs);
								MLLogger.debug("Final Req JSON: " + gson.toJson(subReqBody));
								requestJSON = gson.toJson(subReqBody);
								
								reqDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
							}
						} catch (Exception e) {
							MLLogger.error("Exception occured in fetching CPF Missing docs: " + obj.customException(e));
						}
					}

					JsonObject response = null;
					int returnCode=0;
					try {
						responseJSON = CommonExecuteAPI.postOnboardAPI(URL, requestJSON, authToken, MLLogger);
						returnCode = CommonExecuteAPI.getRetCode();
						responseDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
						response = JsonParser.parseString(responseJSON).getAsJsonObject();
						if(returnCode>=500) {
							MLLogger.debug("Response from CPF Doc API: " + responseJSON);
							MLLogger.debug("ReturnCode from CPF Doc API: " + returnCode);	
						}
						else {
							JsonObject errRes = new JsonObject();
							errRes.addProperty("ErrCode", returnCode);
							errRes.addProperty("raw_response", responseJSON.toString());
						}
					} catch (Exception e) {
						MLLogger.error("Exception occured in POST CPF Onboard Docs API: " + obj.customException(e));
					}
					
					if(returnCode==201) {
						MLLogger.debug("ReturnCode: " + returnCode);	
						obj.DoneWI(processInstanceID, WorkItemID, "Success", "CPF Document Call Successfull", ActivityID, ActivityType,entryDateTime, ws_name, MLLogger);
					}
					else {
						JsonArray errorArr = response.getAsJsonArray("errors");
						String description = errorArr.get(0).getAsJsonObject().get("message").getAsString().replace("'", "''");
						MLLogger.debug("description: " + description);
						obj.DoneWI(processInstanceID, WorkItemID, "Failure", "Error: "+description, ActivityID, ActivityType,entryDateTime, ws_name, MLLogger);
					}
					
					obj.insertIntoLogHistory(processInstanceID, ws_name, reqDateTime, "onboarding-documents", CommonExecuteAPI.uuid, requestJSON, responseJSON, responseDateTime, MLLogger);
					
				}
			}

		} catch (Exception e)

		{
			MLLogger.error("Exception occured in executeDocGenAPI method: " + obj.customException(e));
		}

	}

}
