package com.newgen.ML;

import org.apache.log4j.Logger;
import java.io.*;
import java.util.Base64;
import java.util.Date;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.*;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonExecuteAPI;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.excp.NGException;

import ISPack.CImageServer;
import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;
import Jdts.DataObject.JPDBString;

public class MLDocStamping extends MLMain {

	private static String sID = "";
	private static String cabinetName = "";
	private static String jtsIP = "";
	private static String jtsPort = "";
	private static String URL = "";
	final private static String ws_name = "Sys_Doc_Stamping";
	Logger MLLogger;

	public MLDocStamping() throws NGException {

		MLLog.setLogger(getClass().getSimpleName());
		MLLogger = MLLog.getLogger(getClass().getSimpleName());
	}

	MLMain obj = new MLMain();

	protected void docStamp(String sessionID) {

		try {

			MLLog.setLogger(getClass().getSimpleName());
			String queueID = "";

			MLLogger.debug("Connecting to Cabinet.");

			cabinetName = CommonConnection.getCabinetName();
			MLLogger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			MLLogger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			MLLogger.debug("JTSPORT: " + jtsPort);

			queueID = MLMain.MLConfigParamMap.get("DocStampingQueueID");
			MLLogger.debug("QueueID: " + queueID);
			
			URL = MLMain.MLConfigParamMap.get("ODURL");
			MLLogger.debug("OD URL: " + URL);

			sID = CommonConnection.getSessionID(MLLogger, false);

			if (sID.trim().equalsIgnoreCase("")) {
				MLLogger.debug("Could Not Connect to Server!");
				return;
			} else {
				MLLogger.debug("Session ID found: " + sID);

				MLLogger.debug("ML Doc Gen API to CPF ...123.");
				processStamping(queueID, sID);

			}
		} catch (Exception e) {
			MLLogger.debug("Exception occured in AwaitCPF: " + obj.customException(e));
		}

	}

	private void processStamping(String queueID, String sessionID) {

		try {

			// Fetch all Work-Items on given queueID.
			MLLogger.debug("Fetching all Workitems on awaitNotifyCPF queue");
			String fetchWorkitemListInputXML = CommonMethods.fetchWorkItemsInput(cabinetName, sessionID, queueID);
			MLLogger.debug("InputXML for fetchWorkList Call: " + fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML = CommonMethods.WFNGExecute(fetchWorkitemListInputXML, jtsIP, jtsPort, 1);

			MLLogger.debug("WMFetchWorkList DocGen CPF OutputXML: " + fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			MLLogger.debug("FetchWorkItemListMainCode: " + fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
			MLLogger.debug("RetrievedCount for WMFetchWorkList Call: " + fetchWorkitemListCount);

			MLLogger.debug("Number of workitems retrieved on DocStamping CPF: " + fetchWorkitemListCount);

			System.out.println("Number of workitems retrieved on DocStamping CPF: " + fetchWorkitemListCount);
			

			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0) {
				for (int i = 0; i < fetchWorkitemListCount; i++) {
					String fetchWorkItemlistData = xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData = fetchWorkItemlistData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

					MLLogger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: " + fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

					String processInstanceID = xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					MLLogger.debug("Current ProcessInstanceID: " + processInstanceID);

					MLLogger.debug("Processing Workitem: " + processInstanceID);
					System.out.println("\nProcessing Workitem: " + processInstanceID);

					String WorkItemID = xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					MLLogger.debug("Current WorkItemID: " + WorkItemID);

					String entryDateTime = xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					MLLogger.debug("Current EntryDateTime: " + entryDateTime);

					String ActivityName = xmlParserfetchWorkItemData.getValueOf("ActivityName");
					MLLogger.debug("ActivityName: " + ActivityName);

					String ActivityID = xmlParserfetchWorkItemData.getValueOf("WorkStageId");
					MLLogger.debug("ActivityID: " + ActivityID);
					String ActivityType = xmlParserfetchWorkItemData.getValueOf("ActivityType");
					MLLogger.debug("ActivityType: " + ActivityType);
					String ProcessDefId = xmlParserfetchWorkItemData.getValueOf("RouteId");
					MLLogger.debug("ProcessDefId: " + ProcessDefId);

					String decision = "";
					String decRemarks = "";
					String imageIndex = "";
					String docQuery = "select Name,DocumentIndex,ImageIndex from PDBDocument WITH(nolock) where DocumentIndex in "
							+ "(select DocumentIndex from PDBDocumentContent WITH(nolock) where ParentFolderIndex="
							+ "(select FolderIndex from PDBFolder WITH(nolock) where name='"+processInstanceID+"')) "
							+ "and name in ('Assessment and Suitability ML')";
					
					String extTabDataIPXML = CommonMethods.apSelectWithColumnNames(docQuery, cabinetName, sID);
					MLLogger.debug("extTabDataIPXML: " + extTabDataIPXML);
					String extTabDataOPXML = CommonMethods.WFNGExecute(extTabDataIPXML, jtsIP, jtsPort, 1);
					MLLogger.debug("extTabDataOPXML: " + extTabDataOPXML);

					XMLParser xmlParserData = new XMLParser(extTabDataOPXML);
					NGXmlList objWorkList=xmlParserData.createList("Records", "Record");
					String docName="";
					String docIndex="";
					int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));

					if (xmlParserData.getValueOf("MainCode").equalsIgnoreCase("0") && iTotalrec > 0) {
						for (; objWorkList.hasMoreElements(true); objWorkList.skip(true))
						{	
							docName = objWorkList.getVal("Name");
							docIndex = objWorkList.getVal("DocumentIndex");					
							imageIndex = objWorkList.getVal("ImageIndex");
						
						try {
							String folDir = System.getProperty("user.dir") + File.separator + "StampedDocs" 
									+ File.separator +"ML_StampedDocuments"+ File.separator + processInstanceID;
							File fl = new File(folDir);
							if(!fl.exists()) fl.mkdirs();
							
							String dest = folDir + File.separator +  docName + ".pdf";
							String destSigned = folDir + File.separator + docName + "_Signed.pdf";
							callCPIS(dest,imageIndex);
				            consentStamp(processInstanceID, dest, destSigned);
				            addDocMT(sID, processInstanceID, docName, destSigned);
				            decision ="Success";
				            decRemarks="Document Stamped";
				        } catch (Exception e) {
				        	MLLogger.error("Exception occured in processStamping Method: " + obj.customException(e));
				        	decision = "Failure";
				        	decRemarks="Document Stamping Failed";
				        }
						catch (JPISException e) {
							MLLogger.error("Exception occured due to AddDoc_MT");
							e.printStackTrace();
							decision = "Failure";
							decRemarks="Document Stamping Failed";
				        }
					}
						obj.DoneWI(processInstanceID, WorkItemID, decision, decRemarks, ActivityID, ActivityType,entryDateTime, ws_name, MLLogger);
					}
					
				}
			}

		} catch (Exception e)

		{
			MLLogger.debug("Exception occured in emailAwaitStatus method: " + obj.customException(e));
		}
	}

	private String addDocMT(String sessionID, String processInstanceID, String docName, String destSigned)
			throws JPISException, IOException, Exception {
		String attachDocOP = "";
		JPISIsIndex ISINDEX = new JPISIsIndex();
		JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
		CPISDocumentTxn.AddDocument_MT(null, jtsIP, Short.parseShort(CommonConnection.getsSMSPort()), cabinetName,
				Short.parseShort(CommonConnection.getsVolumeID()), destSigned, JPISDEC, "", ISINDEX);
		MLLogger.debug("After add document mt successful: ");
		String sISIndex = ISINDEX.m_nDocIndex + "#" + ISINDEX.m_sVolumeId;
		MLLogger.debug(" sISIndex: " + sISIndex);
		String DocumentType = "N";
		String strDocumentName = docName + " Signed";
		String strExtension = "pdf";

		File file = new File(destSigned);
		long lLngFileSize = 0L;
		lLngFileSize = file.length();
		String lstrDocFileSize = Long.toString(lLngFileSize);

		String sMappedInputXml = CommonMethods.getNGOAddDocument(getFolderIndex(processInstanceID), strDocumentName,
				DocumentType, strExtension, sISIndex, lstrDocFileSize, CommonConnection.getsVolumeID(), cabinetName, sessionID);
		MLLogger.debug("sMappedInputXml " + sMappedInputXml);

		String sOutputXml = CommonMethods.WFNGExecute(sMappedInputXml, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(),
				1);
		sOutputXml = sOutputXml.replace("<Document>", "");
		sOutputXml = sOutputXml.replace("</Document>", "");
		MLLogger.debug(" Output xml For NGOAddDocument Call: " + sOutputXml);

		attachDocOP = CommonMethods.getTagValues(sOutputXml, "Status");
		MLLogger.debug("attachDocOP: " + attachDocOP);
		return attachDocOP;
	}

	private void consentStamp(String processInstanceID, String src, String dest)
			throws IOException, FileNotFoundException, DocumentException {
		PdfReader reader = new PdfReader(new FileInputStream(src));
		PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(dest));
		
		//PdfPTable table = new PdfPTable(2);
		//table.setTotalWidth(400);
		//table.setLockedWidth(true);
		
		//Font tableFont = new Font(Font.FontFamily.HELVETICA,12);
		
		Paragraph paragraph = new Paragraph("Consent Date: " + getConsentDate(processInstanceID));
//		table.addCell(new Phrase("Consent Date",tableFont));
//		table.addCell(new Phrase(getConsentDate(processInstanceID),tableFont));
		
		PdfContentByte canvas = stamper.getOverContent(1);
		ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, paragraph, 36, 36, 0);
//		table.writeSelectedRows(0, -1, 50, 200, canvas);

		stamper.close();
		reader.close();

		MLLogger.debug("Table stamped successfully.");
	}
	
	protected String getConsentDate(String processInstanceID){
		try {
			String query="SELECT Date_and_Time FROM RB_ML_EXTTABLE WITH(nolock) WHERE WINAME='"+processInstanceID+"'";
			String sInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
			MLLogger.debug("Get Consent Date InputXML = "+sInputXML);
			String sOutputXML = CommonMethods.WFNGExecute(sInputXML, jtsIP, jtsPort, 0 );
			MLLogger.debug("Get Consent Date OutputXML = "+sOutputXML);
			XMLParser objXMLParser = new XMLParser(); 
			objXMLParser.setInputXML(sOutputXML);
			String MaincodeTemp=objXMLParser.getValueOf("MainCode");
			MLLogger.debug("Get Consent Date MainCode = "+MaincodeTemp);
			String RecordCount = objXMLParser.getValueOf("TotalRetrieved");
			String Date_and_Time = "";
			if("0".equalsIgnoreCase(MaincodeTemp) && Integer.parseInt(RecordCount)>0)
			{
				Date_and_Time = objXMLParser.getValueOf("Date_and_Time").substring(0,10);
			}
			return Date_and_Time;
		} catch (Exception e) {
			MLLogger.error("Exception in getConsentDate: " + obj.customException(e));
		}
		return "";
	}
	
	 public String getFolderIndex(String WINo)
		{
			String parentFolderIndex="";
			XMLParser objXMLParser = new XMLParser();
			String sInputXML="";
			String sOutputXML="";
			String RecordCount="";
			

			try
			{
				String query="SELECT ItemIndex FROM RB_ML_EXTTABLE WITH(nolock) WHERE WINAME='"+WINo+"'";
				sInputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
				MLLogger.debug("Get FolderIndex InputXML = "+sInputXML);
				sOutputXML = CommonMethods.WFNGExecute(sInputXML, jtsIP, jtsPort, 0 );
				MLLogger.debug("Get FolderIndex OutputXML = "+sOutputXML);
				objXMLParser.setInputXML(sOutputXML);
				String MaincodeTemp=objXMLParser.getValueOf("MainCode");
				MLLogger.debug("Get FolderIndex MainCode = "+MaincodeTemp);
				RecordCount=objXMLParser.getValueOf("TotalRetrieved");
				if("0".equalsIgnoreCase(MaincodeTemp) && Integer.parseInt(RecordCount)>0)
				{
					parentFolderIndex=objXMLParser.getValueOf("ItemIndex");
				}
					
			}
			catch(Exception e)
			{
				MLLogger.error("Exception in getFolderIndex..." + obj.customException(e));
				
			}
			
		
			
			return parentFolderIndex;
		}
	 
	 protected void callCPIS(String path, String imageIndex) {
			String nextFlePath = path;
			String c_Site = "1";
			CImageServer cImageServer=null;
			String jtsIP=CommonConnection.getJTSIP();
			String jtsPort=CommonConnection.getJTSPort();
			String cabinetName=CommonConnection.getCabinetName();
			String volID=CommonConnection.getsVolumeID();
			try 
			{
				cImageServer = new CImageServer(null, CommonConnection.getJTSIP(), Short.parseShort(CommonConnection.getJTSPort()));
			}
			catch (JPISException e) 
			{
				e.printStackTrace();
			}
			
//			nextFlePath=nextFlePath+File.separator+Name+"-"+DocumentIndex+"."+AppName;
//			OmniflowMigration_log.OmniflowMigration.debug("values passed -> "+ ofjtsIP+" "+ofjtsPort+" "+ofCabinetName+" "
//			+VolumeId+" "+c_Site+" "+ImageIndex+" "+nextFlePath.toString());
			

			MLLogger.debug("Fetching OD Download Code ::::::");
			
			MLLogger.debug("value apssed in donwload document :jtsIP :"+jtsIP+"jtsPort: "+ jtsPort+
					" cabinetName: "+cabinetName +"c_Site: "+ c_Site+"VolumeId: "+volID +":"+"ImageIndex:"+imageIndex +"nextFlePath :"+nextFlePath);
			int odDownloadCode;
			odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,jtsIP, Short.parseShort(jtsPort), cabinetName, Short.parseShort(c_Site),Short.parseShort(volID), Integer.parseInt(imageIndex),"",nextFlePath.toString(), new JPDBString());
			
			MLLogger.debug("OD Download Code :"+odDownloadCode);
		}

}
