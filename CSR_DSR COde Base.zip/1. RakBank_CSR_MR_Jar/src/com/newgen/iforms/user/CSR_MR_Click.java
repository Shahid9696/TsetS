package com.newgen.iforms.user;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.iforms.custom.IFormReference;

import netscape.javascript.JSObject;

public class CSR_MR_Click extends CSR_MRCommon{

	HashMap CAPDataHT = new HashMap();
	public String clickEvent(IFormReference iform, String controlName, String data) {
		
		String strReturn = "";
		try {
	
			CSR_MR.mLogger.debug("inside CSR_MR_click, controlName: "+controlName);
			if (controlName.equalsIgnoreCase("CAPSMAIN_Query")) {
				
				//String credit = ((String) iform.getValue("CreditCardNo1")).replaceAll("-", "");
				//String value1 = validateCCNo(credit);
				String sSQL = "";
				Connection conn = null;
				Statement stmt = null;
				//Statement stmt1 = null;
				// PreparedStatement stmt=null;
				ResultSet result = null;
				ResultSet result1 = null;
				
				try {
	
					String actname = iform.getActivityName();
					String credit = ((String) iform.getValue("CreditCardNo1")).replaceAll("-", "");
		
					String value1 = validateCCNo(credit);
					if (value1.equalsIgnoreCase("ValidCard")) {
						// CSR_OCC.mLogger.debug(actname);
						CSR_MR.mLogger.debug("inside CSR_MR_click credit" + credit);
		
						Context aContext = new InitialContext();
						DataSource aDataSource = (DataSource) aContext.lookup("jdbc/cbop");
						conn = (Connection) (aDataSource.getConnection());
						CSR_MR.mLogger.debug("got data source");
						// stmt = conn.createStatement();
		
						sSQL = "Select LTRIM(RTRIM(FirstName)), LTRIM(RTRIM(MiddleName)), LTRIM(RTRIM(LastName)), "
								+ "substr(to_char(EXPIRYDATE,'dd/mm/yy'),4,length(to_char(EXPIRYDATE,'dd/mm/yy'))), "
								+ "CRNNO, MOBILE,ASSESSEDINCOME,CARDTYPE,generalstat,elitecustomerno  from CAPSMAIN where "
								+ "CREDITCARDNO='" + credit + "'";
		
			
						stmt = conn.createStatement();
						// stmt = conn.prepareStatement(sSQL);
						CSR_MR.mLogger.debug("sSQL ::" + sSQL);
		
						result = stmt.executeQuery(sSQL);
						CSR_MR.mLogger.debug("result stmt::" + result);
						CSR_MR.mLogger.debug("lstDecisions size" + result.getFetchSize());
						if (result.getFetchSize() != 0) {
							String value = "";
							String CRNNO = "";
							String MOBILE = "";
							String ASSESSEDINCOME = "";
							String CARDTYPE = "";
							String generalstat = "";
							String elitecustomerno = "";
							String MiddleName = "";
							String LastName = "";
							String ExpD = "";
		
							iform.clearCombo("CCI_CName");
							iform.clearCombo("CCI_ExpD");
							iform.clearCombo("CCI_CCRNNo");
							iform.clearCombo("CCI_MONO");
							iform.clearCombo("CCI_AccInc");
							iform.clearCombo("CCI_CT");
							iform.clearCombo("CCI_CAPS_GENSTAT");
							iform.clearCombo("CCI_ELITECUSTNO");
							iform.clearCombo("CCI_CrdtCN");
		
							while (result.next()) {
								value = result.getString(1);
								CSR_MR.mLogger.debug("value size" + value);
								MiddleName = result.getString(2);
								LastName = result.getString(3);
								// sCustomerName=sFirstName+" "+sMiddleName+" "+sLastName;
								ExpD = result.getString(4);
								CRNNO = result.getString(5);
								MOBILE = result.getString(6);
								ASSESSEDINCOME = new Integer(result.getInt(7)).toString();
								CARDTYPE = result.getString(8);
								generalstat = result.getString(9);
								CSR_MR.mLogger.debug("generalstat size" + generalstat);
								elitecustomerno = result.getString(10);
								CSR_MR.mLogger.debug("elitecustomerno size" + elitecustomerno);
		
								// iform.addItemInCombo("BTD_OBC_BN",value,value);
								iform.setValue("CCI_CName", value + " " + MiddleName + " " + LastName);
								iform.setValue("CCI_ExpD", ExpD);
								iform.setValue("CCI_ExpD", "Masked");
								iform.setValue("CCI_CCRNNo", CRNNO);
								iform.setValue("CCI_MONO", MOBILE);
								iform.setValue("CCI_AccInc", ASSESSEDINCOME);
								iform.setValue("CCI_CT", CARDTYPE);
								iform.setValue("CCI_CAPS_GENSTAT", generalstat);
								iform.setValue("CCI_ELITECUSTNO", elitecustomerno);
								iform.setValue("CCI_CrdtCN", credit);
								strReturn = "Fetch Card Details successfully";
							}
		
											} else {
							strReturn = "Given Card Details is not Present";
						}
		
					} else {
						strReturn = "Invalid Crad Number format";
					}
					if (result != null) {
						result.close();
						result = null;
						CSR_MR.mLogger.debug("resultset Successfully closed");
					}
					if (stmt != null) {
						stmt.close();
						stmt = null;
						CSR_MR.mLogger.debug("Stmt Successfully closed");
					}
					if (conn != null) {
						conn.close();
//						conn = null;
						CSR_MR.mLogger.debug("Conn Successfully closed");
					}
				}catch (java.sql.SQLException e) {
					CSR_MR.mLogger.debug(e.toString());
					if (e.getClass().toString().equalsIgnoreCase("Class javax.naming.NameNotFoundException"))
						CSR_MR.mLogger.debug("<script>alert(\"Data Source For CAPS System Not Found\")</script>");
			
					else if (e.toString().indexOf("Operation timed out: connect:could be due to invalid address") != -1)
						CSR_MR.mLogger.debug("<script>alert(\"Unable to connect to CAPS System\")</script>");
			
					else {
						CSR_MR.mLogger.debug("<script>alert(\"Unable to connect to CAPS System\")</script>");
					}
			
				}
			} 
			else if (controlName.equalsIgnoreCase("PrintButton")) {
				
	
				 Object localJSObject = "";
				 CSR_MR.mLogger.debug("Print Button inside");
				 CSR_MR.mLogger.debug("localJSObject ::"+localJSObject.toString());
				String str2 = "";
				String str3 = "";
				String str4 = "";
				str2 = ((String) iform.getValue("Cards_Remarks")).replace("&", "ampersand");
				str2 = str2.replace("=", "equalsopt");
				str2 = str2.replace("%", "percentageopt");
				//str3 = ((String) iform.getValue("BA_REMARKS")).replace("&", "ampersand");
				str4 = ((String) iform.getValue("REMARKS")).replace("&", "ampersand");
				str4 = str4.replace("=", "equalsopt");
				str4 = str4.replace("%", "percentageopt");
				CSR_MR.mLogger.debug("arrayOfString ::"+str2+ " "+ str3 + " "+str4);
				String[] arrayOfString = new String[1];
				 arrayOfString[0] = ("CCI_CrdtCN=" +
				 ((String)iform.getValue("CCI_CrdtCN")) + "&" + "CCI_CName="
				 + ((String)iform.getValue("CCI_CName")) + "&" + "CCI_ExpD="
				 + ((String)iform.getValue("CCI_ExpD")) + "&" + "CCI_CCRNNo="
				 + ((String)iform.getValue("CCI_CCRNNo")) + "&" + "CCI_ExtNo=" +
				 ((String)iform.getValue("CCI_ExtNo")) + "&" + "CCI_SC=" +
				 ((String)iform.getValue("CCI_SC")) + "&" + "CCI_MONO=" +
				 ((String)iform.getValue("CCI_MONO")) + "&" + "CCI_AccInc=" +
				 ((String)iform.getValue("CCI_AccInc")) + "&" + "CCI_CAPS_GENSTAT=" +
				 ((String)iform.getValue("CCI_CAPS_GENSTAT")) + "&" +
				 "CCI_ELITECUSTNO=" + ((String)iform.getValue("CCI_ELITECUSTNO")) + "&"
				 + "CCI_CT=" + ((String)iform.getValue("CCI_CT")) + "&" +
				 "VD_TINCheck=" + ((String)iform.getValue("VD_TINCheck")) + "&" +
				 "VD_MoMaidN=" + ((String)iform.getValue("VD_MoMaidN")) + "&" + "VD_DOB=" +
				 ((String)iform.getValue("VD_DOB")) + "&" + "VD_StaffId=" +
				 ((String)iform.getValue("VD_StaffId")) + "&" + "VD_PassNo=" +
				 ((String)iform.getValue("VD_PassNo")) + "&" + "VD_POBox=" +
				 ((String)iform.getValue("VD_POBox")) + "&" + "VD_Oth=" +
				 ((String)iform.getValue("VD_Oth")) + "&" + "VD_MRT=" +
				 ((String)iform.getValue("VD_MRT")) + "&" + "VD_EDC=" +
				 ((String)iform.getValue("VD_EDC")) + "&" + "VD_NOSC=" +
				 ((String)iform.getValue("VD_NOSC")) + "&" + "VD_TELNO=" +
				 ((String)iform.getValue("VD_TELNO")) + "&" + "VD_SD=" +
				 ((String)iform.getValue("VD_SD")) + "&" + "wi_name=" +
				 ((String)iform.getValue("wi_name")) + "&" + "processname=CSR_MR" + "&"
				 //+ "IntroductionDateTime=" + localXMLParser.getValueOf("CreatedDateTime")) + "&" 
				 + "IntroductionDateTime=" + (String)iform.getValue("CreatedDateTime")+ "&" + "BU_UserName=" + (String)iform.getValue("IntroducedBy")+ "&"
				 + "Cards_Decision=" + ((String)iform.getValue("Cards_Decision")) + "&"
				 + "Cards_Remarks=" + str2 + "&" +
				 "REMARKS=" + str4);
				 CSR_MR.mLogger.debug("arrayOfString ::"+arrayOfString[0]);
				 localJSObject = arrayOfString[0];
				 CSR_MR.mLogger.debug("localJSObject ::"+localJSObject.toString());
				// ((JSObject) localJSObject).call("callPrintJSPCSRBT", arrayOfString);
				 CSR_MR.mLogger.debug("localJSObject ::"+localJSObject.toString());
				 strReturn = localJSObject.toString();
				 
				 
			}
			else if (controlName.equalsIgnoreCase("VD_TINCheck")) 
			{
				String msg = "";
				if (iform.getValue("VD_TINCheck").toString().equals("true")) {
					CSR_MR.mLogger.debug("VD_TINCheck ::");
					iform.setStyle("VD_MoMaidN", "disable", "false");
					iform.setStyle("VD_MoMaidN", "disable", "false");
					iform.setStyle("VD_POBox", "disable", "false");
					iform.setStyle("VD_TELNO", "disable", "false");
					iform.setStyle("VD_PassNo", "disable", "false");
					iform.setStyle("VD_MRT", "disable", "false");
					iform.setStyle("VD_Oth", "disable", "false");
					iform.setStyle("VD_SD", "disable", "false");
					iform.setStyle("VD_EDC", "disable", "false");
					iform.setStyle("VD_StaffId", "disable", "false");
					iform.setStyle("VD_DOB", "disable", "false");
					iform.setStyle("VD_NOSC", "disable", "false");
					msg= "tincheck is true.";
					
				}
				else if (iform.getValue("VD_TINCheck").toString().equals("false")) {
					//alert("inside VD_TINCheck");
					iform.setStyle("VD_MoMaidN", "disable", "true");
					iform.setStyle("VD_POBox", "disable", "true");
					iform.setStyle("VD_TELNO", "disable", "true");
					iform.setStyle("VD_PassNo", "disable", "true");
					iform.setStyle("VD_MRT", "disable", "true");
					iform.setStyle("VD_Oth", "disable", "true");
					iform.setStyle("VD_SD", "disable", "true");
					iform.setStyle("VD_EDC", "disable", "true");
					iform.setStyle("VD_StaffId", "disable", "true");
					iform.setStyle("VD_DOB", "disable", "true");
					iform.setStyle("VD_NOSC", "disable", "true");
					msg= "tincheck is false.";
				}
					
					
			}
			else if (controlName.equalsIgnoreCase("RaiseSRO"))
			{
				String Query = "select processdefid from processdeftable where processname = 'SRO'";
				List<List<String>> Query_data = iform.getDataFromDB(Query);
				String processDEFID = Query_data.get(0).get(0);
				CSR_MR.mLogger.debug("CustMail----------->" + processDEFID);
				String processDefIdSRO = processDEFID;
				String paramForSRO = data;
				CSR_MR.mLogger.debug("paramForSRO : "+paramForSRO);
				String attributeTagSRO = ""; String wfuploadInputXMLSRO = ""; String wfuploadOutputXMLSRO = ""; String WINumberSRO = "";
				attributeTagSRO = attributeTagSRO + "Service_Request_Type" + (char)21 +paramForSRO.split("~")[0]+(char)25;
				attributeTagSRO = attributeTagSRO + "Team" + (char)21 +paramForSRO.split("~")[1]+(char)25;
				attributeTagSRO = attributeTagSRO + "Remarks" + (char)21 +paramForSRO.split("~")[2]+(char)25;
				
				wfuploadInputXMLSRO = CSR_MRCommon.getWFUploadWorkItemXML(iform, processDefIdSRO, attributeTagSRO);
				CSR_MR.mLogger.debug("wfuploadInputXMLSRO : "+wfuploadInputXMLSRO);
				wfuploadOutputXMLSRO = CSR_MRCommon.ExecuteQueryOnServer(iform,wfuploadInputXMLSRO);
				CSR_MR.mLogger.debug("wfuploadOutputXMLSRO : "+wfuploadOutputXMLSRO);
				if(wfuploadOutputXMLSRO.indexOf("<MainCode>0</MainCode>")>-1){
					CSR_MR.mLogger.debug("WFUpload for SRO is successfull");
					XMLParser xmlobj = new XMLParser(wfuploadOutputXMLSRO);
					WINumberSRO = xmlobj.getValueOf("ProcessInstanceId");
					CSR_MR.mLogger.debug("WINumberSRO : "+WINumberSRO);
					strReturn = WINumberSRO+"~"+"WI Created";
				}else {
					CSR_MR.mLogger.debug("WFUpload for SRB is failed");
					strReturn = WINumberSRO+"~"+"WI Not Created";
				}
			}
		
		}catch(Exception exc)
		{
			CSR_MR.printException(exc);
			CSR_MR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception[Click Event] - "+exc);
		}
		return strReturn;
	}

	public String validateCCNo(String paramString1) {

		String str = paramString1.replaceAll("-", "");
		int[] arrayOfInt = new int[str.length()];
		int i = 0;
		int j = 0;
		for (i = 0; i < str.length(); i++) {
			arrayOfInt[i] = Integer.parseInt(str.charAt(i) + "");
		}
		for (i = arrayOfInt.length - 2; i >= 0; i -= 2) {
			arrayOfInt[i] *= 2;
			if (arrayOfInt[i] > 9) {
				arrayOfInt[i] -= 9;
			}
		}
		for (i = 0; i < arrayOfInt.length; i++) {
			j += arrayOfInt[i];
		}

		if (j % 10 == 0) {
			return "ValidCard";
		}

		return "Invalid Credit Card No. Format";
	}
	
	public void setFormDetail(IFormReference iform) {
		//((Object) iform).setControlValue("","");
		 CSR_MR.mLogger.debug("setFormDetail inside method=====");
	    if (!iform.getValue("CCI_CName").equals(""))
	      try
	      {
	        String str1 = (String) iform.getValue("cardDetails");
	        if (!str1.equals("")) {
	          CAPDataHT.clear();
	          int i = 0;
	          int j = 0;
	          int k = str1.indexOf("!");
	          int m = 0;
	          String str2 = "";
	          String str3 = "";
	          String str4 = "";
	          j = Integer.parseInt(str1.substring(0, str1.indexOf("@")));
	          str1 = str1.substring(str1.indexOf("@") + 1, str1.length());
	          for (m = 1; m <= j; m++)
	          {
	            if (m == 1)
	            {
	              i = -1;
	              k = str1.indexOf("!");
	            }
	            else
	            {
	              i = k;
	              k = str1.indexOf("!", i + 1);
	            }
	            CSR_MR.mLogger.debug("saaa=======" + k);
	            str2 = str1.substring(i + 1, k);

	            CAPDataHT.put("RAKBankCard" + m, str2);
	            CSR_MR.mLogger.debug("RAKBankCard" + m + "----" + str2);
	            i = k;
	            k = str1.indexOf("!", i + 1);
	            str3 = str1.substring(i + 1, k);
	            CAPDataHT.put("CardType" + m, str3);
	            CSR_MR.mLogger.debug("CardType" + m + "-----" + str3);
	            i = k;
	            k = str1.indexOf("!", i + 1);
	            str4 = str1.substring(i + 1, k);
	            CAPDataHT.put("ExpDate" + m, str4);
	            CSR_MR.mLogger.debug("ExpDate" + m + "---" + str4);
	          }

	          String str5 = (String) iform.getValue("BTD_RBC_RBCN1");
	          String str6 = (String) iform.getValue("BTD_RBC_RBCN2");
	          String str7 = (String) iform.getValue("BTD_RBC_RBCN3");
	          iform.clearCombo("BTD_RBC_RBCN1");
	          iform.clearCombo("BTD_RBC_RBCN2");
	          iform.clearCombo("BTD_RBC_RBCN3");
	          for (m = 1; m <= j; m++)
	          {
	        	 iform.addItemInCombo("BTD_RBC_RBCN1", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
	        	 iform.addItemInCombo("BTD_RBC_RBCN2", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
	        	 iform.addItemInCombo("BTD_RBC_RBCN3", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
	          }
	          if (!str5.equals(""))
	        	  iform.setValue("BTD_RBC_RBCN1", str5.substring(0, 4) + "-" + str5.substring(4, 8) + "-" + str5.substring(8, 12) + "-" + str5.substring(12, 16));
	          else
	        	  iform.setValue("BTD_RBC_RBCN1", "");
	          if (!str6.equals(""))
	        	  iform.setValue("BTD_RBC_RBCN2", str6.substring(0, 4) + "-" + str6.substring(4, 8) + "-" + str6.substring(8, 12) + "-" + str6.substring(12, 16));
	           else
	        	   iform.setValue("BTD_RBC_RBCN2", "");
	           if (!str7.equals(""))
	        	   iform.setValue("BTD_RBC_RBCN3", str7.substring(0, 4) + "-" + str7.substring(4, 8) + "-" + str7.substring(8, 12) + "-" + str7.substring(12, 16));
	           else
	        	   iform.setValue("BTD_RBC_RBCN3", "");
	           CSR_MR.mLogger.debug("tetet443434etew==4545663-");
	         }
	 
	         //lockCAPSFrm();
	       } catch (Exception localException) {
	         CSR_MR.mLogger.debug("card exception at form load==" + localException.toString());
	       }
	   }

	

}
