/*Description : CR for mail and sms trigger
 *Added By : Mirza Suhaib Beg
 *Date : 11-04-23    
 */
package com.newgen.iforms.user;

import java.util.Calendar;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;

import javax.print.DocFlavor.STRING;

import org.json.simple.JSONObject;

import com.newgen.custom.XMLParser;
import com.newgen.iforms.custom.IFormReference;


@SuppressWarnings("unused")
public class CSR_MR_Email extends CSR_MRCommon
{
	public static String mailTrigger(IFormReference iform, String stage,String data)
	{
		try{
			CSR_MR.mLogger.debug("Inside mailTrigger method-----------> ");
			CSR_MR.mLogger.debug("data-----------> "+data);
			String[] param = data.split("-");
			//declare all variable
			String SLA_TAT = "0";
			String tag = "";
			String date = getDate();
			String WI_No = (String)iform.getValue("wi_name");
			CSR_MR.mLogger.debug("WI_No----------->" + WI_No);
			String split_WI_No = splitString(WI_No);
			CSR_MR.mLogger.debug("split_WI_No----------->" + split_WI_No);
			String Card_No = param[0];//(String)iform.getValue("CCI_CrdtCN");
			CSR_MR.mLogger.debug("Card_No----------->" + Card_No);
			String lastDigitCard_No = Card_No.substring(12,16);
			CSR_MR.mLogger.debug("lastDigitCard_No----------->" + lastDigitCard_No);
			/*String rejectReason = param[2];//(String)iform.getValue("Cards_Reject");
			CSR_MR.mLogger.debug("rejectReason----------->" + rejectReason);*/
			String subProcessName = (String)iform.getValue("CCI_REQUESTTYPE");
			CSR_MR.mLogger.debug("subProcessName----------->" + subProcessName);
			String subProcess = convertToCamelCase(subProcessName);
			CSR_MR.mLogger.debug("subProcessName----------->" + subProcessName);
			String CUR_Amount = (String)iform.getValue("Curr_Amount");
			CSR_MR.mLogger.debug("CUR_Amount----------->" + CUR_Amount);
			String MerchantName = (String)iform.getValue("Merchant_Name");
			CSR_MR.mLogger.debug("MerchantName----------->" + MerchantName);
			String SchoolName = (String)iform.getValue("SchoolName");
			CSR_MR.mLogger.debug("SchoolName----------->" + SchoolName);
			String OS_Amount =  (String)iform.getValue("Cards_Outstanding");
			CSR_MR.mLogger.debug("OS_Amount----------->" + OS_Amount);
			String getCustMail = "Select userEmailID FROM RB_CSR_MISC_EXTTABLE WHERE WI_NAME = '"+WI_No+"'";
			List<List<String>> Query_data1 = iform.getDataFromDB(getCustMail);
			String CustMail = Query_data1.get(0).get(0);
			CSR_MR.mLogger.debug("CustMail----------->" + CustMail);
			if(iform.getActivityName().equalsIgnoreCase("CARDS"))
			{
			String rejectReason = (String)iform.getValue("Cards_Reject");
			CSR_MR.mLogger.debug("rejectReason--------->" + rejectReason);
			tag = "<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in; text-align:left;padding-left:31%;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+rejectReason+"</span></p>"+"\n";
			int size = 0;
			JSONArray str = new JSONArray();
			if(rejectReason.equalsIgnoreCase("Others")) 
			{
			String OthersrejectReason = (String)iform.getValue("Others_Cards");
			CSR_MR.mLogger.debug("OthersrejectReason----------->" + OthersrejectReason);
			 tag = "<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in; text-align:left;padding-left:31%;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+OthersrejectReason+"</span></p>"+"\n"; 
			}
			else if(rejectReason.equalsIgnoreCase("Due to non receipt of")){
				str = (JSONArray)iform.getValue("USR_0_CSR_MR_SUB_REASONS");
				size = str.size();
				tag = "";
				for(int i = 0; i<size; i++) {
					String reason = (String) str.get(i);
					CSR_MR.mLogger.debug("Non Receipt rejectReason----------->" + reason);
			        tag = tag+"<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in; text-align:left;padding-left:31%;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+reason+"</span></p>"+"\n"; 
			    }
			}
			}
			else if(iform.getActivityName().equalsIgnoreCase("Pending"))
			{
			String rejectReason = (String)iform.getValue("Pending_Reason");
			CSR_MR.mLogger.debug("rejectReason--------->" + rejectReason);
			tag = "<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in; text-align:left;padding-left:31%;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+rejectReason+"</span></p>"+"\n";
			int size = 0;
			JSONArray str = new JSONArray();
			if(rejectReason.equalsIgnoreCase("Others")) 
			{
			String OthersrejectReason = (String)iform.getValue("Others_Pending");
			CSR_MR.mLogger.debug("OthersrejectReason----------->" + OthersrejectReason);
			 tag = "<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in; text-align:left;padding-left:31%;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+OthersrejectReason+"</span></p>"+"\n"; 
			}
			else if(rejectReason.equalsIgnoreCase("Due to non receipt of")){
				str = (JSONArray)iform.getValue("USR_0_CSR_MR_PENDING_SUB");
				size = str.size();
				tag = "";
				for(int i = 0; i<size; i++) {
					String reason = (String) str.get(i);
					CSR_MR.mLogger.debug("Non Receipt rejectReason----------->" + reason);
			        tag = tag+"<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in; text-align:left;padding-left:31%;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+reason+"</span></p>"+"\n"; 
			    }
			}
			}
			//end
			//String path = System.getProperty("user.dir") + File.separatorChar + "folder name" + File.separatorChar + 
			//		"RAKBank_Email_Temp" + File.separatorChar + "CSR_MR_"+stage+".html";
			//String emailBody = readFile(path);
			String Query_TAT = "SELECT  SLA_TAT FROM USR_0_CSR_SLA_TAT WHERE ProcessName = 'DSR_ODC' AND SubProcessName = '"+subProcessName+"'";
			List<List<String>> Query_TATData = iform.getDataFromDB(Query_TAT);
			if(Query_TATData.size()>0) {
				SLA_TAT = Query_TATData.get(0).get(0);
				CSR_MR.mLogger.debug("SLA_TAT----------->" + SLA_TAT);
			}
			String Query = "Select * From USR_0_CSR_BT_TemplateMapping where ProcessName = 'CSR_MR' and TemplateType = '"+stage+"' and SubProcess = '"+subProcessName+"'";
			List<List<String>> Query_data = iform.getDataFromDB(Query);
			CSR_MR.mLogger.debug("Query_data----------->" + Query_data);
			if(Query_data.size()>0) {
			String emailBody = Query_data.get(0).get(2);
			CSR_MR.mLogger.debug("emailBody before replace" + emailBody);
			if (!emailBody.equalsIgnoreCase("NULL"))
			{
			emailBody = emailBody.replaceAll("#WI_No#", split_WI_No);
			emailBody = emailBody.replaceAll("#Card_No#", lastDigitCard_No);
			emailBody = emailBody.replaceAll("'Times", "''Times");
			emailBody = emailBody.replaceAll("Roman'", "Roman''");
			emailBody = emailBody.replaceAll("#reject reason#", tag);
			emailBody = emailBody.replaceAll("#Sub_Process_Name#", subProcess);
			emailBody = emailBody.replaceAll("#SLA_TAT#", SLA_TAT);
			emailBody = emailBody.replaceAll("#DD/MM/YYYY#", date);
			emailBody = emailBody.replaceAll("#CUR_Amount#", CUR_Amount);
			emailBody = emailBody.replaceAll("#Merchant_Name#", MerchantName);
			emailBody = emailBody.replaceAll("#School_Name#", SchoolName);
			emailBody = emailBody.replaceAll("#OS_Amount#", OS_Amount);
			CSR_MR.mLogger.debug("emailBody after replace" + emailBody);
			String mailFrom = Query_data.get(0).get(3);
			CSR_MR.mLogger.debug("mailFrom----->" + mailFrom);
			String mailTo = CustMail;//"test11@rakbanktst.ae"
			String mailSubject = Query_data.get(0).get(6);
			CSR_MR.mLogger.debug("Mail Subject------>"+mailSubject);
			String mailContentType = "text/html;charset=UTF-8";
			int mailPriority = 1;
			int workitemId = 1;
			int noOfTrials = 1;
			int activityId = 3;
			String mailStatus = "N";
			String mailActionType = "TRIGGER";
			String tableName = "WFMAILQUEUETABLE";
			String columnName = "(mailFrom,mailTo,mailSubject,mailMessage, mailContentType, mailPriority,mailStatus,insertedBy,"
					+ "mailActionType,processInstanceId,workitemId,activityId,noOfTrials)";
			String values;
				values = "('" + mailFrom + "','" + mailTo + "','" + mailSubject + "',N'" + emailBody + "','" + mailContentType
						+ "','" + mailPriority + "','" + mailStatus + "','" + getUserName() + "','" + mailActionType + "','"
						+ (iform.getObjGeneralData()).getM_strProcessInstanceId() + "','" + workitemId + "','" + activityId + "','" 
						+ noOfTrials + "')";
			String mailInsertQuery = "Insert into "+tableName+" "+columnName+" values "+values ;
			CSR_MR.mLogger.debug("Query to be inserted in table-----------------: " + mailInsertQuery);
			int status = iform.saveDataInDB(mailInsertQuery);
			CSR_MR.mLogger.debug("Status------------>"+status);
			CSR_MR.mLogger.debug("Mail Triggred successfuly if value of status is 1---------STATUS = " + status);
			if(status==1)
			return "true";
				}
			}
		}catch (Exception ex) {
			CSR_MR.mLogger.debug("Some error in mailTrigger " + ex.toString());
			return "false";
		}
		return "false";
	}
	public static String sendSMS(IFormReference iform, String stage, String data) {
		try{
			CSR_MR.mLogger.debug("inside sendSMScall txtMessagessss");
			CSR_MR.mLogger.debug("data----->"+data);
			String[] param = data.split("-");
			//declare all  variable
			String SLA_TAT = "0";

			String WI_No = (String)iform.getValue("wi_name");
			CSR_MR.mLogger.debug("WI_No------->" + WI_No);
			String split_WI_No = splitString(WI_No);
			CSR_MR.mLogger.debug("split_WI_No----------->" + split_WI_No);
			String Card_No = param[0];//(String)iform.getValue("CCI_CrdtCN");
			CSR_MR.mLogger.debug("Card_No------->" + Card_No);
			String lastDigitCard_No =Card_No.substring(12,16);
			CSR_MR.mLogger.debug("lastDigitCard_No------->" + lastDigitCard_No);
			String pendingReason = (String)iform.getValue("Pending_Reason");
			CSR_MR.mLogger.debug("pendingReason------->" + pendingReason);
			String subProcessName = (String)iform.getValue("CCI_REQUESTTYPE");
			CSR_MR.mLogger.debug("subProcessName----------->" + subProcessName);
			String subProcess = convertToCamelCase(subProcessName);
			CSR_MR.mLogger.debug("subProcessName----------->" + subProcessName);
			String CUR_Amount = (String)iform.getValue("Curr_Amount");
			CSR_MR.mLogger.debug("CUR_Amount----------->" + CUR_Amount);
			String MerchantName = (String)iform.getValue("Merchant_Name");
			CSR_MR.mLogger.debug("MerchantName----------->" + MerchantName);
			String SchoolName = (String)iform.getValue("SchoolName");
			CSR_MR.mLogger.debug("SchoolName----------->" + SchoolName);
			String OS_Amount =  (String)iform.getValue("Cards_Outstanding");
			CSR_MR.mLogger.debug("OS_Amount----------->" + OS_Amount);
			String date = getDate();
			String smsLang = "EN";
			//end
			CSR_MR.mLogger.debug("inside sendSMScall Card_No :" + Card_No);
			//String path = System.getProperty("user.dir") + File.separatorChar + "folder name" + File.separatorChar + 
			//		"RAKBank_SMS_Temp" + File.separatorChar + "CSR_MR_"+stage+".html";
			//String txtMessage = readFile(path);
			String Query = "Select * From USR_0_CSR_BT_TemplateMapping where ProcessName = 'CSR_MR' and TemplateType = '"+stage+"' and SubProcess = '"+subProcessName+"'";
			List<List<String>> Query_data = iform.getDataFromDB(Query);
			CSR_MR.mLogger.debug("Query_data------->" + Query_data);
			if(Query_data.size()>0) {
			String txtMessage = Query_data.get(0).get(5);
			CSR_MR.mLogger.debug("txtMessage before replace" + txtMessage);
			if(!txtMessage.equalsIgnoreCase("NULL"))
			{
			txtMessage = txtMessage.replaceAll("#WI_No#", split_WI_No);
			txtMessage = txtMessage.replaceAll("#Card_No#", lastDigitCard_No);
			txtMessage = txtMessage.replaceAll("#CancellationReason#", pendingReason);
			txtMessage = txtMessage.replaceAll("#Sub_Process_Name#", subProcess);
			txtMessage = txtMessage.replaceAll("#SLA_TAT#", SLA_TAT);
			txtMessage = txtMessage.replaceAll("#DD/MM/YYYY#", date);
			txtMessage = txtMessage.replaceAll("#CUR_Amount#", CUR_Amount);
			txtMessage = txtMessage.replaceAll("#Merchant_Name#", MerchantName);
			txtMessage = txtMessage.replaceAll("#School_Name#", SchoolName);
			txtMessage = txtMessage.replaceAll("#OS_Amount#", OS_Amount);
			CSR_MR.mLogger.debug("txtMessage after replace" + txtMessage);
			String tableName = "NG_RLOS_SMSQUEUETABLE";
			String ALERT_Name = stage;
			String Alert_Code = "CSR_MR";
			String Alert_Status = "P";
			String Mobile_No = param[1];//(String)iform.getValue("CCI_MONO");
			CSR_MR.mLogger.debug("Mobile no--------->" + Mobile_No);
			String Workstep_Name = (String)iform.getActivityName();
			String columnName = "(ALERT_Name, Alert_Code, Alert_Status, Mobile_No, Alert_Text, WI_Name, Workstep_Name, Inserted_Date_time)";
			String values = "('" + ALERT_Name + "','" + Alert_Code + "','" + Alert_Status + "','" + Mobile_No + "','" + txtMessage
					+ "','" + WI_No + "','" + Workstep_Name + "', getdate() )";
			String SMSInsertQuery = "Insert into "+tableName+" "+columnName+" values "+values ;
			CSR_MR.mLogger.debug("Query to be inserted in table-----------------: " + SMSInsertQuery);
			int status = iform.saveDataInDB(SMSInsertQuery);
			CSR_MR.mLogger.debug("SMS Triggred successfuly if value of status is 1-------------STATUS = " + status);
			if(status==1)
			return "true";
			}
		}
		}catch(Exception ex) {
			CSR_MR.mLogger.debug("Some error in sendSMScall" + ex.toString());
		}
		return "false";
	}
}