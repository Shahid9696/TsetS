package netscape.javascript;

public class JSObject {

	public void call(String string, String[] arrayOfString) {
		// TODO Auto-generated method stub
		
	}

}
