package com.newgen.iforms.user;

import java.util.List;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.omni.jts.cmgr.XMLParser;

public class CSR_OCC_Click {

	public String clickEvent(IFormReference iform, String controlName, String data)
	{
		String strReturn = "";
		CSR_OCC.mLogger.debug("inside CSR_OCC_click");
		 if(controlName.equals("CAPSMAIN_Query1") || controlName.equals("CAPSMAIN_Query2"))
             return new CSR_OCCIntegration().onclickevent(iform, controlName, data);
		 else if(controlName.equals("Print_Button"))
             return new CSR_OCCIntegration().onclickevent(iform, controlName, data);
		 else if (controlName.equalsIgnoreCase("RaiseSRO"))
         {
			 String Query = "select processdefid from processdeftable where processname = 'SRO'";
			 List<List<String>> Query_data = iform.getDataFromDB(Query);
			 String processDEFID = Query_data.get(0).get(0);
			 CSR_OCC.mLogger.debug("CustMail----------->" + processDEFID);
			 String processDefIdSRO = processDEFID;
             String paramForSRO = data;
             CSR_OCC.mLogger.debug("paramForSRO : "+paramForSRO);
             String attributeTagSRO = ""; 
             String wfuploadInputXMLSRO = ""; 
             String wfuploadOutputXMLSRO = ""; 
             String WINumberSRO = "";
             attributeTagSRO = attributeTagSRO + "Service_Request_Type" + (char)21 +paramForSRO.split("~")[0]+(char)25;
             attributeTagSRO = attributeTagSRO + "Team" + (char)21 +paramForSRO.split("~")[1]+(char)25;
             attributeTagSRO = attributeTagSRO + "Remarks" + (char)21 +paramForSRO.split("~")[2]+(char)25;

             wfuploadInputXMLSRO = CSR_OCCCommon.getWFUploadWorkItemXML(iform, processDefIdSRO, attributeTagSRO);
             CSR_OCC.mLogger.debug("wfuploadInputXMLSRO : "+wfuploadInputXMLSRO);
             wfuploadOutputXMLSRO = CSR_OCCCommon.ExecuteQueryOnServer(iform,wfuploadInputXMLSRO);
             CSR_OCC.mLogger.debug("wfuploadOutputXMLSRO : "+wfuploadOutputXMLSRO);
             if(wfuploadOutputXMLSRO.indexOf("<MainCode>0</MainCode>")>-1){
            	 CSR_OCC.mLogger.debug("WFUpload for SRO is successfull");
                 XMLParser xmlobj = new XMLParser(wfuploadOutputXMLSRO);
                 WINumberSRO = xmlobj.getValueOf("ProcessInstanceId");
                 CSR_OCC.mLogger.debug("WINumberSRO : "+WINumberSRO);
                 strReturn = WINumberSRO+"~"+"WI Created";
             }else {
            	 CSR_OCC.mLogger.debug("WFUpload for SRB is failed");
                 strReturn = WINumberSRO+"~"+"WI Not Created";
             }
         }
         else
        	 return "";	
		 
		 CSR_OCC.mLogger.debug("strReturn for SRO raised : "+strReturn);
         return strReturn;
	}
}
