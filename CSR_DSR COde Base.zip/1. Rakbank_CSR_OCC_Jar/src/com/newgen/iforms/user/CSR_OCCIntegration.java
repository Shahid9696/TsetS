package com.newgen.iforms.user;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.mvcbeans.model.wfobjects.WDGeneralData;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Iterator;
import java.util.Map.Entry;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import netscape.javascript.JSObject;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.CharacterData;
	
	public class CSR_OCCIntegration extends CSR_OCCCommon 
	{		
		LinkedHashMap<String,String> executeXMLMapMain = new LinkedHashMap<String,String>();
		public static String XMLLOG_HISTORY="NG_CSR_OCC_XMLLOG_HISTORY";

	public String onclickevent(IFormReference iformObj,String control,String StringData)
	{
		Connection conn = null;
		//Statement stmt =null;
		PreparedStatement stmt=null;
		ResultSet result=null;
		String sSQL = "";
		String MQ_response="";
		String MQ_response_Entity ="";
		String strReturn="false";
		HashMap CAPDataHT = new HashMap();
		
		try
		{
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Inside onclickevent function");
			CSR_OCC.mLogger.debug("control : "+control);
			if(control.equals("CAPSMAIN_Query1"))
			{
				String sFirstName = "";
				String sMiddleName = "";
				String sLastName = "";
				String sCustomerName = "";
				String sExpiryDate = "";
				String sCardCRNNo = "";
				String sMobileNo = "";
				String sAccessedIncome = "";
				String sCardType = "";
				String sGeneralStat = "";
				String sEliteCustomerNo = "";
				
				try{			
					Context aContext = new InitialContext();
					DataSource aDataSource = (DataSource)aContext.lookup("jdbc/cbop");
					conn = (Connection)(aDataSource.getConnection());
					CSR_OCC.mLogger.debug("got data source");
					//stmt = conn.createStatement();					
					
					//Changed by Amandeep for CAPS Database change
					sSQL = "Select trim(FirstName), trim(MiddleName), trim(LastName), substr(to_char(EXPIRYDATE,'dd/mm/yy'),4,length(to_char(EXPIRYDATE,'dd/mm/yy'))),CRNNO, MOBILE,ASSESSEDINCOME,CARDTYPE,generalstat,elitecustomerno  from ftsdib.CAPSMAIN NOLOCK where CREDITCARDNO=?";
					CSR_OCC.mLogger.debug("Execute Query..."+sSQL);	
					stmt = conn.prepareStatement(sSQL);
					stmt.setString(1, iformObj.getValue("CCI_CrdtCN").toString());
					CSR_OCC.mLogger.debug("Execute stmt..."+stmt);					
					
					result = stmt.executeQuery();
					CSR_OCC.mLogger.debug("Execute result..."+result);
					CSR_OCC.mLogger.debug("result.getFetchSize()..."+result.getFetchSize());
					if(result.getFetchSize() != 0)
					{
						CSR_OCC.mLogger.debug("result.getRow()..."+result.getRow());
						while(result.next())
						{
							CSR_OCC.mLogger.debug("result.getString(1)..."+result.getString(1));
							sFirstName = result.getString(1);					
							sMiddleName = result.getString(2);
							sLastName = result.getString(3);
							sCustomerName=sFirstName+" "+sMiddleName+" "+sLastName;
							sExpiryDate=result.getString(4);
							sCardCRNNo=result.getString(5);
							sMobileNo=result.getString(6);
							sAccessedIncome=new Integer(result.getInt(7)).toString();
							sCardType=result.getString(8);
							sGeneralStat=result.getString(9);
							sEliteCustomerNo=result.getString(10);
							CSR_OCC.mLogger.debug("result.getString(10)..."+sEliteCustomerNo);
						}
						
						setControlValue("CCI_CName", sCustomerName);
						setControlValue("CCI_ExpD", sExpiryDate);
						//setControlValue("CCI_ExpD", "Masked");
						setControlValue("CCI_CCRNNo", sCardCRNNo);
						setControlValue("CCI_MONO", sMobileNo);
						setControlValue("CCI_AccInc", sAccessedIncome);
						setControlValue("CCI_CT", sCardType);
						setControlValue("CCI_CAPS_GENSTAT", sGeneralStat);
						setControlValue("CCI_ELITECUSTNO", sEliteCustomerNo);
						strReturn=control+"Customer Data Loaded";
					}	
					else
					{
						CSR_OCC.mLogger.debug("'Customer Not Found 1");
						strReturn=control+"Customer Data Not Loaded";
					}
					CSR_OCC.mLogger.debug(" Process_Name_Label :"+iformObj.getValue("Process_Name_Label").toString());
					CSR_OCC.mLogger.debug(" getProcessName :"+iformObj.getProcessName());
					/*if (iformObj.getValue("Process_Name").toString().equalsIgnoreCase("Card Service Request - Balance Transfer")||iformObj.getValue("Process_Name").toString().equalsIgnoreCase("Card Service Request - Credit Card Cheque")||iformObj.getValue("Process_Name").toString().equalsIgnoreCase("Card Service Request - Cash Back Request"))
					{
					
						//out.println("<script>alert('"+sCardCRNNo+"');</script>");						
				
						
						if (sCardCRNNo.charAt(7)=='0'&&sCardCRNNo.charAt(8)=='0')
						{	
							
						}
						else
						{
							CSR_OCC.mLogger.debug("Supplementary Cards are not allowed for this request");
						}						
					}*/
					if(result != null)
					{
						result.close();
						result=null;
						CSR_OCC.mLogger.debug("resultset Successfully closed"); 
					}
					if(stmt != null)
					{
						stmt.close();
						stmt=null;						
						CSR_OCC.mLogger.debug("Stmt Successfully closed"); 
					}
					if(conn != null)
					{
						conn.close();
						conn=null;	
						CSR_OCC.mLogger.debug("Conn Successfully closed"); 
					}
				}
				catch (java.sql.SQLException e)
				{
					CSR_OCC.mLogger.debug(e.toString());
					if(e.getClass().toString().equalsIgnoreCase("Class javax.naming.NameNotFoundException"))
						CSR_OCC.mLogger.debug("Data Source For CAPS System Not Found");

						else if(e.toString().indexOf("Operation timed out: connect:could be due to invalid address")!=-1)
							CSR_OCC.mLogger.debug("Unable to connect to CAPS System");

						else{
							CSR_OCC.mLogger.debug("Unable to connect to CAPS System");
						}
				}
				catch(Exception e)
				{
					CSR_OCC.mLogger.debug(e.toString());
					CSR_OCC.mLogger.debug("Some error occured Please Contact Administrator\")</script>");
				}
				finally
				{
					if(result != null)
					{
						result.close();
						result=null;
						CSR_OCC.mLogger.debug("resultset Successfully closed"); 
					}
					if(stmt != null)
					{
						stmt.close();
						stmt=null;						
						CSR_OCC.mLogger.debug("Stmt Successfully closed"); 
					}
					if(conn != null)
					{
						conn.close();
						conn=null;	
						CSR_OCC.mLogger.debug("Conn Successfully closed"); 
					}
				}
				
				
				/*String str1 = "Select LTRIM(RTRIM(FirstName)), LTRIM(RTRIM(MiddleName)), LTRIM(RTRIM(LastName)), substring(format(EXPIRYDATE,'dd/mm/yy'),4,LEN(format(EXPIRYDATE,'dd/mm/yy'))), CRNNO, MOBILE,ASSESSEDINCOME,CARDTYPE,generalstat,elitecustomerno  from rak_bpm.dbo.CAPSMAIN where  CREDITCARDNO='" + iformObj.getValue("CCI_CrdtCN").toString().replaceAll("-", "") + "'";
				String str3 = "";
				String str4 = "";
				String str5 = "";
				String str6 = "";
				String str7 = "";
				String str8 = "";
				String str9 = "";
				String str10 = "";
				String str11 = "";
				String str12 = "";
				CSR_OCC.mLogger.debug("str1 :"+str1);
				List lstDecisions = iformObj.getDataFromDB(str1);
				CSR_OCC.mLogger.debug("lstDecisions :"+lstDecisions);
				if (lstDecisions != null)
				{
					for(int i=0;i<lstDecisions.size();i++)
					{
						CSR_OCC.mLogger.debug(" loop i :"+i);
						List<String> arr1=(List)lstDecisions.get(i);
						str3=arr1.get(0);
						str4=arr1.get(1);
						str5=arr1.get(2);
						str6=arr1.get(3);
						str7=arr1.get(4);
						str8=arr1.get(5);
						str9=arr1.get(6);
						str10=arr1.get(7);
						str11=arr1.get(8);
						str12=arr1.get(9);
					}

					setControlValue("CCI_CName", str3 + " " + str4 + " " + str5);
					setControlValue("CCI_ExpD", str6);
					setControlValue("CCI_ExpD", "Masked");
					setControlValue("CCI_CCRNNo", str7);
					setControlValue("CCI_MONO", str8);
					setControlValue("CCI_AccInc", str9);
					setControlValue("CCI_CT", str10);
					setControlValue("CCI_CAPS_GENSTAT", str11);
					setControlValue("CCI_ELITECUSTNO", str12);
					
				}*/
			}	
			else if(control.equals("CAPSMAIN_Query2"))
			{
				
				try{			
					Context aContext = new InitialContext();
					DataSource aDataSource = (DataSource)aContext.lookup("jdbc/cbop");
					conn = (Connection)(aDataSource.getConnection());
					CSR_OCC.mLogger.debug("got data source");
					//stmt = conn.createStatement();					
					
					//Changed by Amandeep for CAPS Database change
					sSQL = "select creditcardno,CARDTYPE,substr(to_char(EXPIRYDATE,'dd/mm/yy'),4,length(to_char(EXPIRYDATE,'dd/mm/yy'))) from ftsdib.capsmain NOLOCK where elitecustomerno=(select elitecustomerno from ftsdib.capsmain NOLOCK where creditcardno='" + iformObj.getValue("CCI_CrdtCN").toString().replaceAll("-", "") + "') and substr(CREDITCARDNO,14,1)<>'0'";
					CSR_OCC.mLogger.debug("Execute Query..."+sSQL);	
					stmt = conn.prepareStatement(sSQL);

					CSR_OCC.mLogger.debug("Execute stmt..."+stmt);					
					result = stmt.executeQuery();
					CSR_OCC.mLogger.debug("Execute result..."+result);
					
					Object localObject = "";					
					int j = 0;
					int k = 0;
					String str13="";
					CSR_OCC.mLogger.debug("result.getFetchSize() ..."+result.getRow());
					if(result.getFetchSize() != 0)
					{						
						CSR_OCC.mLogger.debug("result.getRow() ..."+result.getRow());
						
						CAPDataHT.clear();
						while(result.next())
						{
							k++;
							CSR_OCC.mLogger.debug("result.getString(1) ..."+result.getString(1));
							str13 = result.getString(1);
							
							if (((String)localObject) == "")
								localObject = str13;
							else 
							{
								localObject = (String)localObject + str13;
							}						
							CAPDataHT.put("RAKBankCard"+k, str13);
							CSR_OCC.mLogger.debug("k :"+k+" CAPDataHT :"+CAPDataHT.get("RAKBankCard"+k));
							
							str13 = result.getString(2);
							localObject = (String)localObject + "!" + str13;
							CAPDataHT.put("CardType"+k, str13);
							CSR_OCC.mLogger.debug("k :"+k+" CAPDataHT :"+CAPDataHT.get("CardType"+k));
							
							str13 = result.getString(3);
							localObject = (String)localObject + "!" + str13;
							CAPDataHT.put("ExpDate"+k, str13);
							CSR_OCC.mLogger.debug("k :"+k+" CAPDataHT :"+CAPDataHT.get("ExpDate"+k));
							localObject = (String)localObject + "!";
							j++;
						}

						localObject = j + "@" + (String)localObject;
						CSR_OCC.mLogger.debug("localObject :"+localObject);
						str13 = iformObj.getValue("oth_ssc_SCNo").toString();
						setControlValue("cardDetails", (String)localObject);
						iformObj.clearCombo("oth_ssc_SCNo_Combo");
						
						CSR_OCC.mLogger.debug("j :"+j);
						
						for (int i = 1; i <= j; i++)
						{
							CSR_OCC.mLogger.debug("i :"+i+" oth_ssc_SCNo_Combo :"+CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(12, 16));
							iformObj.addItemInCombo("oth_ssc_SCNo_Combo", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(12, 16), CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(12, 16));
						}
						CSR_OCC.mLogger.debug("str13 :"+str13);
						if (!str13.equalsIgnoreCase(""))
							setControlValue("oth_ssc_SCNo_Combo", str13.substring(0, 4) + "-" + str13.substring(4, 8) + "-" + str13.substring(8, 12) + "-" + str13.substring(12, 16));
						else 
						{
							setControlValue("oth_ssc_SCNo_Combo", "");
						}
						CSR_OCC.mLogger.debug("oth_ssc_SCNo_Combo :"+iformObj.getValue("oth_ssc_SCNo_Combo"));
						strReturn=control+" and card No's are Loaded";
					}	
					else
					{
						CSR_OCC.mLogger.debug("'Customer Not Found 2");
						strReturn=control+" and card No's are not Loaded";
					}
					CSR_OCC.mLogger.debug(" Process_Name :"+iformObj.getValue("Process_Name").toString());
					CSR_OCC.mLogger.debug(" getProcessName :"+iformObj.getProcessName());
					
					if(result != null)
					{
						result.close();
						result=null;
						CSR_OCC.mLogger.debug("resultset Successfully closed"); 
					}
					if(stmt != null)
					{
						stmt.close();
						stmt=null;						
						CSR_OCC.mLogger.debug("Stmt Successfully closed"); 
					}
					if(conn != null)
					{
						conn.close();
						conn=null;	
						CSR_OCC.mLogger.debug("Conn Successfully closed"); 
					}
				}
				catch (java.sql.SQLException e)
				{
					CSR_OCC.mLogger.debug(e.toString());
					if(e.getClass().toString().equalsIgnoreCase("Class javax.naming.NameNotFoundException"))
						CSR_OCC.mLogger.debug("Data Source For CAPS System Not Found");

						else if(e.toString().indexOf("Operation timed out: connect:could be due to invalid address")!=-1)
							CSR_OCC.mLogger.debug("Unable to connect to CAPS System");

						else{
							CSR_OCC.mLogger.debug("Unable to connect to CAPS System");
						}
				}
				catch(Exception e)
				{
					CSR_OCC.mLogger.debug(e.toString());
					CSR_OCC.mLogger.debug("Some error occured Please Contact Administrator\")</script>");
				}
				finally
				{
					if(result != null)
					{
						result.close();
						result=null;
						CSR_OCC.mLogger.debug("resultset Successfully closed"); 
					}
					if(stmt != null)
					{
						stmt.close();
						stmt=null;						
						CSR_OCC.mLogger.debug("Stmt Successfully closed"); 
					}
					if(conn != null)
					{
						conn.close();
						conn=null;	
						CSR_OCC.mLogger.debug("Conn Successfully closed"); 
					}
				}
				
				/*String str1 = "select creditcardno,CARDTYPE,substring(format(EXPIRYDATE,'dd/mm/yy'),4,LEN(format(EXPIRYDATE,'dd/mm/yy'))) from rak_bpm.dbo.capsmain where elitecustomerno=(select elitecustomerno from rak_bpm.dbo.capsmain where creditcardno='" + iformObj.getValue("CCI_CrdtCN").toString().replaceAll("-", "") + "') and substring(CREDITCARDNO,14,1)<>'0'";
				CSR_OCC.mLogger.debug("str1 :"+str1);
				List lstDecisions = iformObj.getDataFromDB(str1);

				CSR_OCC.mLogger.debug("lstDecisions :"+lstDecisions);
				//str2 = ExecuteQuery_APSelect(str1);
				Object localObject = "";
				
				int j = 0;
				int k = 0;
				String str13="";
				if (lstDecisions != null)
				{			
					CAPDataHT.clear();
					for(int l=0;l<lstDecisions.size();l++)
					{
						k++;
						List<String> arr1=(List)lstDecisions.get(l);
						str13 = arr1.get(0);						
						
						if (((String)localObject) == "")
							localObject = str13;
						else 
						{
							localObject = (String)localObject + str13;
						}						
						CAPDataHT.put("RAKBankCard"+k, str13);
						CSR_OCC.mLogger.debug("k :"+k+" CAPDataHT :"+CAPDataHT.get("RAKBankCard"+k));
						
						str13 = arr1.get(1);
						localObject = (String)localObject + "!" + str13;
						CAPDataHT.put("CardType"+k, str13);
						CSR_OCC.mLogger.debug("k :"+k+" CAPDataHT :"+CAPDataHT.get("CardType"+k));
						
						str13 = arr1.get(2);
						localObject = (String)localObject + "!" + str13;
						CAPDataHT.put("ExpDate"+k, str13);
						CSR_OCC.mLogger.debug("k :"+k+" CAPDataHT :"+CAPDataHT.get("ExpDate"+k));
						localObject = (String)localObject + "!";
						j++;
					}

					localObject = j + "@" + (String)localObject;
					CSR_OCC.mLogger.debug("localObject :"+localObject);
					str13 = iformObj.getValue("oth_ssc_SCNo").toString();
					setControlValue("cardDetails", (String)localObject);
					iformObj.clearCombo("oth_ssc_SCNo_Combo");
					
					CSR_OCC.mLogger.debug("j :"+j);
					
					for (int i = 1; i <= j; i++)
					{
						CSR_OCC.mLogger.debug("i :"+i+" oth_ssc_SCNo_Combo :"+CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(12, 16));
						iformObj.addItemInCombo("oth_ssc_SCNo_Combo", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(12, 16), CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i).toString()).toString().substring(12, 16));
					}
					CSR_OCC.mLogger.debug("str13 :"+str13);
					if (!str13.equalsIgnoreCase(""))
						setControlValue("oth_ssc_SCNo_Combo", str13.substring(0, 4) + "-" + str13.substring(4, 8) + "-" + str13.substring(8, 12) + "-" + str13.substring(12, 16));
					else 
					{
						setControlValue("oth_ssc_SCNo_Combo", "");
					}
					CSR_OCC.mLogger.debug("oth_ssc_SCNo_Combo :"+iformObj.getValue("oth_ssc_SCNo_Combo"));
					
				}*/
			}
			else if(control.equals("Print_Button"))
			{
				CSR_OCC.mLogger.debug("inside Print_Button :");
				//JSObject jsObj = JSObject.getWindow(this);
				//CSR_OCC.mLogger.debug("localJSObject :"+localJSObject.toString());
				String str2 = ""; String str3 = ""; String str4 = ""; String str5 = ""; String str6 = ""; String str7 = ""; String str8 = ""; String str9 = ""; String str10 = ""; String str11 = ""; String str12 = ""; String str13 = ""; String str14 = "";
				str2 = iformObj.getValue("Cards_Remarks").toString().replace("&", "ampersand");
				str2 = str2.replace("=", "equalsopt");
				str2 = str2.replace("%", "percentageopt");
				str3 = iformObj.getValue("BR_Remarks").toString().replace("&", "ampersand");
				str3 = str3.replace("=", "equalsopt");
				str3 = str3.replace("%", "percentageopt");

				str5 = iformObj.getValue("oth_cu_RR").toString().replace("&", "ampersand");
				str5 = str5.replace("=", "equalsopt");
				str5 = str5.replace("%", "percentageopt");
				str6 = iformObj.getValue("oth_cdr_RR").toString().replace("&", "ampersand");
				str6 = str6.replace("=", "equalsopt");
				str6 = str6.replace("%", "percentageopt");
				str7 = iformObj.getValue("oth_td_RR").toString().replace("&", "ampersand");
				str7 = str7.replace("=", "equalsopt");
				CSR_OCC.mLogger.debug("str7 : :"+str7);
				str7 = str7.replace("%", "percentageopt");
				str8 = iformObj.getValue("oth_ecr_RR").toString().replace("&", "ampersand");
				str8 = str8.replace("=", "equalsopt");
				str8 = str8.replace("%", "percentageopt");
				str9 = iformObj.getValue("oth_cs_RR").toString().replace("&", "ampersand");
				str9 = str9.replace("=", "equalsopt");
				str9 = str9.replace("%", "percentageopt");
				str10 = iformObj.getValue("oth_cr_RR").toString().replace("&", "ampersand");
				str10 = str10.replace("=", "equalsopt");
				str10 = str10.replace("%", "percentageopt");
				str11 = iformObj.getValue("oth_cli_RR").toString().replace("&", "ampersand");
				str11 = str11.replace("=", "equalsopt");
				str11 = str11.replace("%", "percentageopt");
				str12 = iformObj.getValue("oth_csi_RR").toString().replace("&", "ampersand");
				str12 = str12.replace("=", "equalsopt");
				str12 = str12.replace("%", "percentageopt");
				str13 = iformObj.getValue("oth_ssc_RR").toString().replace("&", "ampersand");
				str13 = str13.replace("=", "equalsopt");
				str13 = str13.replace("%", "percentageopt");
				str14 = iformObj.getValue("oth_rip_RR").toString().replace("&", "ampersand");
				str14 = str14.replace("=", "equalsopt");
				str14 = str14.replace("%", "percentageopt");

				//String[] arrayOfString = new String[1];
				String ParamValues = "CCI_CrdtCN=" + iformObj.getValue("CCI_CrdtCN") + "&" + "CCI_CName=" + iformObj.getValue("CCI_CName") + "&" + "CCI_ExpD=" + iformObj.getValue("CCI_ExpD") + "&" + "CCI_CCRNNo=" + iformObj.getValue("CCI_CCRNNo") + "&" + "CCI_ExtNo=" + iformObj.getValue("CCI_ExtNo") + "&" + "CCI_MONO=" + iformObj.getValue("CCI_MONO") + "&" + "CCI_CAPS_GENSTAT=" + iformObj.getValue("CCI_CAPS_GENSTAT") + "&" + "CCI_ELITECUSTNO=" + iformObj.getValue("CCI_ELITECUSTNO") + "&" + "CCI_AccInc=" + iformObj.getValue("CCI_AccInc") + "&" + "CCI_CT=" + iformObj.getValue("CCI_CT") + "&" + "Card_Upgrade=" + iformObj.getValue("request_type") + "&" + "Card_Delivery_Request=" + iformObj.getValue("request_type") + "&" + "Transaction_Dispute=" + iformObj.getValue("request_type") + "&" + "Early_Card_Renewal=" + iformObj.getValue("request_type") + "&" + "Credit_Shield=" + iformObj.getValue("request_type") + "&" + "Card_Replacement=" + iformObj.getValue("request_type") + "&" + "Credit_Limit_Increase=" + iformObj.getValue("request_type") + "&" + "Change_in_Standing_Instructions=" + iformObj.getValue("request_type") + "&" + "Setup_Suppl_Card_Limit=" + iformObj.getValue("request_type") + "&" + "Re_Issue_of_PIN=" + iformObj.getValue("request_type") + "&" + "IntroductionDateTime=" + iformObj.getValue("CreatedDateTime") + "&" + "Cards_Decision=" + iformObj.getValue("Cards_Decision") + "&" + "Cards_Remarks=" + str2 + "&" + "VD_TINCheck=" + iformObj.getValue("VD_TIN_Check") + "&" + "VD_MoMaidN=" + iformObj.getValue("VD_MoMaidN_Check") + "&" + "VD_DOB=" + iformObj.getValue("VD_DOB_Check") + "&" + "VD_StaffId=" + iformObj.getValue("VD_StaffId_Check") + "&" + "VD_PassNo=" + iformObj.getValue("VD_PassNo_Check") + "&" + "VD_POBox=" + iformObj.getValue("VD_POBox_Check") + "&" + "VD_Oth=" + iformObj.getValue("VD_Oth_Check") + "&" + "VD_MRT=" + iformObj.getValue("VD_MRT_Check") + "&" + "VD_EDC=" + iformObj.getValue("VD_EDC_Check") + "&" + "VD_NOSC=" + iformObj.getValue("VD_NOSC_Check") + "&" + "VD_TELNO=" + iformObj.getValue("VD_TELNO_Check") + "&" + "VD_SD=" + iformObj.getValue("VD_SD_Check") + "&" + "wi_name=" + iformObj.getValue("wi_name") + "&" + "processname=" + "CSR_OCC" + "&" + "oth_cu_RR=" + str5 + "&" + "oth_rip_reason=" + iformObj.getValue("oth_rip_reason") + "&" + "oth_rip_DC=" + iformObj.getValue("oth_rip_DC") + "&" + "oth_rip_BN=" + iformObj.getValue("oth_rip_BN") + "&" + "oth_rip_RR=" + str14 + "&" + "oth_td_RNO=" + iformObj.getValue("oth_td_RNO") + "&" + "oth_td_Amount=" + iformObj.getValue("oth_td_Amount") + "&" + "oth_td_RR=" + str7 + "&" + "oth_cs_CS=" + iformObj.getValue("oth_cs_CS") + "&" + "oth_cs_CSR=" + iformObj.getValue("oth_cs_CSR") + "&" + "oth_cs_Amount=" + iformObj.getValue("oth_cs_Amount") + "&" + "oth_cs_RR=" + str9 + "&" + "oth_csi_PH=" + iformObj.getValue("oth_csi_PH_Check") + "&" + "oth_csi_TOH=" + iformObj.getValue("oth_csi_TOH") + "&" + "oth_csi_NOM=" + iformObj.getValue("oth_csi_NOM") + "&" + "oth_csi_CSIP=" + iformObj.getValue("oth_csi_CSIP_Check") + "&" + "oth_csi_POSTMTB=" + iformObj.getValue("oth_csi_POSTMTB") + "&" + "oth_csi_CSID=" + iformObj.getValue("oth_csi_CSID_Check") + "&" + "oth_csi_ND=" + iformObj.getValue("oth_csi_ND") + "&" + "oth_csi_CDACNo=" + iformObj.getValue("oth_csi_CDACNo_Check") + "&" + "oth_csi_AccNo=" + iformObj.getValue("oth_csi_AccNo") + "&" + "oth_csi_RR=" + str12 + "&" + "oth_cr_reason=" + iformObj.getValue("oth_cr_reason") + "&" + "oth_cr_OPS=" + iformObj.getValue("oth_cr_OPS") + "&" + "oth_cr_DC=" + iformObj.getValue("oth_cr_DC") + "&" + "oth_cr_BN=" + iformObj.getValue("oth_cr_BN") + "&" + "oth_cr_RR=" + str10 + "&" + "oth_ssc_Amount=" + iformObj.getValue("oth_ssc_Amount") + "&" + "oth_ssc_SCNo=" + iformObj.getValue("oth_ssc_SCNo") + "&" + "oth_ssc_RR=" + str13 + "&" + "oth_ecr_RB=" + iformObj.getValue("oth_ecr_RB") + "&" + "oth_ecr_RR=" + str8 + "&" + "oth_ecr_dt=" + iformObj.getValue("oth_ecr_dt") + "&" + "oth_ecr_bn=" + iformObj.getValue("oth_ecr_bn") + "&" + "oth_cli_type=" + iformObj.getValue("oth_cli_type") + "&" + "oth_cli_months=" + iformObj.getValue("oth_cli_months") + "&" + "oth_cli_RR=" + str11 + "&" + "oth_cdr_CDT=" + iformObj.getValue("oth_cdr_CDT") + "&" + "oth_cdr_BN=" + iformObj.getValue("OTH_CDR_BN") + "&" + "oth_cdr_RR=" + str6 + "&" + "BU_UserName=" + iformObj.getValue("IntroducedBy") + "&" + "request_type=" + iformObj.getValue("request_type") + "&" + "BR_Remarks=" + str3;
				CSR_OCC.mLogger.debug("ParamValues :"+ParamValues);
				strReturn=ParamValues;
				//Object result = localJSObject.call("callPrintJSPCSROCC", arrayOfString);
				//CSR_OCC.mLogger.debug("result is " + result.toString());
			}			
		}		
		catch(Exception exc)
		{
			CSR_OCC.printException(exc);
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception 2 - "+exc);
		}	
		return strReturn;
	}
	
	/*public String getImages(String tempImagePath,String debt_acc_num,String[] imageArr,String[] remarksArr)
	{

		if(imageArr==null)
			return "";
		for (int i=0;i<imageArr.length;i++)
		{
			try
			{	
				CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Inside Get Images 0");
				byte[] btDataFile = new sun.misc.BASE64Decoder().decodeBuffer(imageArr[i]);
				//File of = new File(filePath+debt_acc_num+"imageCreatedN"+i+".jpg");
				String imagePath = System.getProperty("user.dir")+tempImagePath+System.getProperty("file.separator")+debt_acc_num+"imageCreatedN"+i+".jpg";
				CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", imagePath"+imagePath);
				File of = new File(imagePath);
				
				FileOutputStream osf = new FileOutputStream(of);
				osf.write(btDataFile);
				osf.flush();
				osf.close();
			}
			catch (Exception e)
			{
				CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Not able to get the image imageCreated"+e);
				CSR_OCC.mLogger.debug( e.getMessage());
				e.printStackTrace();				
			}
		}
		//WriteLog( html.toString());
		return "";
	}*/
	
	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
		   CharacterData cd = (CharacterData) child;
		   return cd.getData();
		}
		return "NO_DATA";
	}
	
	public String MQ_connection_response(IFormReference iformObj,String control,String Data) 
	{
		
	CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Inside MQ_connection_response function");
	final IFormReference iFormOBJECT;
	final WDGeneralData wdgeneralObj;	
	Socket socket = null;
	OutputStream out = null;
	InputStream socketInputStream = null;
	DataOutputStream dout = null;
	DataInputStream din = null;
	String mqOutputResponse = null;
	String mqOutputResponse1 = null;
	String mqInputRequest = null;	
	String cabinetName = getCabinetName();
	String wi_name = getWorkitemName();
	String ws_name = getActivityName();
	String sessionID = getSessionId();
	String userName = getUserName();
	String socketServerIP;
	int socketServerPort;
	wdgeneralObj = iformObj.getObjGeneralData();
	sessionID = wdgeneralObj.getM_strDMSSessionId();
	String CIFNumber="";	
	String CallName="";
	
	if(control.equals("btn_View_Signature"))
	{
		CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Inside btn_View_Signature control--");
		String acc_selected = Data;
		CallName="SIGNATURE_DETAILS";
		String selectedCIFNumber = getControlValue("CIF_ID");
		CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", $$selectedCIFNumber "+selectedCIFNumber);
		StringBuilder finalXml = new StringBuilder("<EE_EAI_MESSAGE>\n"+
				"<EE_EAI_HEADER>\n"+
				"<MsgFormat>SIGNATURE_DETAILS</MsgFormat>\n"+
				"<MsgVersion>0001</MsgVersion>\n"+
				"<RequestorChannelId>BPM</RequestorChannelId>\n"+
				"<RequestorUserId>RAKUSER</RequestorUserId>\n"+
				"<RequestorLanguage>E</RequestorLanguage>\n"+
				"<RequestorSecurityInfo>secure</RequestorSecurityInfo>\n"+
				"<ReturnCode>911</ReturnCode>\n"+
				"<ReturnDesc>Issuer Timed Out</ReturnDesc>\n"+
				"<MessageId>MDL053169111</MessageId>\n"+
				"<Extra1>REQ||PERCOMER.PERCOMER</Extra1>\n"+
				"<Extra2>2007-01-01T10:30:30.000Z</Extra2>\n"+
				"</EE_EAI_HEADER>\n"+
				"<SignatureDetailsReq><BankId>RAK</BankId><CustId></CustId><AcctId>"+acc_selected+"</AcctId></SignatureDetailsReq>\n"+
				"</EE_EAI_MESSAGE>");
	mqInputRequest = getMQInputXML(sessionID, cabinetName,wi_name, ws_name, userName, finalXml);
	CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", mqInputRequest for Signature Details call" + mqInputRequest);
	}
	
	try {
	
	CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", userName "+ userName);
	CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", sessionID "+ sessionID);
	
	String sMQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_RLOS_MQ_TABLE with (nolock) where host_name = 'mq'";
	List<List<String>> outputMQXML = iformObj.getDataFromDB(sMQuery);
	//CreditCard.mLogger.info("$$outputgGridtXML "+ "sMQuery " + sMQuery);
	if (!outputMQXML.isEmpty()) {
		//CreditCard.mLogger.info("$$outputgGridtXML "+ outputMQXML.get(0).get(0) + "," + outputMQXML.get(0).get(1));
		socketServerIP = outputMQXML.get(0).get(0);
		CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", socketServerIP " + socketServerIP);
		socketServerPort = Integer.parseInt(outputMQXML.get(0).get(1));
		CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", socketServerPort " + socketServerPort);
		
		CSR_OCC.mLogger.debug(" outside socket"+socket);
		
		if (!("".equalsIgnoreCase(socketServerIP) && socketServerIP == null && socketServerPort==0)) {
			socket = new Socket(socketServerIP, socketServerPort);
			
			int connection_timeout=60;
				try{
					connection_timeout=70;
					//connection_timeout = Integer.parseInt(NGFUserResourceMgr_CreditCard.getGlobalVar("Integration_Connection_Timeout"));
				}
				catch(Exception e){
					connection_timeout=60;
				}
				
			socket.setSoTimeout(connection_timeout*1000);
			out = socket.getOutputStream();
			
			CSR_OCC.mLogger.debug("connection timeout"+connection_timeout);
			CSR_OCC.mLogger.debug(" inside socket"+socket);	
			CSR_OCC.mLogger.debug("out" +out);
			
			socketInputStream = socket.getInputStream();
			
			CSR_OCC.mLogger.debug("socketInputStream"+socketInputStream);
			
			dout = new DataOutputStream(out);
			din = new DataInputStream(socketInputStream);
			
			CSR_OCC.mLogger.debug("dout"+dout);
			CSR_OCC.mLogger.debug("din"+din);
			
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", dout " + dout);
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", din " + din);
			mqOutputResponse = "";
			mqOutputResponse1 = "";
			
	
			if (mqInputRequest != null && mqInputRequest.length() > 0) {
				int outPut_len = mqInputRequest.getBytes("UTF-16LE").length;
				CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Final XML output len: "+outPut_len + "");
				mqInputRequest = outPut_len + "##8##;" + mqInputRequest;
				CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", MqInputRequest"+"Input Request Bytes : "+ mqInputRequest.getBytes("UTF-16LE"));
				dout.write(mqInputRequest.getBytes("UTF-16LE"));dout.flush();
			}
			byte[] readBuffer = new byte[500];
			int num = din.read(readBuffer);
			if (num > 0) {
	
				byte[] arrayBytes = new byte[num];
				System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
				mqOutputResponse = mqOutputResponse+ new String(arrayBytes, "UTF-16LE");
				CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", mqOutputResponse/message ID :  "+mqOutputResponse);
				
				mqOutputResponse1 = mqOutputResponse1+ new String(arrayBytes, "UTF-16LE");
				CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", mqOutputResponse1/message ID :  "+mqOutputResponse1+", CallName :"+CallName);
								
				if(!"".equalsIgnoreCase(mqOutputResponse) && control.equalsIgnoreCase("btn_View_Signature"))
				{
					mqOutputResponse = getOutWtthMessageID(CallName,iformObj,mqOutputResponse);
				}
				
					
				if(mqOutputResponse.contains("&lt;")){
					mqOutputResponse=mqOutputResponse.replaceAll("&lt;", "<");
					mqOutputResponse=mqOutputResponse.replaceAll("&gt;", ">");
				}
			}
			socket.close();
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", mqOutputResponse::::::::::::  "+mqOutputResponse);
			return mqOutputResponse;
			
		} else {
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", SocketServerIp and SocketServerPort is not maintained "+"");
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", SocketServerIp is not maintained "+	socketServerIP);
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", SocketServerPort is not maintained "+	socketServerPort);
			return "MQ details not maintained";
		}
	} else {
		CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", SOcket details are not maintained in NG_RLOS_MQ_TABLE table"+"");
		return "MQ details not maintained";
	}
	
	} catch (Exception e) {
		CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception Occured Mq_connection_CC"+e.getStackTrace());
	return "";
	}
	finally{
	try{
		if(out != null){
			
			out.close();
			out=null;
			}
		if(socketInputStream != null){
			
			socketInputStream.close();
			socketInputStream=null;
			}
		if(dout != null){
			
			dout.close();
			dout=null;
			}
		if(din != null){
			
			din.close();
			din=null;
			}
		if(socket != null){
			if(!socket.isClosed()){
				socket.close();
			}
			socket=null;
		}
	}catch(Exception e)
	{
		CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Final Exception Occured Mq_connection_CC"+e.getStackTrace());
		//printException(e);
	}
	}
	}
	
	
	private static String getMQInputXML(String sessionID, String cabinetName,
			String wi_name, String ws_name, String userName,
			StringBuilder final_xml) {
		//FormContext.getCurrentInstance().getFormConfig();
		CSR_OCC.mLogger.debug("inside getMQInputXML function");
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("<APMQPUTGET_Input>");
		strBuff.append("<SessionId>" + sessionID + "</SessionId>");
		strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
		strBuff.append("<XMLHISTORY_TABLENAME>"+XMLLOG_HISTORY+"</XMLHISTORY_TABLENAME>");
		strBuff.append("<WI_NAME>" + wi_name + "</WI_NAME>");
		strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
		strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
		strBuff.append("<MQ_REQUEST_XML>");
		strBuff.append(final_xml);
		strBuff.append("</MQ_REQUEST_XML>");
		strBuff.append("</APMQPUTGET_Input>");
		return strBuff.toString();
	}
		
	public String getOutWtthMessageID(String callName,IFormReference iformObj,String message_ID){
		String outputxml="";
		try{
			CSR_OCC.mLogger.debug("getOutWtthMessageID - callName :"+callName);
			//String wi_name = iformObj.getWFWorkitemName();
			String wi_name = getWorkitemName();
			String str_query = "select OUTPUT_XML from "+ XMLLOG_HISTORY +" with (nolock) where CALLNAME ='"+callName+"' and MESSAGE_ID ='"+message_ID+"' and WI_NAME = '"+wi_name+"'";
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", inside getOutWtthMessageID str_query: "+ str_query);
			List<List<String>> result=iformObj.getDataFromDB(str_query);
			//below code added by nikhil 18/10 for Connection timeout
			//String Integration_timeOut=NGFUserResourceMgr_CreditCard.getGlobalVar("Inegration_Wait_Count");
			String Integration_timeOut="100";
			int Loop_wait_count=10;
			try
			{
				Loop_wait_count=Integer.parseInt(Integration_timeOut);
			}
			catch(Exception ex)
			{
				Loop_wait_count=10;
			}
		
			for(int Loop_count=0;Loop_count<Loop_wait_count;Loop_count++){
				if(result.size()>0){
					outputxml = result.get(0).get(0);
					break;
				}
				else{
					Thread.sleep(1000);
					result=iformObj.getDataFromDB(str_query);
				}
			}
			
			if("".equalsIgnoreCase(outputxml)){
				outputxml="Error";
			}
			CSR_OCC.mLogger.debug("This is output xml from DB");
			String outputxmlMasked = outputxml;
			CSR_OCC.mLogger.debug("The output XML is "+outputxml);
			outputxmlMasked = maskXmlogBasedOnCallType(outputxmlMasked,callName);    //uncomment it at UAT
			CSR_OCC.mLogger.debug("Masked output XML is "+outputxmlMasked);
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", getOutWtthMessageID" + outputxmlMasked);				
		}
		catch(Exception e){
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception occurred in getOutWtthMessageID" + e.getMessage());
			CSR_OCC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception occurred in getOutWtthMessageID" + e.getStackTrace());
			outputxml="Error";
		}
		return outputxml;
	}
	
	public String maskXmlogBasedOnCallType(String outputxmlMasked, String callType)
	{
		String Tags = "";
		if (callType.equalsIgnoreCase("CUSTOMER_DETAILS"))
		{
			outputxmlMasked = outputxmlMasked.replace("("," ").replace(")"," ").replace("@"," ").replace("+"," ").replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
			Tags = "<ACCNumber>~,~<AccountName>~,~<ECRNumber>~,~<DOB>~,~<MothersName>~,~<IBANNumber>~,~<DocId>~,~<DocExpDt>~,~<DocIssDate>~,~<PassportNum>~,~<MotherMaidenName>~,~<LinkedDebitCardNumber>~,~<FirstName>~,~<MiddleName>~,~<LastName>~,~<FullName>~,~<ARMCode>~,~<ARMName>~,~<PhnCountryCode>~,~<PhnLocalCode>~,~<PhoneNo>~,~<EmailID>~,~<CustomerName>~,~<CustomerMobileNumber>~,~<PrimaryEmailId>~,~<Fax>~,~<AddressType>~,~<AddrLine1>~,~<AddrLine2>~,~<AddrLine3>~,~<AddrLine4>~,~<POBox>~,~<City>~,~<Country>~,~<AddressLine1>~,~<AddressLine2>~,~<AddressLine3>~,~<AddressLine4>~,~<CityCode>~,~<State>~,~<CountryCode>~,~<Nationality>~,~<ResidentCountry>~,~<PrimaryContactName>~,~<PrimaryContactNum>~,~<SecondaryContactName>~,~<SecondaryContactNum>";
			
		}

			else if (callType.equalsIgnoreCase("ACCOUNT_SUMMARY"))
		{
			outputxmlMasked = outputxmlMasked.replace("("," ").replace(")"," ").replace("@"," ").replace("+"," ").replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
			Tags = "<Acid>~,~<Foracid>~,~<NicName>~,~<AccountName>~,~<AcctBal>~,~<LoanAmtAED>~,~<AcctOpnDt>~,~<MaturityAmt>~,~<EffAvailableBal>~,~<EquivalentAmt>~,~<LedgerBalanceinAED>~,~<LedgerBalance>";
		}
		else if (callType.equalsIgnoreCase("SIGNATURE_DETAILS"))
		{
			outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
			Tags = "<CustomerName>";
		}
		if (!Tags.equalsIgnoreCase(""))
		{
	    	String Tag[] = Tags.split("~,~");
	    	for(int i=0;i<Tag.length;i++)
	    	{
	    		outputxmlMasked = maskXmlTags(outputxmlMasked,Tag[i]);
	    	}
		}
    	return outputxmlMasked;
	}
	
}


