package com.newgen.iforms.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import javax.swing.JOptionPane;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormXmlResponse;

import netscape.javascript.JSObject;

public class CSR_BT_Click extends CSR_BTCommon {

	HashMap CAPDataHT = new HashMap();
	HashMap map = new HashMap();

	public String clickEvent(IFormReference iform, String controlName, String data) {

		String strReturn = "";
		try {

			CSR_BT.mLogger.debug("inside CSR_BT_click");
			if (controlName.equalsIgnoreCase("Refresh")) {
				String sTempCardDetails = "";
				String sSQL = "";
				int iCAPSCardCount = 0;
				int i = 1;

				Connection conn = null;
				Statement stmt = null;
				//Statement stmt1 = null;
				// PreparedStatement stmt=null;
				ResultSet result = null;
				ResultSet result1 = null;
				try {

					String actname = iform.getActivityName();
					String credit = ((String) iform.getValue("CreditCardNo1")).replaceAll("-", "");

					String value1 = validateCCNo(credit);
					if (value1.equalsIgnoreCase("ValidCard")) {
						// CSR_OCC.mLogger.debug(actname);
						CSR_BT.mLogger.debug("inside CSR_BT_click credit" + credit);

						Context aContext = new InitialContext();
						DataSource aDataSource = (DataSource) aContext.lookup("jdbc/cbop");
						conn = (Connection) (aDataSource.getConnection());
						CSR_BT.mLogger.debug("got data source");
						// stmt = conn.createStatement();

						sSQL = "Select LTRIM(RTRIM(FirstName)), LTRIM(RTRIM(MiddleName)), LTRIM(RTRIM(LastName)), "
								+ "substr(to_char(EXPIRYDATE,'dd/mm/yy'),4,length(to_char(EXPIRYDATE,'dd/mm/yy'))), "
								+ "CRNNO, MOBILE,ASSESSEDINCOME,CARDTYPE,generalstat,elitecustomerno  from CAPSMAIN where "
								+ "CREDITCARDNO='" + credit + "'";

//					List lstDecisions = iform.getDataFromDB(
//							"Select LTRIM(RTRIM(FirstName)), LTRIM(RTRIM(MiddleName)), LTRIM(RTRIM(LastName)), substring(format(EXPIRYDATE,'dd/mm/yy'),4,LEN(format(EXPIRYDATE,'dd/mm/yy'))), CRNNO, MOBILE,ASSESSEDINCOME,CARDTYPE,generalstat,elitecustomerno  from rak_bpm.dbo.CAPSMAIN where  CREDITCARDNO='"
//									+ credit + "'");
						// substr(to_char(EXPIRYDATE,'dd/mm/yy'),4,length(to_char(EXPIRYDATE,'dd/mm/yy')))
						stmt = conn.createStatement();
						// stmt = conn.prepareStatement(sSQL);
						CSR_BT.mLogger.debug("sSQL ::" + sSQL);

						result = stmt.executeQuery(sSQL);
						CSR_BT.mLogger.debug("result stmt::" + result);
						CSR_BT.mLogger.debug("lstDecisions size" + result.getFetchSize());
						if (result.getFetchSize() != 0) {
							String value = "";
							String CRNNO = "";
							String MOBILE = "";
							String ASSESSEDINCOME = "";
							String CARDTYPE = "";
							String generalstat = "";
							String elitecustomerno = "";
							String MiddleName = "";
							String LastName = "";
							String ExpD = "";

							iform.clearCombo("CCI_CName");
							iform.clearCombo("CCI_ExpD");
							iform.clearCombo("CCI_CCRNNo");
							iform.clearCombo("CCI_MONO");
							iform.clearCombo("CCI_AccInc");
							iform.clearCombo("CCI_CT");
							iform.clearCombo("CCI_CAPS_GENSTAT");
							iform.clearCombo("CCI_ELITECUSTNO");
							iform.clearCombo("CCI_CrdtCN");

							while (result.next()) {
								value = result.getString(1);
								CSR_BT.mLogger.debug("value size" + value);
								MiddleName = result.getString(2);
								LastName = result.getString(3);
								// sCustomerName=sFirstName+" "+sMiddleName+" "+sLastName;
								ExpD = result.getString(4);
								CRNNO = result.getString(5);
								MOBILE = result.getString(6);
								ASSESSEDINCOME = new Integer(result.getInt(7)).toString();
								CARDTYPE = result.getString(8);
								generalstat = result.getString(9);
								CSR_BT.mLogger.debug("generalstat size" + generalstat);
								elitecustomerno = result.getString(10);
								CSR_BT.mLogger.debug("elitecustomerno size" + elitecustomerno);

								// iform.addItemInCombo("BTD_OBC_BN",value,value);
								iform.setValue("CCI_CName", value + " " + MiddleName + " " + LastName);
								iform.setValue("CCI_ExpD", ExpD);
								iform.setValue("CCI_ExpD", "Masked");
								iform.setValue("CCI_CCRNNo", CRNNO);
								iform.setValue("CCI_MONO", MOBILE);
								iform.setValue("CCI_AccInc", ASSESSEDINCOME);
								iform.setValue("CCI_CT", CARDTYPE);
								iform.setValue("CCI_CAPS_GENSTAT", generalstat);
								iform.setValue("CCI_ELITECUSTNO", elitecustomerno);
								iform.setValue("CCI_CrdtCN", credit);
								strReturn = "Fetch Card Details successfully";
							}

							String sSQL1 = "select creditcardno,CARDTYPE,substr(to_char(EXPIRYDATE,'dd/mm/yy'),4,length(to_char(EXPIRYDATE,'dd/mm/yy'))) from capsmain where elitecustomerno=(select elitecustomerno from capsmain where creditcardno='"
									+ credit + "') and substr(CREDITCARDNO,14,1)<>'0'";

							CSR_BT.mLogger.debug("value sSQL1 :: " + sSQL1);

							//stmt1 = conn.createStatement();
							result1 = stmt.executeQuery(sSQL1);
							CSR_BT.mLogger.debug("result stmt::" + result1);
							CSR_BT.mLogger.debug("result1 size" + result1.getFetchSize());

							while (result1.next()) {
								String sValue = result1.getString(1);
								if (sTempCardDetails.equals(""))
									sTempCardDetails = sValue;
								else
									sTempCardDetails = sTempCardDetails + sValue;
								CAPDataHT.put("RAKBankCard" + i, sValue);
								sValue = result1.getString(2);
								sTempCardDetails = sTempCardDetails + "!" + sValue;
								CAPDataHT.put("CardType" + i, sValue);
								sValue = result1.getString(3);
								sTempCardDetails = sTempCardDetails + "!" + sValue;
								CAPDataHT.put("ExpDate" + i, sValue);
								sTempCardDetails = sTempCardDetails + "!";
								i++;
							}
							iCAPSCardCount = i - 1;
							sTempCardDetails = iCAPSCardCount + "@" + sTempCardDetails;
							iform.setValue("cardDetails", sTempCardDetails);
							CSR_BT.mLogger.debug("cardDetails :" + iform.getValue("cardDetails"));
							// iform.clearCombo("oth_ssc_SCNo_Combo");
							iform.clearCombo("BTD_RBC_RBCN1");
							iform.clearCombo("BTD_RBC_RBCN2");
							iform.clearCombo("BBTD_RBC_RBCN3");
							CSR_BT.mLogger.debug("iCAPSCardCount :" + iCAPSCardCount);
							for (int i1 = 1; i1 <= iCAPSCardCount; i1++) {
								iform.addItemInCombo("BTD_RBC_RBCN1", CAPDataHT
										.get(new StringBuilder().append("RAKBankCard").append(i1).toString()).toString()
										.substring(0, 4)
										+ "-"
										+ CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
												.toString().substring(4, 8)
										+ "-"
										+ CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
												.toString().substring(8, 12)
										+ "-"
										+ CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
												.toString().substring(12, 16));
								/* 2915 */ iform.addItemInCombo("BTD_RBC_RBCN2", CAPDataHT
										.get(new StringBuilder().append("RAKBankCard").append(i1).toString()).toString()
										.substring(0, 4)
										+ "-"
										+ CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
												.toString().substring(4, 8)
										+ "-"
										+ CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
												.toString().substring(8, 12)
										+ "-"
										+ CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
												.toString().substring(12, 16));
								/* 2916 */ iform.addItemInCombo("BTD_RBC_RBCN3", CAPDataHT
										.get(new StringBuilder().append("RAKBankCard").append(i1).toString()).toString()
										.substring(0, 4)
										+ "-"
										+ CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
												.toString().substring(4, 8)
										+ "-"
										+ CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
												.toString().substring(8, 12)
										+ "-"
										+ CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
												.toString().substring(12, 16));
								/*      */ }
							/* 2918 */ iform.setValue("BTD_RBC_RBCN1", "");
							/* 2919 */ iform.setValue("BTD_RBC_RBCN2", "");
							/* 2920 */ iform.setValue("BTD_RBC_RBCN3", "");

							/*      */CSR_BT.mLogger.debug("test--234");
						} else {
							strReturn = "Given Card Details is not Present";
						}

					} else {
						strReturn = "Invalid Crad Number format";
					}
					if (result != null) {
						result.close();
						result = null;
						CSR_BT.mLogger.debug("resultset Successfully closed");
					}
					if (stmt != null) {
						stmt.close();
						stmt = null;
						CSR_BT.mLogger.debug("Stmt Successfully closed");
					}
					if (conn != null) {
						conn.close();
						conn = null;
						CSR_BT.mLogger.debug("Conn Successfully closed");
					}
				} catch (java.sql.SQLException e) {
					CSR_BT.mLogger.debug(e.toString());
					if (e.getClass().toString().equalsIgnoreCase("Class javax.naming.NameNotFoundException"))
						CSR_BT.mLogger.debug("<script>alert(\"Data Source For CAPS System Not Found\")</script>");

					else if (e.toString().indexOf("Operation timed out: connect:could be due to invalid address") != -1)
						CSR_BT.mLogger.debug("<script>alert(\"Unable to connect to CAPS System\")</script>");

					else {
						CSR_BT.mLogger.debug("<script>alert(\"Unable to connect to CAPS System\")</script>");
					}

				}

//				/*	List lstDecisions = null;
//						//	iform.getDataFromDB(
//						//	"Select LTRIM(RTRIM(FirstName)), LTRIM(RTRIM(MiddleName)), LTRIM(RTRIM(LastName)), substring(format(EXPIRYDATE,'dd/mm/yy'),4,LEN(format(EXPIRYDATE,'dd/mm/yy'))), CRNNO, MOBILE,ASSESSEDINCOME,CARDTYPE,generalstat,elitecustomerno  from rak_bpm.dbo.CAPSMAIN where  CREDITCARDNO='"
//								//	+ credit + "'");
//					
//					if (lstDecisions.size() != 0) {
//					/*	for (int i = 0; i < lstDecisions.size(); i++) {
//							CSR_BT.mLogger.debug("lstDecisions size" + lstDecisions.size());
//							List<String> arr1 = (List) lstDecisions.get(i);
//							value = arr1.get(0);
//							MiddleName = arr1.get(1);
//							LastName = arr1.get(2);
//							ExpD = arr1.get(3);
//							CRNNO = arr1.get(4);
//							MOBILE = arr1.get(5);
//							ASSESSEDINCOME = arr1.get(6);
//							CARDTYPE = arr1.get(7);
//							generalstat = arr1.get(8);
//							elitecustomerno = arr1.get(9);
//							// iform.addItemInCombo("BTD_OBC_BN",value,value);
//							iform.setValue("CCI_CName", value + " " + MiddleName + " " + LastName);
//							iform.setValue("CCI_ExpD", ExpD);
//							iform.setValue("CCI_ExpD", "Masked");
//							iform.setValue("CCI_CCRNNo", CRNNO);
//							iform.setValue("CCI_MONO", MOBILE);
//							iform.setValue("CCI_AccInc", ASSESSEDINCOME);
//							iform.setValue("CCI_CT", CARDTYPE);
//							iform.setValue("CCI_CAPS_GENSTAT", generalstat);
//							iform.setValue("CCI_ELITECUSTNO", elitecustomerno);
//							iform.setValue("CCI_CrdtCN", credit); */
//							//strReturn = "Fetch Card Details successfully";
//						//}
//					
//							String str1 = "select creditcardno,CARDTYPE,substring(format(EXPIRYDATE,'dd/mm/yy'),4,LEN(format(EXPIRYDATE,'dd/mm/yy'))) from rak_bpm.dbo.capsmain where elitecustomerno=(select elitecustomerno from rak_bpm.dbo.capsmain where creditcardno='"
//									+ credit + "') and substring(CREDITCARDNO,14,1)<>'0'";
//							List lstDecisions1 = iform.getDataFromDB(str1);
//							CSR_BT.mLogger.debug("lstDecisions1 :" + lstDecisions1);
//							Object localObject = "";
//							int j = 0;
//							int k = 0;
//							String str13 = "";
//							if (lstDecisions1 != null) {
//								CAPDataHT.clear();
//								for (int l = 0; l < lstDecisions1.size(); l++) {
//									k++;
//									List arr2 = (List) lstDecisions1.get(l);
//									str13 = (String) arr2.get(0);
//
//									if ((String) localObject == "") {
//										localObject = str13;
//									} else {
//										localObject = (String) localObject + str13;
//									}
//									CAPDataHT.put("RAKBankCard" + k, str13);
//									CSR_BT.mLogger.debug("k :" + k + " CAPDataHT :"
//											+ CAPDataHT.get(new StringBuilder("RAKBankCard").append(k).toString()));
//
//									str13 = (String) arr2.get(1);
//									localObject = (String) localObject + "!" + str13;
//									CAPDataHT.put("CardType" + k, str13);
//									CSR_BT.mLogger.debug("k :" + k + " CAPDataHT :"
//											+ CAPDataHT.get(new StringBuilder("CardType").append(k).toString()));
//
//									str13 = (String) arr2.get(2);
//									localObject = (String) localObject + "!" + str13;
//									CAPDataHT.put("ExpDate" + k, str13);
//									CSR_BT.mLogger.debug("k :" + k + " CAPDataHT :"
//											+ CAPDataHT.get(new StringBuilder("ExpDate").append(k).toString()));
//									localObject = (String) localObject + "!";
//									j++;
//								}
//
//								localObject = j + "@" + (String) localObject;
//								CSR_BT.mLogger.debug("localObject :" + localObject);
//								// str13 = iform.getValue("oth_ssc_SCNo").toString();
//								iform.setValue("cardDetails", (String) localObject);
//								CSR_BT.mLogger.debug("cardDetails :" + iform.getValue("cardDetails"));
//								// iform.clearCombo("oth_ssc_SCNo_Combo");
//								iform.clearCombo("BTD_RBC_RBCN11");
//								iform.clearCombo("BTD_RBC_RBCN22");
//								iform.clearCombo("BBTD_RBC_RBCN33");
//								CSR_BT.mLogger.debug("j :" + j);
//								for (int i1 = 1; i1 <= j; i1++) {
//									iform.addItemInCombo("BTD_RBC_RBCN11", CAPDataHT
//											.get(new StringBuilder().append("RAKBankCard").append(i1).toString())
//											.toString().substring(0, 4)
//											+ "-"
//											+ CAPDataHT.get(
//													new StringBuilder().append("RAKBankCard").append(i1).toString())
//													.toString().substring(4, 8)
//											+ "-"
//											+ CAPDataHT.get(
//													new StringBuilder().append("RAKBankCard").append(i1).toString())
//													.toString().substring(8, 12)
//											+ "-"
//											+ CAPDataHT.get(
//													new StringBuilder().append("RAKBankCard").append(i1).toString())
//													.toString().substring(12, 16));
//									/* 2915 */ iform
//											.addItemInCombo("BTD_RBC_RBCN22",
//													CAPDataHT
//															.get(new StringBuilder().append("RAKBankCard").append(i1)
//																	.toString())
//															.toString().substring(0, 4)
//															+ "-"
//															+ CAPDataHT.get(new StringBuilder().append("RAKBankCard")
//																	.append(i1).toString()).toString().substring(4, 8)
//															+ "-"
//															+ CAPDataHT.get(new StringBuilder().append("RAKBankCard")
//																	.append(i1).toString()).toString().substring(8, 12)
//															+ "-"
//															+ CAPDataHT
//																	.get(new StringBuilder().append("RAKBankCard")
//																			.append(i1).toString())
//																	.toString().substring(12, 16));
//									/* 2916 */ iform
//											.addItemInCombo("BTD_RBC_RBCN33",
//													CAPDataHT
//															.get(new StringBuilder().append("RAKBankCard").append(i1)
//																	.toString())
//															.toString().substring(0, 4)
//															+ "-"
//															+ CAPDataHT.get(new StringBuilder().append("RAKBankCard")
//																	.append(i1).toString()).toString().substring(4, 8)
//															+ "-"
//															+ CAPDataHT.get(new StringBuilder().append("RAKBankCard")
//																	.append(i1).toString()).toString().substring(8, 12)
//															+ "-"
//															+ CAPDataHT
//																	.get(new StringBuilder().append("RAKBankCard")
//																			.append(i1).toString())
//																	.toString().substring(12, 16));
//									/*      */ }
//								/* 2918 */ iform.setValue("BTD_RBC_RBCN11", "");
//								/* 2919 */ iform.setValue("BTD_RBC_RBCN22", "");
//								/* 2920 */ iform.setValue("BTD_RBC_RBCN33", "");
//
//								/*      */CSR_BT.mLogger.debug("test--234");
//
//								// strReturn = "Fetch Card Details successfully";
//							}
//						
//					} else if (lstDecisions.size() == 0) {
//						strReturn = "Given Fetch Card Details is not Present";
//
//					}

			} else if (controlName.equalsIgnoreCase("BTD_OBC_OBCNO")) {
				CSR_BT.mLogger.debug("inside BTD_OBC_OBCNO other bank card check ");
				if (iform.getValue("BTD_OBC_OBCNO") != "") {
					CSR_BT.mLogger.debug("inside other bank card check " + (String) iform.getValue("BTD_OBC_OBCNO"));
					String CardNo = ((String) iform.getValue("BTD_OBC_OBCNO")).replaceAll("-", "");
					String CardNOValidation = validateCCNo(CardNo);

					CSR_BT.mLogger.debug("inside CardNOValidation " + CardNOValidation);
					if (CardNOValidation.equalsIgnoreCase("ValidCard")) {
						strReturn = "ValidCard";
					} else {
						strReturn = "Invalid Card Number format";
						iform.clearCombo("BTD_OBC_OBCNO");
					}

				}
			}

			/*
			 * else if (controlName.equalsIgnoreCase("VD_TINCheck")) {
			 * CSR_BT.mLogger.debug("inside VD_TINCheck "); if ((boolean)
			 * iform.getValue("VD_TINCheck") == true) { iform.setStyle("VD_MoMaidN",
			 * "disable", "false"); iform.setStyle("VD_POBox", "disable", "false");
			 * iform.setStyle("VD_TELNO", "disable", "false"); iform.setStyle("VD_PassNo",
			 * "disable", "false"); iform.setStyle("VD_MRT", "disable", "false");
			 * iform.setStyle("VD_Oth", "disable", "false"); iform.setStyle("VD_SD",
			 * "disable", "false"); iform.setStyle("VD_EDC", "disable", "false");
			 * iform.setStyle("VD_StaffId", "disable", "false"); iform.setStyle("VD_DOB",
			 * "disable", "false"); iform.setStyle("VD_NOSC", "disable", "false"); strReturn
			 * = "check"; } else if ((boolean) iform.getValue("VD_TINCheck") == false) {
			 * CSR_BT.mLogger.debug("inside VD_TINCheck"); iform.setStyle("VD_MoMaidN",
			 * "disable", "true"); iform.setStyle("VD_POBox", "disable", "true");
			 * iform.setStyle("VD_TELNO", "disable", "true"); iform.setStyle("VD_PassNo",
			 * "disable", "true"); iform.setStyle("VD_MRT", "disable", "true");
			 * iform.setStyle("VD_Oth", "disable", "true"); iform.setStyle("VD_SD",
			 * "disable", "true"); iform.setStyle("VD_EDC", "disable", "true");
			 * iform.setStyle("VD_StaffId", "disable", "true"); iform.setStyle("VD_DOB",
			 * "disable", "true"); iform.setStyle("VD_NOSC", "disable", "true"); strReturn =
			 * "check"; } }
			 */

			else if (controlName.equalsIgnoreCase("BttnPrint")) {

				Object localJSObject = "";
				CSR_BT.mLogger.debug("BttnPrint inside");
				CSR_BT.mLogger.debug("localJSObject ::" + localJSObject.toString());
				String str2 = "";
				String str3 = "";
				String str4 = "";
				str2 = ((String) iform.getValue("Cards_Remarks")).replace("&", "ampersand");
				str2 = str2.replace("=", "equalsopt");
				str2 = str2.replace("%", "percentageopt");
				str3 = ((String) iform.getValue("BA_REMARKS")).replace("&", "ampersand");
				str4 = ((String) iform.getValue("BTD_RBC_RR")).replace("&", "ampersand");
				str4 = str4.replace("=", "equalsopt");
				str4 = str4.replace("%", "percentageopt");
				CSR_BT.mLogger.debug("arrayOfString ::" + str2 + " " + str3 + " " + str4);
				String[] arrayOfString = new String[1];
				arrayOfString[0] = ("CCI_CrdtCN=" + ((String) iform.getValue("CCI_CrdtCN")) + "&" + "CCI_CName="
						+ ((String) iform.getValue("CCI_CName")) + "&" + "CCI_ExpD="
						+ ((String) iform.getValue("CCI_ExpD")) + "&" + "CCI_CCRNNo="
						+ ((String) iform.getValue("CCI_CCRNNo")) + "&" + "CCI_ExtNo="
						+ ((String) iform.getValue("CCI_ExtNo")) + "&" + "CCI_SC=" + ((String) iform.getValue("CCI_SC"))
						+ "&" + "CCI_MONO=" + ((String) iform.getValue("CCI_MONO")) + "&" + "CCI_AccInc="
						+ ((String) iform.getValue("CCI_AccInc")) + "&" + "CCI_CAPS_GENSTAT="
						+ ((String) iform.getValue("CCI_CAPS_GENSTAT")) + "&" + "CCI_ELITECUSTNO="
						+ ((String) iform.getValue("CCI_ELITECUSTNO")) + "&" + "CCI_CT="
						+ ((String) iform.getValue("CCI_CT")) + "&" + "VD_TINCheck="
						+ ((String) iform.getValue("VD_TINCheck")) + "&" + "VD_MoMaidN="
						+ ((String) iform.getValue("VD_MoMaidN")) + "&" + "VD_DOB="
						+ ((String) iform.getValue("VD_DOB")) + "&" + "VD_StaffId="
						+ ((String) iform.getValue("VD_StaffId")) + "&" + "VD_PassNo="
						+ ((String) iform.getValue("VD_PassNo")) + "&" + "VD_POBox="
						+ ((String) iform.getValue("VD_POBox")) + "&" + "VD_Oth=" + ((String) iform.getValue("VD_Oth"))
						+ "&" + "VD_MRT=" + ((String) iform.getValue("VD_MRT")) + "&" + "VD_EDC="
						+ ((String) iform.getValue("VD_EDC")) + "&" + "VD_NOSC=" + ((String) iform.getValue("VD_NOSC"))
						+ "&" + "VD_TELNO=" + ((String) iform.getValue("VD_TELNO")) + "&" + "VD_SD="
						+ ((String) iform.getValue("VD_SD")) + "&" + "wi_name=" + ((String) iform.getValue("wi_name"))
						+ "&" + "processname=CSR_BT" + "&"
						// + "IntroductionDateTime=" + localXMLParser.getValueOf("CreatedDateTime")) +
						// "&"
						+ "IntroductionDateTime=" + (String)iform.getValue("IntroductionDateTime")+ "&" + "BU_UserName=" + (String)iform.getValue("IntroducedBy")+ "&"
						+ "BTD_OBC_NOOC=" + ((String) iform.getValue("BTD_OBC_NOOC")) + "&" + "Cards_Decision="
						+ ((String) iform.getValue("Cards_Decision")) + "&" + "Cards_Remarks=" + str2 + "&"
						+ "BTD_OBC_CT=" + ((String) iform.getValue("BTD_OBC_CT")) + "&" + "BTD_OBC_OBN="
						+ ((String) iform.getValue("BTD_OBC_OBN")) + "&" + "BTD_OBC_OBNO="
						+ ((String) iform.getValue("BTD_OBC_OBNO")) + "&" + "BTD_OBC_OBCNO="
						+ ((String) iform.getValue("BTD_OBC_OBCNO")) + "&" + // "BU_UserName=" +
						// localXMLParser.getValueOf("IntroducedBy")) + "&" +
						"BTD_OBC_DT=" + ((String) iform.getValue("BTD_OBC_DT")) + "&" + "BTD_OBC_BN="
						+ ((String) iform.getValue("BTD_OBC_BN")) + "&" + "BTD_RBC_RBCN1="
						+ ((String) iform.getValue("BTD_RBC_RBCN1")) + "&" + "BTD_RBC_RBCN2="
						+ ((String) iform.getValue("BTD_RBC_RBCN2")) + "&" + "BTD_RBC_RBCN3="
						+ ((String) iform.getValue("BTD_RBC_RBCN3")) + "&" + "BTD_RBC_CT1="
						+ ((String) iform.getValue("BTD_RBC_CT1")) + "&" + "BTD_RBC_CT2="
						+ ((String) iform.getValue("BTD_RBC_CT2")) + "&" + "BTD_RBC_CT3="
						+ ((String) iform.getValue("BTD_RBC_CT3")) + "&" + "BTD_RBC_ExpD1="
						+ ((String) iform.getValue("BTD_RBC_ExpD1")) + "&" + "BTD_RBC_ExpD2="
						+ ((String) iform.getValue("BTD_RBC_ExpD2")) + "&" + "BTD_RBC_ExpD3="
						+ ((String) iform.getValue("BTD_RBC_ExpD3")) + "&" + "BTD_RBC_BTA1="
						+ ((String) iform.getValue("BTD_RBC_BTA1")) + "&" + "BTD_RBC_BTA2="
						+ ((String) iform.getValue("BTD_RBC_BTA2")) + "&" + "BTD_RBC_BTA3="
						+ ((String) iform.getValue("BTD_RBC_BTA3")) + "&" + "BTD_RBC_AppC1="
						+ ((String) iform.getValue("BTD_RBC_AppC1")) + "&" + "BTD_RBC_AppC2="
						+ ((String) iform.getValue("BTD_RBC_AppC2")) + "&" + "BTD_RBC_AppC3="
						+ ((String) iform.getValue("BTD_RBC_AppC3")) + "&" + "BTD_RBC_RR=" + str4);
				CSR_BT.mLogger.debug("arrayOfString ::" + arrayOfString[0]);
				localJSObject = arrayOfString[0];
				CSR_BT.mLogger.debug("localJSObject ::" + localJSObject.toString());
				// ((JSObject) localJSObject).call("callPrintJSPCSRBT", arrayOfString);
				CSR_BT.mLogger.debug("localJSObject ::" + localJSObject.toString());
				strReturn = localJSObject.toString();
			}

			else if (controlName.equalsIgnoreCase("BTD_RBC_RBCN1")) {
				CSR_BT.mLogger.debug("BTD_RBC_RBCN1 inside--");

				String GetCardRet = getCardDetails(iform);
				if (GetCardRet.equalsIgnoreCase("CardDetails values Loaded")) {

					String CardValue = ((String) iform.getValue("BTD_RBC_RBCN1")).replaceAll("-", "");
					CSR_BT.mLogger.debug("CardValue --" + CardValue);
					if (CardValue.equalsIgnoreCase((String) map.get("CardNo0"))
							|| CardValue.equalsIgnoreCase((String) map.get("CardNo3"))
							|| CardValue.equalsIgnoreCase((String) map.get("CardNo6"))) {
						if ("L".equalsIgnoreCase((String) map.get("CardType1"))
								|| "L".equalsIgnoreCase((String) map.get("CardType4"))
								|| "L".equalsIgnoreCase((String) map.get("CardType7"))) {
							// iform.setValue("CSR_BT_RBCN1", "");
							iform.setValue("BTD_RBC_RBCN1", "");
							iform.setValue("BTD_RBC_CT1", "");
							iform.setValue("BTD_RBC_ExpD1", "");
							iform.setValue("BTD_RBC_AppC1", "");
							// iform.setValue("RBC_BTA1", "");
							iform.setValue("BTD_RBC_BTA1", "");
							// iform.setStyle("RBC_BTA1", false);
							iform.setStyle("BTD_RBC_AppC1", "disable", " false");
							// JOptionPane.showMessageDialog(this._objApplet, "Rakbank Card Type L is not
							// allowed!");
							// ((Object) iform).setFocus("CSR_BT_RBCN1");
							strReturn = "Rakbank Card Type L is not allowed!";
						}
						if (CardValue.equalsIgnoreCase((String) map.get("CardNo0"))) {
							CSR_BT.mLogger.debug("(String) map.get(\"CardType1\"):: " + (String) map.get("CardType1"));
							CSR_BT.mLogger.debug("(String) map.get(\"ExpDT2\");:: " + (String) map.get("ExpDT2"));
							iform.setValue("BTD_RBC_CT1", (String) map.get("CardType1"));
							iform.setValue("BTD_RBC_ExpD1", (String) map.get("ExpDT2"));
							iform.setStyle("BTD_RBC_AppC1", "disable", " true");
						} else if (CardValue.equalsIgnoreCase((String) map.get("CardNo3"))) {
							CSR_BT.mLogger.debug("(String) map.get(\"CardType4\"):: " + (String) map.get("CardType4"));
							CSR_BT.mLogger.debug("(String) map.get(\"ExpDT5\");:: " + (String) map.get("ExpDT5"));
							iform.setValue("BTD_RBC_CT1", (String) map.get("CardType4"));
							iform.setValue("BTD_RBC_ExpD1", (String) map.get("ExpDT5"));
							iform.setStyle("BTD_RBC_AppC1", "disable", " true");
						} else if (CardValue.equalsIgnoreCase((String) map.get("CardNo6"))) {
							CSR_BT.mLogger.debug("(String) map.get(\"CardType4\"):: " + (String) map.get("CardType7"));
							CSR_BT.mLogger.debug("(String) map.get(\"ExpDT5\");:: " + (String) map.get("ExpDT8"));
							iform.setValue("BTD_RBC_CT1", (String) map.get("CardType7"));
							iform.setValue("BTD_RBC_ExpD1", (String) map.get("ExpDT8"));
							iform.setStyle("BTD_RBC_AppC1", "disable", " true");

						}
					} else {
						iform.setValue("BTD_RBC_RBCN1", "");
						iform.setValue("BTD_RBC_CT1", "");
						iform.setValue("BTD_RBC_ExpD1", "");
						iform.setValue("BTD_RBC_AppC1", "");
						// iform.setValue("RBC_BTA1", "");
						iform.setValue("BTD_RBC_BTA1", "");
						// iform.setStyle("RBC_BTA1", false);

					}
					strReturn = "BTD_RBC_RBCN1 values loaded";
				} else {
					strReturn = "CardDetails is not present.";
				}

			}

			else if (controlName.equalsIgnoreCase("BTD_RBC_RBCN2"))

			{
				CSR_BT.mLogger.debug("BTD_RBC_RBCN2 inside--");

				String GetCardRet = getCardDetails(iform);
				if (GetCardRet.equalsIgnoreCase("CardDetails values Loaded")) {
					String CardValue = ((String) iform.getValue("BTD_RBC_RBCN2")).replaceAll("-", "");
					CSR_BT.mLogger.debug("CardValue --" + CardValue);
					if (CardValue.equalsIgnoreCase((String) map.get("CardNo0"))
							|| CardValue.equalsIgnoreCase((String) map.get("CardNo3"))
							|| CardValue.equalsIgnoreCase((String) map.get("CardNo6"))) {
						if ("L".equalsIgnoreCase((String) map.get("CardType1"))
								|| "L".equalsIgnoreCase((String) map.get("CardType4"))
								|| "L".equalsIgnoreCase((String) map.get("CardType7"))) {
							// iform.setValue("CSR_BT_RBCN1", "");
							iform.setValue("BTD_RBC_RBCN2", "");
							iform.setValue("BTD_RBC_CT2", "");
							iform.setValue("BTD_RBC_ExpD2", "");
							iform.setValue("BTD_RBC_AppC2", "");
							// iform.setValue("RBC_BTA1", "");
							iform.setValue("BTD_RBC_BTA2", "");
							// iform.setStyle("RBC_BTA1", false);
							iform.setStyle("BTD_RBC_AppC2", "disable", " false");
							// JOptionPane.showMessageDialog(this._objApplet, "Rakbank Card Type L is not
							// allowed!");
							// ((Object) iform).setFocus("CSR_BT_RBCN1");
							strReturn = "Rakbank Card Type L is not allowed!";
						}
						if (CardValue.equalsIgnoreCase((String) map.get("CardNo0"))) {
							CSR_BT.mLogger.debug("(String) map.get(\"CardType1\"):: " + (String) map.get("CardType1"));
							CSR_BT.mLogger.debug("(String) map.get(\"ExpDT2\");:: " + (String) map.get("ExpDT2"));
							iform.setValue("BTD_RBC_CT2", (String) map.get("CardType1"));
							iform.setValue("BTD_RBC_ExpD2", (String) map.get("ExpDT2"));
							iform.setStyle("BTD_RBC_AppC2", "disable", " true");
						} else if (CardValue.equalsIgnoreCase((String) map.get("CardNo3"))) {
							CSR_BT.mLogger.debug("(String) map.get(\"CardType4\"):: " + (String) map.get("CardType4"));
							CSR_BT.mLogger.debug("(String) map.get(\"ExpDT5\");:: " + (String) map.get("ExpDT5"));
							iform.setValue("BTD_RBC_CT2", (String) map.get("CardType4"));
							iform.setValue("BTD_RBC_ExpD2", (String) map.get("ExpDT5"));
							iform.setStyle("BTD_RBC_AppC2", "disable", " true");
						} else if (CardValue.equalsIgnoreCase((String) map.get("CardNo6"))) {
							CSR_BT.mLogger.debug("(String) map.get(\"CardType4\"):: " + (String) map.get("CardType7"));
							CSR_BT.mLogger.debug("(String) map.get(\"ExpDT5\");:: " + (String) map.get("ExpDT8"));
							iform.setValue("BTD_RBC_CT2", (String) map.get("CardType7"));
							iform.setValue("BTD_RBC_ExpD2", (String) map.get("ExpDT8"));
							iform.setStyle("BTD_RBC_AppC2", "disable", " true");

						}
					} else {
						iform.setValue("BTD_RBC_RBCN2", "");
						iform.setValue("BTD_RBC_CT2", "");
						iform.setValue("BTD_RBC_ExpD2", "");
						iform.setValue("BTD_RBC_AppC2", "");
						// iform.setValue("RBC_BTA1", "");
						iform.setValue("BTD_RBC_BTA2", "");
						// iform.setStyle("RBC_BTA1", false);

					}
					strReturn = "BTD_RBC_RBCN2 values loaded";
				} else {
					strReturn = "CardDetails is not present.";
				}
			}

			else if (controlName.equalsIgnoreCase("BTD_RBC_RBCN3")) {

				CSR_BT.mLogger.debug("BTD_RBC_RBCN3 inside--");

				String GetCardRet = getCardDetails(iform);
				if (GetCardRet.equalsIgnoreCase("CardDetails values Loaded")) {
					String CardValue = ((String) iform.getValue("BTD_RBC_RBCN3")).replaceAll("-", "");
					CSR_BT.mLogger.debug("CardValue --" + CardValue);
					if (CardValue.equalsIgnoreCase((String) map.get("CardNo0"))
							|| CardValue.equalsIgnoreCase((String) map.get("CardNo3"))
							|| CardValue.equalsIgnoreCase((String) map.get("CardNo6"))) {
						if ("L".equalsIgnoreCase((String) map.get("CardType1"))
								|| "L".equalsIgnoreCase((String) map.get("CardType4"))
								|| "L".equalsIgnoreCase((String) map.get("CardType7"))) {
							// iform.setValue("CSR_BT_RBCN1", "");
							iform.setValue("BTD_RBC_RBCN3", "");
							iform.setValue("BTD_RBC_CT3", "");
							iform.setValue("BTD_RBC_ExpD3", "");
							iform.setValue("BTD_RBC_AppC3", "");
							// iform.setValue("RBC_BTA1", "");
							iform.setValue("BTD_RBC_BTA3", "");
							// iform.setStyle("RBC_BTA1", false);
							// iform.setStyle("BTD_RBC_AppC3", "disable", " false");
							// JOptionPane.showMessageDialog(this._objApplet, "Rakbank Card Type L is not
							// allowed!");
							// ((Object) iform).setFocus("CSR_BT_RBCN1");
							strReturn = "Rakbank Card Type L is not allowed!";
						}
						if (CardValue.equalsIgnoreCase((String) map.get("CardNo0"))) {
							CSR_BT.mLogger.debug("(String) map.get(\"CardType1\"):: " + (String) map.get("CardType1"));
							CSR_BT.mLogger.debug("(String) map.get(\"ExpDT2\");:: " + (String) map.get("ExpDT2"));
							iform.setValue("BTD_RBC_CT3", (String) map.get("CardType1"));
							iform.setValue("BTD_RBC_ExpD3", (String) map.get("ExpDT2"));
							iform.setStyle("BTD_RBC_AppC3", "disable", " true");
						} else if (CardValue.equalsIgnoreCase((String) map.get("CardNo3"))) {
							CSR_BT.mLogger.debug("(String) map.get(\"CardType4\"):: " + (String) map.get("CardType4"));
							CSR_BT.mLogger.debug("(String) map.get(\"ExpDT5\");:: " + (String) map.get("ExpDT5"));
							iform.setValue("BTD_RBC_CT3", (String) map.get("CardType4"));
							iform.setValue("BTD_RBC_ExpD3", (String) map.get("ExpDT5"));
							iform.setStyle("BTD_RBC_AppC3", "disable", " true");
						} else if (CardValue.equalsIgnoreCase((String) map.get("CardNo6"))) {
							CSR_BT.mLogger.debug("(String) map.get(\"CardType4\"):: " + (String) map.get("CardType7"));
							CSR_BT.mLogger.debug("(String) map.get(\"ExpDT5\");:: " + (String) map.get("ExpDT8"));
							iform.setValue("BTD_RBC_CT3", (String) map.get("CardType7"));
							iform.setValue("BTD_RBC_ExpD3", (String) map.get("ExpDT8"));
							iform.setStyle("BTD_RBC_AppC3", "disable", " true");

						}
					} else {
						iform.setValue("BTD_RBC_RBCN3", "");
						iform.setValue("BTD_RBC_CT3", "");
						iform.setValue("BTD_RBC_ExpD3", "");
						iform.setValue("BTD_RBC_AppC3", "");
						// iform.setValue("RBC_BTA1", "");
						iform.setValue("BTD_RBC_BTA3", "");
						// iform.setStyle("RBC_BTA1", false);

					}
					strReturn = "BTD_RBC_RBCN3 values loaded";
				} else {
					strReturn = "CardDetails is not present.";
				}
			}
		} catch (Exception exc) {
			CSR_BT.printException(exc);
			CSR_BT.mLogger.debug(
					"WINAME : " + getWorkitemName() + ", WSNAME: " + getActivityName() + ", Exception 2 - " + exc);
		}
		return strReturn;
	}

	public String validateCCNo(String paramString1) {
		if (!paramString1.equals("")) { // && ((paramString1.length() != 19) || (!isInteger(paramString1.substring(0,
										// 4))) || (!isInteger(paramString1.substring(5, 9))) ||
										// (!isInteger(paramString1.substring(10, 14))) ||
										// (!isInteger(paramString1.substring(15, 19)))
			String str = paramString1.replaceAll("-", "");
			int[] arrayOfInt = new int[str.length()];
			int i = 0;
			int j = 0;
			for (i = 0; i < str.length(); i++) {
				arrayOfInt[i] = Integer.parseInt(str.charAt(i) + "");
			}
			for (i = arrayOfInt.length - 2; i >= 0; i -= 2) {
				arrayOfInt[i] *= 2;
				if (arrayOfInt[i] > 9) {
					arrayOfInt[i] -= 9;
				}
			}
			for (i = 0; i < arrayOfInt.length; i++) {
				j += arrayOfInt[i];
			}

			if (j % 10 == 0) {
				return "ValidCard";
			}

			return "Invalid Credit Card No. Format";
		} else {
			return "Please Enter Valid Card Number";
		}
	}

	private boolean isInteger(String paramString)
	/*      */ {
		/* 2233 */ boolean bool = false;
		/*      */ try {
			/* 2235 */ int i = Integer.parseInt(paramString);
			/* 2236 */ bool = true;
			/*      */ }
		/*      */ catch (NumberFormatException localNumberFormatException) {
			/*      */ }
		/*      */ catch (Exception localException) {
			/*      */ }
		/* 2242 */ return bool;
		/*      */ }

	public String getCardDetails(IFormReference iform) {

		String StrRet = "";
		String CardDetails = (String) iform.getValue("cardDetails");
		CSR_BT.mLogger.debug("BTD_RBC_RBCN11 CardDetails--" + CardDetails);
		if (CardDetails != "") {
			String SetCardDetails = CardDetails.substring(2, CardDetails.length());

			String[] Splitdata = SetCardDetails.split("!");
			for (int i = 0; i < Splitdata.length; i++) {
				System.out.println("Splitdata:: " + Splitdata[i]);
			}
			int i = 0;
			while (i < Splitdata.length) {
				map.put("CardNo" + i, Splitdata[i]);
				i++;
				map.put("CardType" + i, Splitdata[i]);
				i++;
				map.put("ExpDT" + i, Splitdata[i]);
				i++;
			}
			StrRet = "CardDetails values Loaded";
		} else {
			StrRet = "CardDetails is not present";
		}
		return StrRet;

	}
}
