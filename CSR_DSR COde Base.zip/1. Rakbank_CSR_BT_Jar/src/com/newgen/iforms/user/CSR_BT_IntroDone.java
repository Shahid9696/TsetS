package com.newgen.iforms.user;

import java.util.Calendar;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

public class CSR_BT_IntroDone extends CSR_BTCommon
{
	public String onIntroduceDone(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn="";
		CSR_BT.mLogger.debug("This is CSR_BT_IntroDone_Event");
		if("InsertIntoHistory".equals(controlName))
		{
			try {
				CSR_BT.mLogger.debug("Reject Reasons Grid Length is "+data);
				String strRejectReasons="";
				for(int p=0;p<Integer.parseInt(data);p++)
				{
					if(strRejectReasons=="")	
						strRejectReasons=iform.getTableCellValue("REJECT_REASON_GRID",p,0);
					else
						strRejectReasons=strRejectReasons+"#"+iform.getTableCellValue("REJECT_REASON_GRID",p,0);
				}

				CSR_BT.mLogger.debug("Final reject reasons are "+strRejectReasons);
				JSONArray jsonArray=new JSONArray();
				JSONObject obj=new JSONObject();
				Calendar cal = Calendar.getInstance();
				// SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");			   
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:MM:ss");
				String strDate = sdf.format(cal.getTime());

				obj.put("Date Time",strDate);
				obj.put("Workstep",iform.getActivityName());
				obj.put("User Name", iform.getUserName());
				obj.put("Decision",iform.getValue("q_Decision"));
				obj.put("Reject Reasons", strRejectReasons);
				obj.put("Remarks", iform.getValue("REMARKS"));


				CSR_BT.mLogger.debug("Decision" +iform.getValue("q_Decision"));

				if("Introduction".equalsIgnoreCase(iform.getActivityName()))
					obj.put("Entry Date Time",iform.getValue("CreatedDateTime"));
				else
					obj.put("Entry Date Time",iform.getValue("EntryDateTime"));
				jsonArray.add(obj);
				iform.addDataToGrid("Q_USR_0_CSR_OCC_WIHISTORY", jsonArray);

				CSR_BT.mLogger.debug("Created Date Time"+iform.getValue("CreatedDateTime"));
				CSR_BT.mLogger.debug("Entry Date Time"+iform.getValue("EntryDateTime"));
				
			} catch (Exception e) {
				CSR_BT.mLogger.debug("Exception in check if system Check Required non borrowing" + e.getMessage());
			}
		}
		return strReturn;
	}
	
	public String triggerMailSMS(IFormReference iform, String controlName,String event, String data) {
		//for mail/sms trigger, added by aditya.rai 11-04-23
		CSR_BT.mLogger.debug("Inside triggerMailSMS method");
		try {
		String stage = "";
		CSR_BT.mLogger.debug("stage------->"+stage);
		if (iform.getActivityName() == "Introduction" )
		{
			CSR_BT.mLogger.debug("stage------->"+stage);
			stage = "Introduction";
			CSR_BT.mLogger.debug("stage------->"+stage);
		}
		if (iform.getActivityName().equals("CARDS")){
			CSR_BT.mLogger.debug("stage------->"+stage);
			String Decision = (String) iform.getValue("Cards_Decision");
			if (Decision.equals("CARDS_BR")) {
				stage = "RejectRTS";
			CSR_BT.mLogger.debug("stage------->"+stage);
			}
			else if (Decision.equals("CARDS_D")) {
				stage = "RejectFinalDiscard";
			CSR_BT.mLogger.debug("stage------->"+stage);
			}
			else if (Decision.equals("CARDS_E")) {
				stage = "Completed";
				CSR_BT.mLogger.debug("stage------->"+stage);
				}
		}
		else if(iform.getActivityName().equalsIgnoreCase("Pending")) {
			stage = "PendingCancel";
			CSR_BT.mLogger.debug("stage----->"+stage);
			String SMSRes = CSR_BT_Email.sendSMS(iform, stage, data);
			if(SMSRes.equalsIgnoreCase("true"))
				return "True-Sms Triggered successfully";
			else
				return "False-Some error in triggering SMS Service";
		}
		if(!stage.equals("") ){
			String mailres = CSR_BT_Email.mailTrigger(iform, stage,data);
			String SMSRes =  CSR_BT_Email.sendSMS(iform, stage,data);
			if(mailres.equals("true") || SMSRes.equals("true")) {
			CSR_BT.mLogger.debug("Mail/SMS Triggered");
			return "True-MailSms Triggered successfully";
			}
		}
		
		}
		catch (Exception e) {
			CSR_BT.mLogger.debug("Exception in mailSMS trigger" + e.getMessage());
		}
		return "False-Some error in triggering MailSMS Service";	
	}
}