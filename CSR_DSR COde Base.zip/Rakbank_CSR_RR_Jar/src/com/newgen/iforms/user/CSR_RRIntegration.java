package com.newgen.iforms.user;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.mvcbeans.model.wfobjects.WDGeneralData;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.CharacterData;
	
	public class CSR_RRIntegration extends CSR_RRCommon 
	{		
		LinkedHashMap<String,String> executeXMLMapMain = new LinkedHashMap<String,String>();
		public static String XMLLOG_HISTORY="NG_CSR_RR_XMLLOG_HISTORY";

	public String onclickevent(IFormReference iformObj,String control,String StringData)
	{
		String MQ_response="";
		String MQ_response_Entity ="";
		String AccountNumber = "";		
		String TradeLicense="";
		String TradeLicenseExpiryDate="";
		String Blacklisted="";
		String Negated="";
		String Companyname="";
		int returnedSignatures = 0;
		String ReturnCode1="";		
		String ReturnDesc = "";		
		
			try
			{
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Inside onclickevent function");
			
			
			/*  if(control.equals("btn_Populate"))
			{
				
			} */			
			
		}
			
		
		catch(Exception exc)
		{
			CSR_RR.printException(exc);
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception 2 - "+exc);
		}
	
		return "";
	}
	
		
	/*public String getImages(String tempImagePath,String debt_acc_num,String[] imageArr,String[] remarksArr)
	{

		if(imageArr==null)
			return "";
		for (int i=0;i<imageArr.length;i++)
		{
			try
			{	
				CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Inside Get Images 0");
				byte[] btDataFile = new sun.misc.BASE64Decoder().decodeBuffer(imageArr[i]);
				//File of = new File(filePath+debt_acc_num+"imageCreatedN"+i+".jpg");
				String imagePath = System.getProperty("user.dir")+tempImagePath+System.getProperty("file.separator")+debt_acc_num+"imageCreatedN"+i+".jpg";
				CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", imagePath"+imagePath);
				File of = new File(imagePath);
				
				FileOutputStream osf = new FileOutputStream(of);
				osf.write(btDataFile);
				osf.flush();
				osf.close();
			}
			catch (Exception e)
			{
				CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Not able to get the image imageCreated"+e);
				CSR_RR.mLogger.debug( e.getMessage());
				e.printStackTrace();				
			}
		}
		//WriteLog( html.toString());
		return "";
	}*/
	
	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
		   CharacterData cd = (CharacterData) child;
		   return cd.getData();
		}
		return "NO_DATA";
	}
	
	public String MQ_connection_response(IFormReference iformObj,String control,String Data) 
	{
		
	CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Inside MQ_connection_response function");
	final IFormReference iFormOBJECT;
	final WDGeneralData wdgeneralObj;	
	Socket socket = null;
	OutputStream out = null;
	InputStream socketInputStream = null;
	DataOutputStream dout = null;
	DataInputStream din = null;
	String mqOutputResponse = null;
	String mqOutputResponse1 = null;
	String mqInputRequest = null;	
	String cabinetName = getCabinetName();
	String wi_name = getWorkitemName();
	String ws_name = getActivityName();
	String sessionID = getSessionId();
	String userName = getUserName();
	String socketServerIP;
	int socketServerPort;
	wdgeneralObj = iformObj.getObjGeneralData();
	sessionID = wdgeneralObj.getM_strDMSSessionId();
	String CIFNumber="";	
	String CallName="";
	
	if(control.equals("btn_View_Signature"))
	{
		CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Inside btn_View_Signature control--");
		String acc_selected = Data;
		CallName="SIGNATURE_DETAILS";
		String selectedCIFNumber = getControlValue("CIF_ID");
		CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", $$selectedCIFNumber "+selectedCIFNumber);
		StringBuilder finalXml = new StringBuilder("<EE_EAI_MESSAGE>\n"+
				"<EE_EAI_HEADER>\n"+
				"<MsgFormat>SIGNATURE_DETAILS</MsgFormat>\n"+
				"<MsgVersion>0001</MsgVersion>\n"+
				"<RequestorChannelId>BPM</RequestorChannelId>\n"+
				"<RequestorUserId>RAKUSER</RequestorUserId>\n"+
				"<RequestorLanguage>E</RequestorLanguage>\n"+
				"<RequestorSecurityInfo>secure</RequestorSecurityInfo>\n"+
				"<ReturnCode>911</ReturnCode>\n"+
				"<ReturnDesc>Issuer Timed Out</ReturnDesc>\n"+
				"<MessageId>MDL053169111</MessageId>\n"+
				"<Extra1>REQ||PERCOMER.PERCOMER</Extra1>\n"+
				"<Extra2>2007-01-01T10:30:30.000Z</Extra2>\n"+
				"</EE_EAI_HEADER>\n"+
				"<SignatureDetailsReq><BankId>RAK</BankId><CustId></CustId><AcctId>"+acc_selected+"</AcctId></SignatureDetailsReq>\n"+
				"</EE_EAI_MESSAGE>");
	mqInputRequest = getMQInputXML(sessionID, cabinetName,wi_name, ws_name, userName, finalXml);
	CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", mqInputRequest for Signature Details call" + mqInputRequest);
	}
	
	try {
	
	CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", userName "+ userName);
	CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", sessionID "+ sessionID);
	
	String sMQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_RLOS_MQ_TABLE with (nolock) where host_name = 'mq'";
	List<List<String>> outputMQXML = iformObj.getDataFromDB(sMQuery);
	//CreditCard.mLogger.info("$$outputgGridtXML "+ "sMQuery " + sMQuery);
	if (!outputMQXML.isEmpty()) {
		//CreditCard.mLogger.info("$$outputgGridtXML "+ outputMQXML.get(0).get(0) + "," + outputMQXML.get(0).get(1));
		socketServerIP = outputMQXML.get(0).get(0);
		CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", socketServerIP " + socketServerIP);
		socketServerPort = Integer.parseInt(outputMQXML.get(0).get(1));
		CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", socketServerPort " + socketServerPort);
		
		CSR_RR.mLogger.debug(" outside socket"+socket);
		
		if (!("".equalsIgnoreCase(socketServerIP) && socketServerIP == null && socketServerPort==0)) {
			socket = new Socket(socketServerIP, socketServerPort);
			
			int connection_timeout=60;
				try{
					connection_timeout=70;
					//connection_timeout = Integer.parseInt(NGFUserResourceMgr_CreditCard.getGlobalVar("Integration_Connection_Timeout"));
				}
				catch(Exception e){
					connection_timeout=60;
				}
				
			socket.setSoTimeout(connection_timeout*1000);
			out = socket.getOutputStream();
			
			CSR_RR.mLogger.debug("connection timeout"+connection_timeout);
			CSR_RR.mLogger.debug(" inside socket"+socket);	
			CSR_RR.mLogger.debug("out" +out);
			
			socketInputStream = socket.getInputStream();
			
			CSR_RR.mLogger.debug("socketInputStream"+socketInputStream);
			
			dout = new DataOutputStream(out);
			din = new DataInputStream(socketInputStream);
			
			CSR_RR.mLogger.debug("dout"+dout);
			CSR_RR.mLogger.debug("din"+din);
			
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", dout " + dout);
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", din " + din);
			mqOutputResponse = "";
			mqOutputResponse1 = "";
			
	
			if (mqInputRequest != null && mqInputRequest.length() > 0) {
				int outPut_len = mqInputRequest.getBytes("UTF-16LE").length;
				CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Final XML output len: "+outPut_len + "");
				mqInputRequest = outPut_len + "##8##;" + mqInputRequest;
				CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", MqInputRequest"+"Input Request Bytes : "+ mqInputRequest.getBytes("UTF-16LE"));
				dout.write(mqInputRequest.getBytes("UTF-16LE"));dout.flush();
			}
			byte[] readBuffer = new byte[500];
			int num = din.read(readBuffer);
			if (num > 0) {
	
				byte[] arrayBytes = new byte[num];
				System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
				mqOutputResponse = mqOutputResponse+ new String(arrayBytes, "UTF-16LE");
				CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", mqOutputResponse/message ID :  "+mqOutputResponse);
				
				mqOutputResponse1 = mqOutputResponse1+ new String(arrayBytes, "UTF-16LE");
				CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", mqOutputResponse1/message ID :  "+mqOutputResponse1+", CallName :"+CallName);
								
				if(!"".equalsIgnoreCase(mqOutputResponse) && control.equalsIgnoreCase("btn_View_Signature"))
				{
					mqOutputResponse = getOutWtthMessageID(CallName,iformObj,mqOutputResponse);
				}
				
					
				if(mqOutputResponse.contains("&lt;")){
					mqOutputResponse=mqOutputResponse.replaceAll("&lt;", "<");
					mqOutputResponse=mqOutputResponse.replaceAll("&gt;", ">");
				}
			}
			socket.close();
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", mqOutputResponse::::::::::::  "+mqOutputResponse);
			return mqOutputResponse;
			
		} else {
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", SocketServerIp and SocketServerPort is not maintained "+"");
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", SocketServerIp is not maintained "+	socketServerIP);
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", SocketServerPort is not maintained "+	socketServerPort);
			return "MQ details not maintained";
		}
	} else {
		CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", SOcket details are not maintained in NG_RLOS_MQ_TABLE table"+"");
		return "MQ details not maintained";
	}
	
	} catch (Exception e) {
		CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception BTured Mq_connection_CC"+e.getStackTrace());
	return "";
	}
	finally{
	try{
		if(out != null){
			
			out.close();
			out=null;
			}
		if(socketInputStream != null){
			
			socketInputStream.close();
			socketInputStream=null;
			}
		if(dout != null){
			
			dout.close();
			dout=null;
			}
		if(din != null){
			
			din.close();
			din=null;
			}
		if(socket != null){
			if(!socket.isClosed()){
				socket.close();
			}
			socket=null;
		}
	}catch(Exception e)
	{
		CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Final Exception BTured Mq_connection_CC"+e.getStackTrace());
		//printException(e);
	}
	}
	}
	
	
	private static String getMQInputXML(String sessionID, String cabinetName,
			String wi_name, String ws_name, String userName,
			StringBuilder final_xml) {
		//FormContext.getCurrentInstance().getFormConfig();
		CSR_RR.mLogger.debug("inside getMQInputXML function");
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("<APMQPUTGET_Input>");
		strBuff.append("<SessionId>" + sessionID + "</SessionId>");
		strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
		strBuff.append("<XMLHISTORY_TABLENAME>"+XMLLOG_HISTORY+"</XMLHISTORY_TABLENAME>");
		strBuff.append("<WI_NAME>" + wi_name + "</WI_NAME>");
		strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
		strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
		strBuff.append("<MQ_REQUEST_XML>");
		strBuff.append(final_xml);
		strBuff.append("</MQ_REQUEST_XML>");
		strBuff.append("</APMQPUTGET_Input>");
		return strBuff.toString();
	}
		
	public String getOutWtthMessageID(String callName,IFormReference iformObj,String message_ID){
		String outputxml="";
		try{
			CSR_RR.mLogger.debug("getOutWtthMessageID - callName :"+callName);
			//String wi_name = iformObj.getWFWorkitemName();
			String wi_name = getWorkitemName();
			String str_query = "select OUTPUT_XML from "+ XMLLOG_HISTORY +" with (nolock) where CALLNAME ='"+callName+"' and MESSAGE_ID ='"+message_ID+"' and WI_NAME = '"+wi_name+"'";
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", inside getOutWtthMessageID str_query: "+ str_query);
			List<List<String>> result=iformObj.getDataFromDB(str_query);
			//below code added by nikhil 18/10 for Connection timeout
			//String Integration_timeOut=NGFUserResourceMgr_CreditCard.getGlobalVar("Inegration_Wait_Count");
			String Integration_timeOut="100";
			int Loop_wait_count=10;
			try
			{
				Loop_wait_count=Integer.parseInt(Integration_timeOut);
			}
			catch(Exception ex)
			{
				Loop_wait_count=10;
			}
		
			for(int Loop_count=0;Loop_count<Loop_wait_count;Loop_count++){
				if(result.size()>0){
					outputxml = result.get(0).get(0);
					break;
				}
				else{
					Thread.sleep(1000);
					result=iformObj.getDataFromDB(str_query);
				}
			}
			
			if("".equalsIgnoreCase(outputxml)){
				outputxml="Error";
			}
			CSR_RR.mLogger.debug("This is output xml from DB");
			String outputxmlMasked = outputxml;
			CSR_RR.mLogger.debug("The output XML is "+outputxml);
			outputxmlMasked = maskXmlogBasedOnCallType(outputxmlMasked,callName);    //uncomment it at UAT
			CSR_RR.mLogger.debug("Masked output XML is "+outputxmlMasked);
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", getOutWtthMessageID" + outputxmlMasked);				
		}
		catch(Exception e){
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception BTurred in getOutWtthMessageID" + e.getMessage());
			CSR_RR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception BTurred in getOutWtthMessageID" + e.getStackTrace());
			outputxml="Error";
		}
		return outputxml;
	}
	
	public String maskXmlogBasedOnCallType(String outputxmlMasked, String callType)
	{
		String Tags = "";
		if (callType.equalsIgnoreCase("CUSTOMER_DETAILS"))
		{
			outputxmlMasked = outputxmlMasked.replace("("," ").replace(")"," ").replace("@"," ").replace("+"," ").replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
			Tags = "<ACCNumber>~,~<AccountName>~,~<ECRNumber>~,~<DOB>~,~<MothersName>~,~<IBANNumber>~,~<DocId>~,~<DocExpDt>~,~<DocIssDate>~,~<PassportNum>~,~<MotherMaidenName>~,~<LinkedDebitCardNumber>~,~<FirstName>~,~<MiddleName>~,~<LastName>~,~<FullName>~,~<ARMCode>~,~<ARMName>~,~<PhnCountryCode>~,~<PhnLocalCode>~,~<PhoneNo>~,~<EmailID>~,~<CustomerName>~,~<CustomerMobileNumber>~,~<PrimaryEmailId>~,~<Fax>~,~<AddressType>~,~<AddrLine1>~,~<AddrLine2>~,~<AddrLine3>~,~<AddrLine4>~,~<POBox>~,~<City>~,~<Country>~,~<AddressLine1>~,~<AddressLine2>~,~<AddressLine3>~,~<AddressLine4>~,~<CityCode>~,~<State>~,~<CountryCode>~,~<Nationality>~,~<ResidentCountry>~,~<PrimaryContactName>~,~<PrimaryContactNum>~,~<SecondaryContactName>~,~<SecondaryContactNum>";
			
		}

			else if (callType.equalsIgnoreCase("ACCOUNT_SUMMARY"))
		{
			outputxmlMasked = outputxmlMasked.replace("("," ").replace(")"," ").replace("@"," ").replace("+"," ").replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
			Tags = "<Acid>~,~<Foracid>~,~<NicName>~,~<AccountName>~,~<AcctBal>~,~<LoanAmtAED>~,~<AcctOpnDt>~,~<MaturityAmt>~,~<EffAvailableBal>~,~<EquivalentAmt>~,~<LedgerBalanceinAED>~,~<LedgerBalance>";
		}
		else if (callType.equalsIgnoreCase("SIGNATURE_DETAILS"))
		{
			outputxmlMasked = outputxmlMasked.replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
			Tags = "<CustomerName>";
		}
		if (!Tags.equalsIgnoreCase(""))
		{
	    	String Tag[] = Tags.split("~,~");
	    	for(int i=0;i<Tag.length;i++)
	    	{
	    		outputxmlMasked = maskXmlTags(outputxmlMasked,Tag[i]);
	    	}
		}
    	return outputxmlMasked;
	}
	
}

