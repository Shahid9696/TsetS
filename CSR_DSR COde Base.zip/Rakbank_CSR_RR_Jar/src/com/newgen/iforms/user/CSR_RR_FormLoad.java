package com.newgen.iforms.user;

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

public class CSR_RR_FormLoad extends CSR_RRCommon
{
	public String formLoadEvent(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn=""; 
	
		CSR_RR.mLogger.debug("This is CSR_RR_FormLoad_Event"+event+" controlName :"+controlName);
		
		//CSR_RR.mLogger.debug("SELECT DECISION FROM USR_0_CSR_RR_DECISION_MASTER WHERE WORKSTEP_NAME= '"+iform.getActivityName()"' and ISACTIVE='Y'");
				
		if (controlName.equalsIgnoreCase("BranchName") && event.equalsIgnoreCase("FormLoad") )
		{
			String actname = iform.getActivityName();
			//CSR_RR.mLogger.debug(actname);
			List lstDecisions = iform.getDataFromDB("select BRANCHNAME,branchid from rb_branch_details");
			
			String value="";
			
			CSR_RR.mLogger.debug(lstDecisions);
			
			 iform.clearCombo("BTD_OBC_BN");
			
			for(int i=0;i<lstDecisions.size();i++)
			 {
				List<String> arr1=(List)lstDecisions.get(i);
				value=arr1.get(0);
				iform.addItemInCombo("BTD_OBC_BN",value,value);
				strReturn="Brnach vakue loaded";
			 }		
		}
		
			
		else if("DuplicateWI".equals(controlName))
		{
			try {
				CSR_RR.mLogger.debug("Duplicate WIs");
				CSR_RR.mLogger.debug("WI Name duplicate is "+getWorkitemName());
				CSR_RR.mLogger.debug("CIF id is "+iform.getValue("CIF_ID"));
				String strQuery="SELECT WI_NAME,CREATED_TIME, CREATED_BY, SOL_ID  FROM RB_CSR_RR_EXTTABLE WHERE CIF_ID='"+iform.getValue("CIF_ID")+"' AND WI_NAME NOT IN ('"+getWorkitemName()+"')";
				List<List<String>> lstDuplicateWIs = iform.getDataFromDB(strQuery);
				
				CSR_RR.mLogger.debug("strQuery "+strQuery);
				JSONArray jsonArray=new JSONArray();
				String value="";
				CSR_RR.mLogger.debug("lstDuplicateWIs.size() "+lstDuplicateWIs.size());
				for(int i=0;i<lstDuplicateWIs.size();i++)
				{
					//PC.mLogger.debug(" "+memoPad);
					JSONObject obj=new JSONObject();
					List<String> arr=(List)lstDuplicateWIs.get(i);
					value=arr.get(0);
					CSR_RR.mLogger.debug("WI is "+value);
					obj.put("Work-Item Number", value);
					value=arr.get(1);
					//CSR_RR.mLogger.debug("Date format Sajan "+value);
					//Date date1= new SimpleDateFormat("EE dd/MMM/yyyy HH:mm:ss",Locale.ENGLISH).parse(value);
					Date date1= new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss").parse(value);
					CSR_RR.mLogger.debug("date1 "+date1);
					SimpleDateFormat sdf1=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
					CSR_RR.mLogger.debug("Initiated date is "+sdf1.format(date1).toString());
					
					value=sdf1.format(date1).toString();
					obj.put("Initiated Date", value);
					value=arr.get(2);
					CSR_RR.mLogger.debug("Initiated by is "+value);
					obj.put("Initiated By", value);
					value=arr.get(3);
					CSR_RR.mLogger.debug("Sol id is "+value);
					obj.put("Sol Id", value);
					jsonArray.add(obj);
				}
				CSR_RR.mLogger.debug("JSON array is "+jsonArray.toString());
				iform.addDataToGrid("Q_USR_0_CSR_RR_DUPLICATE_WI", jsonArray);
				strReturn=strReturn+lstDuplicateWIs.size();
			} catch (Exception e) {
				CSR_RR.mLogger.debug("Exception in Duplicate WorkItem" + e.getMessage());
			}
		}
		
		return strReturn;
	}
	
}
