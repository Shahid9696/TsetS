package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormReference;

public class CSR_CCC_Click {

	public String clickEvent(IFormReference iform, String controlName, String data)
	{
		String strReturn = "";
		CSR_CCC.mLogger.debug("inside CSR_CCC_click");
		 if(controlName.equals("btn_View_Signature"))
		 {
             return new CSR_CCCIntegration().onclickevent(iform, "btn_View_Signature",data);
		 }
		else if (controlName.equalsIgnoreCase("PrintButton")) 
		{

			Object localJSObject = "";
			CSR_CCC.mLogger.debug("PrintButton inside");
			CSR_CCC.mLogger.debug("localJSObject ::" + localJSObject.toString());
			String str2 = "";
			String str3 = "";
			String str4 = "";
			str2 = ((String) iform.getValue("Cards_Remarks")).replace("&", "ampersand");
			str2 = str2.replace("=", "equalsopt");
			str2 = str2.replace("%", "percentageopt");
			str3 = ((String) iform.getValue("BA_Remarks")).replace("&", "ampersand");
			str3 = str3.replace("=", "equalsopt");
			str3 = str3.replace("%", "percentageopt");
			str4 = ((String) iform.getValue("Remarks")).replace("&", "ampersand");
			str4 = str4.replace("=", "equalsopt");
			str4 = str4.replace("%", "percentageopt");
			CSR_CCC.mLogger.debug("arrayOfString ::" + str2 + " " + str3 + " " + str4);
			String[] arrayOfString = new String[1];
			arrayOfString[0] = ("CCI_CrdtCN=" + ((String) iform.getValue("CCI_CrdtCN")) + "&" + "CCI_CName="
				+ ((String) iform.getValue("CCI_CName")) + "&" + "CCI_ExpD="
				+ ((String) iform.getValue("CCI_ExpD")) + "&" + "CCI_CCRNNo="
				+ ((String) iform.getValue("CCI_CCRNNo")) + "&" + "CCI_ExtNo="
				+ ((String) iform.getValue("CCI_ExtNo")) + "&" + "CCI_SC=" + ((String) iform.getValue("CCI_SC"))
				+ "&" + "CCI_MONO=" + ((String) iform.getValue("CCI_MONO")) + "&" + "CCI_AccInc="
				+ ((String) iform.getValue("CCI_AccInc")) + "&" + "CCI_CAPS_GENSTAT="
				+ ((String) iform.getValue("CCI_CAPS_GENSTAT")) + "&" + "CCI_ELITECUSTNO="
				+ ((String) iform.getValue("CCI_ELITECUSTNO")) + "&" + "CCI_CT="
				+ ((String) iform.getValue("CCI_CT")) + "&" + "VD_TINCheck="
				+ ((String) iform.getValue("VD_TINCheck")) + "&" + "VD_MoMaidN="
				+ ((String) iform.getValue("VD_MoMaidN")) + "&" + "VD_DOB="
				+ ((String) iform.getValue("VD_DOB")) + "&" + "VD_StaffId="
				+ ((String) iform.getValue("VD_StaffId")) + "&" + "VD_PassNo="
				+ ((String) iform.getValue("VD_PassNo")) + "&" + "VD_POBox="
				+ ((String) iform.getValue("VD_POBox")) + "&" + "VD_Oth=" + ((String) iform.getValue("VD_Oth"))
				+ "&" + "VD_MRT=" + ((String) iform.getValue("VD_MRT")) + "&" + "VD_EDC="
				+ ((String) iform.getValue("VD_EDC")) + "&" + "VD_NOSC=" + ((String) iform.getValue("VD_NOSC"))
				+ "&" + "VD_TELNO=" + ((String) iform.getValue("VD_TELNO")) + "&" + "VD_SD="
				+ ((String) iform.getValue("VD_SD")) + "&" + "wi_name=" + ((String) iform.getValue("wi_name"))
				+ "&" + "processname=CSR_CCC" + "&"
				+ "IntroductionDateTime=" + (String)iform.getValue("IntroductionDateTime") +
				"&"
				+ "BANEFICIARY_NAME=" + ((String) iform.getValue("BANEFICIARY_NAME")) + "&" + "Cards_Decision="
				+ ((String) iform.getValue("Cards_Decision")) + "&" + "Cards_Remarks=" + str2 + "&"
				+ "DELIVERTO=" + ((String) iform.getValue("DELIVERTO")) + "&" + "BRANCHCODE="
				+ ((String) iform.getValue("BRANCHCODE")) + "&" + "CARDNO1="
				+ ((String) iform.getValue("CARDNO1")) + "&" + "CARDNO2="
				+ ((String) iform.getValue("CARDNO2")) + "&" + "CARDNO3="
				+ ((String) iform.getValue("CARDNO3")) + "&" + // "BU_UserName=" +
				// localXMLParser.getValueOf("IntroducedBy")) + "&" +
				"CARDTYPE1=" + ((String) iform.getValue("CARDTYPE1")) + "&" + "CARDTYPE2="
				+ ((String) iform.getValue("CARDTYPE2")) + "&" + "CARDTYPE3="
				+ ((String) iform.getValue("CARDTYPE3")) + "&" + "CARDEXPIRY_DATE1="
				+ ((String) iform.getValue("CARDEXPIRY_DATE1")) + "&" + "CARDEXPIRY_DATE2="
				+ ((String) iform.getValue("CARDEXPIRY_DATE2")) + "&" + "CARDEXPIRY_DATE3="
				+ ((String) iform.getValue("CARDEXPIRY_DATE3")) + "&" + "CHQ_AMOUNT1="
				+ ((String) iform.getValue("CHQ_AMOUNT1")) + "&" + "CHQ_AMOUNT2="
				+ ((String) iform.getValue("CHQ_AMOUNT2")) + "&" + "CHQ_AMOUNT3="
				+ ((String) iform.getValue("CHQ_AMOUNT3")) + "&" + "ApprovalCode1="
				+ ((String) iform.getValue("ApprovalCode1")) + "&" + "ApprovalCode2="
				+ ((String) iform.getValue("ApprovalCode2")) + "&" + "ApprovalCode3="
				+ ((String) iform.getValue("ApprovalCode3")) + "&" + "BA_Decision="
				+ ((String) iform.getValue("BA_Decision")) +  "&" + "BA_Remarks="
				+ str3 + "&" + "REMARKS=" + str4);
		
			CSR_CCC.mLogger.debug("arrayOfString ::" + arrayOfString[0]);
			localJSObject = arrayOfString[0];
			CSR_CCC.mLogger.debug("localJSObject ::" + localJSObject.toString());
			// ((JSObject) localJSObject).call("callPrintJSPCSRBT", arrayOfString);
			CSR_CCC.mLogger.debug("localJSObject ::" + localJSObject.toString());
			strReturn = localJSObject.toString();
		}
         else
		 {
        	 return "";	
		 }
		return strReturn;
	}
	
}
