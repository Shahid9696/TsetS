package com.newgen.iforms.user;

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

public class CSR_OCC_IntroDone extends CSR_CCCCommon
{
	public String onIntroduceDone(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn="";
		CSR_CCC.mLogger.debug("This is CSR_OCC_IntroDone_Event");
		if("InsertIntoHistory".equals(controlName))
		{
			try {
				CSR_CCC.mLogger.debug("Reject Reasons Grid Length is "+data);
				String strRejectReasons="";
				for(int p=0;p<Integer.parseInt(data);p++)
				{
					if(strRejectReasons=="")	
						strRejectReasons=iform.getTableCellValue("REJECT_REASON_GRID",p,0);
					else
						strRejectReasons=strRejectReasons+"#"+iform.getTableCellValue("REJECT_REASON_GRID",p,0);
				}
				
				CSR_CCC.mLogger.debug("Final reject reasons are "+strRejectReasons);
				JSONArray jsonArray=new JSONArray();
				JSONObject obj=new JSONObject();
				Calendar cal = Calendar.getInstance();
			   // SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");			   
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:MM:ss");
			    String strDate = sdf.format(cal.getTime());
			    
				obj.put("Date Time",strDate);
				obj.put("Workstep",iform.getActivityName());
				obj.put("User Name", iform.getUserName());
				obj.put("Decision",iform.getValue("q_Decision"));
				obj.put("Reject Reasons", strRejectReasons);
				obj.put("Remarks", iform.getValue("REMARKS"));
				
			
				CSR_CCC.mLogger.debug("Decision" +iform.getValue("q_Decision"));
				
				if("Introduction".equalsIgnoreCase(iform.getActivityName()))
					obj.put("Entry Date Time",iform.getValue("CreatedDateTime"));
				else
					obj.put("Entry Date Time",iform.getValue("EntryDateTime"));
				jsonArray.add(obj);
				iform.addDataToGrid("Q_USR_0_CSR_OCC_WIHISTORY", jsonArray);
				
				CSR_CCC.mLogger.debug("Created Date Time"+iform.getValue("CreatedDateTime"));
				CSR_CCC.mLogger.debug("Entry Date Time"+iform.getValue("EntryDateTime"));
				
				
			} catch (Exception e) {
				CSR_CCC.mLogger.debug("Exception in check if system Check Required non borrowing" + e.getMessage());
			}
		}
		return strReturn;
	}
	
	public String triggerMailSMS(IFormReference iform, String controlName,String event, String data) {
		try {
			CSR_CCC.mLogger.debug("Inside triggerMailSms");
			String activityName = iform.getActivityName();
			CSR_CCC.mLogger.debug("activityName---------->"+activityName);
		//for mail/sms trigger, added by Mirza 02-05-23
		String stage = "";
		CSR_CCC.mLogger.debug("Setting stage");
		if (iform.getActivityName().equalsIgnoreCase("Introduction"))
		{
			String Decision = (String) iform.getValue("Decision");
			if (Decision.equalsIgnoreCase("Introduce"))
				stage = "Introduction";
			else if (Decision.equalsIgnoreCase("Pending"))
				stage = "Pending";
		}
		else if (iform.getActivityName().equalsIgnoreCase("Branch_Approver")) {
			String Decision = (String) iform.getValue("BA_Decision");
			CSR_CCC.mLogger.debug("Decision------->"+Decision);
			 if (Decision.equalsIgnoreCase("BA_D")) {
				stage = "RejectFinalDiscard";
			 CSR_CCC.mLogger.debug("stage----->"+stage);
			 }
		}
		else if (iform.getActivityName().equalsIgnoreCase("CARDS")){
			String Decision = (String) iform.getValue("Cards_Decision");
			CSR_CCC.mLogger.debug("Decision----->"+Decision);
			if (Decision.equals("CARDS_BR")) {
				stage = "RejectRTS";
			 CSR_CCC.mLogger.debug("stage----->"+stage);
			 }
			else if (Decision.equalsIgnoreCase("CARDS_D")) {
				stage = "RejectFinalDiscard";
				CSR_CCC.mLogger.debug("stage----->"+stage);
			}
			else if (Decision.equalsIgnoreCase("CARDS_E")) {
				stage = "Completed";
				CSR_CCC.mLogger.debug("stage----->"+stage);
			}
		}
		else if(iform.getActivityName().equalsIgnoreCase("Pending")) {
			String Decision = (String) iform.getValue("Pending_Decision");
			CSR_CCC.mLogger.debug("Decision----->"+Decision);
			if (Decision.equalsIgnoreCase("P_Discard")) {
				stage = "PendingCancel";
			 CSR_CCC.mLogger.debug("stage----->"+stage);
			}
			
		}
		if(stage!="")
		{
			String mailRes = CSR_CCC_Email.mailTrigger(iform, stage, data);
			String SMSRes = CSR_CCC_Email.sendSMS(iform, stage, data);
			CSR_CCC.mLogger.debug("MailResponse------>"+mailRes+"SMSResponse----->"+SMSRes);
			if(mailRes.equalsIgnoreCase("true") || SMSRes.equalsIgnoreCase("true")) {
				CSR_CCC.mLogger.debug("Mail/SMS Triggered");
				return "True-MailSms Triggered successfully";
				}
			}
		else
			return "stage not found";
		}catch (Exception e) {
			CSR_CCC.mLogger.debug("Exception in mailSMS trigger" + e.getMessage());
		}
		return "False-Some error in triggering MailSMS Service";
	}
	//end
}