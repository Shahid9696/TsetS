/*Description : CR for mail and sms trigger
 *Added By : Mirza
 *Date : 16-05-23    
 */
package com.newgen.iforms.user;

import java.util.Calendar;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;

import javax.print.DocFlavor.STRING;

import org.json.simple.JSONObject;

import com.newgen.custom.XMLParser;
import com.newgen.iforms.custom.IFormReference;


public class DSR_MR_Email extends DSR_MRCommon
{
	public static String mailTrigger(IFormReference iform, String stage,String data)
	{
		try{
			DSR_MR.mLogger.debug("Inside mailTrigger method-----------> ");
			DSR_MR.mLogger.debug("data-----------> "+data);
			String[] param = data.split("-");
			//declare all variable
			String SLA_TAT = "0";
			String tag = "";
			String WI_No = (String)iform.getValue("wi_name");
			DSR_MR.mLogger.debug("WI_No----------->" + WI_No);
			String split_WI_No = splitString(WI_No);
			DSR_MR.mLogger.debug("split_WI_No----------->" + split_WI_No);
			String Card_No = param[0];//(String)iform.getValue("CCI_CrdtCN");
			DSR_MR.mLogger.debug("Card_No----------->" + Card_No);
			String lastDigitCard_No = Card_No.substring(12,16);
			DSR_MR.mLogger.debug("lastDigitCard_No----------->" + lastDigitCard_No);
			/*String rejectReason = param[2];//(String)iform.getValue("Cards_Reject");
			DSR_MR.mLogger.debug("rejectReason----------->" + rejectReason);*/
			String getCustMail = "Select userEmailID FROM RB_DSR_MISC_EXTTABLE WHERE WI_NAME = '"+WI_No+"'";
			List<List<String>> Query_data1 = iform.getDataFromDB(getCustMail);
			String CustMail = Query_data1.get(0).get(0);
			DSR_MR.mLogger.debug("CustMail----------->" + CustMail);
			if(iform.getActivityName().equalsIgnoreCase("CARDS"))
			{
			String rejectReason = (String)iform.getValue("Cards_Reject");//param[2];
			DSR_MR.mLogger.debug("rejectReason--------->" + rejectReason);
			tag = "<p class=MsoListParagraphCxSpFirst align=center style=\"margin-bottom:0in; text-align:center;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">�<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+rejectReason+"</span></p>"+"\n";
			int size = 0;
			JSONArray str = new JSONArray();
			if(rejectReason.equalsIgnoreCase("Others")) 
			{
			String OthersrejectReason = (String)iform.getValue("Others_Reject_Reason");//param[2];
			DSR_MR.mLogger.debug("OthersrejectReason----------->" + OthersrejectReason);
			 tag = "<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in; text-align:left;padding-left:31%;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+OthersrejectReason+"</span></p>"+"\n"; 
			}
			else if(rejectReason.equalsIgnoreCase("Due to non receipt of")){
				str = (JSONArray)iform.getValue("USR_0_DSR_MR_REJECT_SUB_REASON");
				size = str.size();
				tag = "";
				for(int i = 0; i<size; i++) {
					String reason = (String) str.get(i);
			        tag = tag+"<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in;padding-left:31%; text-align:left;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+reason+"</span></p>"+"\n"; 
			    }
			}
			}
			else if(iform.getActivityName().equalsIgnoreCase("Pending"))
			{
			String rejectReason = (String)iform.getValue("Pending_Reason");//param[2];
			DSR_MR.mLogger.debug("rejectReason--------->" + rejectReason);
			tag = "<p class=MsoListParagraphCxSpFirst align=center style=\"margin-bottom:0in; text-align:center;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">�<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+rejectReason+"</span></p>"+"\n";
			int size = 0;
			JSONArray str = new JSONArray();
			if(rejectReason.equalsIgnoreCase("Others")) 
			{
			String OthersrejectReason = (String)iform.getValue("Others_Pending_SubReason");//param[2];
			DSR_MR.mLogger.debug("OthersrejectReason----------->" + OthersrejectReason);
			 tag = "<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in; text-align:left;padding-left:31%;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+OthersrejectReason+"</span></p>"+"\n"; 
			}
			else if(rejectReason.equalsIgnoreCase("Due to non receipt of")){
				str = (JSONArray)iform.getValue("USR_0_DSR_MR_PENDING_SUB");
				size = str.size();
				tag = "";
				for(int i = 0; i<size; i++) {
					String reason = (String) str.get(i);
			        tag = tag+"<p class=MsoListParagraphCxSpFirst align=left style=\"margin-bottom:0in; text-align:left;padding-left:31%;text-indent:-.25in;line-height:normal\"><span style=\"font-size:10.0pt;font-family:Symbol\">*<span style=\"font:7.0pt \"Times New Roman\"\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span><span style=\"font-size:10.0pt;font-family:\"Verdana\",sans-serif\">"+reason+"</span></p>"+"\n"; 
			    }
			}
			}
			//end
			//String path = System.getProperty("user.dir") + File.separatorChar + "folder name" + File.separatorChar + 
			//		"RAKBank_Email_Temp" + File.separatorChar + "DSR_MR_"+stage+".html";
			//String emailBody = readFile(path);
			String Query_TAT = "SELECT  SLA_TAT FROM USR_0_CSR_SLA_TAT WHERE ProcessName = 'DSR_MR'";
			List<List<String>> Query_TATData = iform.getDataFromDB(Query_TAT);
			if(Query_TATData.size()>0) {
				SLA_TAT = Query_TATData.get(0).get(0);
				DSR_MR.mLogger.debug("SLA_TAT" + SLA_TAT);
			}
			String Query = "Select * From USR_0_CSR_BT_TemplateMapping where ProcessName = 'DSR_MR' and TemplateType = '"+stage+"'";
			List<List<String>> Query_data = iform.getDataFromDB(Query);
			DSR_MR.mLogger.debug("Query_data----------->" + Query_data);
			if(Query_data.size()>0) {
			String emailBody = Query_data.get(0).get(2);
			DSR_MR.mLogger.debug("emailBody before replace" + emailBody);
			if (!emailBody.equalsIgnoreCase("NULL"))
			{
			emailBody = emailBody.replaceAll("#WI_No#", split_WI_No);
			emailBody = emailBody.replaceAll("#Card_No#", lastDigitCard_No);
			emailBody = emailBody.replaceAll("'Times", "''Times");
			emailBody = emailBody.replaceAll("Roman'", "Roman''");
			emailBody = emailBody.replaceAll("#reject reason#", tag);
			emailBody = emailBody.replaceAll("#SLA_TAT#", SLA_TAT);
			DSR_MR.mLogger.debug("emailBody after replace" + emailBody);
			
			String mailFrom = Query_data.get(0).get(3);
			DSR_MR.mLogger.debug("mailFrom----->" + mailFrom);
			String mailTo = CustMail;
			String mailSubject = Query_data.get(0).get(6);
			DSR_MR.mLogger.debug("Mail Subject------>"+mailSubject);
			String mailContentType = "text/html;charset=UTF-8";
			int mailPriority = 1;
			int workitemId = 1;
			int noOfTrials = 1;
			int activityId = 3;
			String mailStatus = "N";
			String mailActionType = "TRIGGER";
			String tableName = "WFMAILQUEUETABLE";
			String columnName = "(mailFrom,mailTo,mailSubject,mailMessage, mailContentType, mailPriority,mailStatus,insertedBy,"
					+ "mailActionType,processInstanceId,workitemId,activityId,noOfTrials)";
			String values = "('" + mailFrom + "','" + mailTo + "','" + mailSubject + "',N'" + emailBody + "','" + mailContentType
					+ "','" + mailPriority + "','" + mailStatus + "','" + getUserName() + "','" + mailActionType + "','"
					+ (iform.getObjGeneralData()).getM_strProcessInstanceId() + "','" + workitemId + "','" + activityId + "','" 
					+ noOfTrials + "')";
			String mailInsertQuery = "Insert into "+tableName+" "+columnName+" values "+values ;
			DSR_MR.mLogger.debug("Query to be inserted in table-----------------: " + mailInsertQuery);
			int status = iform.saveDataInDB(mailInsertQuery);
			DSR_MR.mLogger.debug("Status------------>"+status);
			DSR_MR.mLogger.debug("Mail Triggred successfuly if value of status is 1---------STATUS = " + status);
			if(status==1)
			return "true";
			}
			}
		}catch (Exception ex) {
			DSR_MR.mLogger.debug("Some error in mailTrigger " + ex.toString());
			return "false";
		}
		return "false";
	}
	public static String sendSMS(IFormReference iform, String stage, String data) {
		try{
			DSR_MR.mLogger.debug("inside sendSMScall txtMessagessss");
			DSR_MR.mLogger.debug("data----->"+data);
			String[] param = data.split("-");
			//declare all  variable
			String WI_No = (String)iform.getValue("wi_name");
			DSR_MR.mLogger.debug("WI_No------->" + WI_No);
			String split_WI_No = splitString(WI_No);
			DSR_MR.mLogger.debug("split_WI_No----------->" + split_WI_No);
			String Card_No = param[0];//(String)iform.getValue("CCI_CrdtCN");
			DSR_MR.mLogger.debug("Card_No------->" + Card_No);
			String lastDigitCard_No =Card_No.substring(12,16);
			DSR_MR.mLogger.debug("lastDigitCard_No------->" + lastDigitCard_No);
			String date = getDate();
			String smsLang = "EN";
			//end
			DSR_MR.mLogger.debug("inside sendSMScall Card_No :" + Card_No);
			//String path = System.getProperty("user.dir") + File.separatorChar + "folder name" + File.separatorChar + 
			//		"RAKBank_SMS_Temp" + File.separatorChar + "DSR_MR_"+stage+".html";
			//String txtMessage = readFile(path);
			String Query = "Select * From USR_0_CSR_BT_TemplateMapping where ProcessName = 'DSR_MR' and TemplateType = '"+stage+"'";
			List<List<String>> Query_data = iform.getDataFromDB(Query);
			DSR_MR.mLogger.debug("Query_data------->" + Query_data);
			if(Query_data.size()>0) {
			String txtMessage = Query_data.get(0).get(5);
			if (!txtMessage.equalsIgnoreCase("NULL"))
			{
			DSR_MR.mLogger.debug("txtMessage before replace" + txtMessage);
			txtMessage = txtMessage.replaceAll("#WI_No#", split_WI_No);
			txtMessage = txtMessage.replaceAll("#Card_No#", lastDigitCard_No);
			txtMessage = txtMessage.replaceAll("#DD/MM/YYYY#", date);
			if(stage.equalsIgnoreCase("PendingCancel"))
			{
				String pendingReason = (String)iform.getValue("Pending_Reason");
				DSR_MR.mLogger.debug("pendingReason------->" + pendingReason);
				txtMessage = txtMessage.replaceAll("#CancellationReason#", pendingReason);
			}
			DSR_MR.mLogger.debug("txtMessage after replace" + txtMessage);
			String tableName = "NG_RLOS_SMSQUEUETABLE";
			String ALERT_Name = stage;
			String Alert_Code = "DSR_MR";
			String Alert_Status = "P";
			String Mobile_No = param[1];//(String)iform.getValue("CCI_MONO");
			DSR_MR.mLogger.debug("Mobile no--------->" + Mobile_No);
			String Workstep_Name = (String)iform.getActivityName();
			String columnName = "(ALERT_Name, Alert_Code, Alert_Status, Mobile_No, Alert_Text, WI_Name, Workstep_Name, Inserted_Date_time)";
			String values = "('" + ALERT_Name + "','" + Alert_Code + "','" + Alert_Status + "','" + Mobile_No + "','" + txtMessage
					+ "','" + WI_No + "','" + Workstep_Name + "', getdate() )";
			String SMSInsertQuery = "Insert into "+tableName+" "+columnName+" values "+values ;
			DSR_MR.mLogger.debug("Query to be inserted in table-----------------: " + SMSInsertQuery);
			int status = iform.saveDataInDB(SMSInsertQuery);
			DSR_MR.mLogger.debug("SMS Triggred successfuly if value of status is 1-------------STATUS = " + status);
			if(status==1)
			return "true";
			}
			}
		}catch(Exception ex) {
			DSR_MR.mLogger.debug("Some error in sendSMScall" + ex.toString());
			return "false";
		}return "false";
	}
}