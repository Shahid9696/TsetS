package com.newgen.iforms.user;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.newgen.iforms.custom.IFormReference;

import netscape.javascript.JSObject;

public class DSR_MR_Click extends DSR_MRCommon{

	HashMap CAPDataHT = new HashMap();
	public String clickEvent(IFormReference iform, String controlName, String data) {
		
		String strReturn = "";
		try {
	
		DSR_MR.mLogger.debug("inside DSR_MR_click");
		if (controlName.equalsIgnoreCase("CAPSMAIN_Query")) {
			
			//String debit = ((String) iform.getValue(DebitCardNo1")).replaceAll("-", "");
			//String value1 = validateCCNo(debit);
			String sSQL = "";
			Connection conn = null;
			Statement stmt = null;
			//Statement stmt1 = null;
			// PreparedStatement stmt=null;
			ResultSet result = null;
			ResultSet result1 = null;
			
			try {

			String actname = iform.getActivityName();
			String debit = ((String) iform.getValue("DebitCardNo1")).replaceAll("-", "");

			String value1 = validateCCNo(debit);
			if (value1.equalsIgnoreCase("ValidCard")) {
				// DSR_OCC.mLogger.debug(actname);
				DSR_MR.mLogger.debug("inside DSR_MR_click debit" + debit);

				Context aContext = new InitialContext();
				DataSource aDataSource = (DataSource) aContext.lookup("jdbc/cbop");
				conn = (Connection) (aDataSource.getConnection());
				DSR_MR.mLogger.debug("got data source");
				// stmt = conn.createStatement();

				sSQL = "Select LTRIM(RTRIM(FirstName)), LTRIM(RTRIM(MiddleName)), LTRIM(RTRIM(LastName)), "
						+ "substr(to_char(EXPIRYDATE,'dd/mm/yy'),4,length(to_char(EXPIRYDATE,'dd/mm/yy'))), "
						+ "CRNNO, MOBILE,ASSESSEDINCOME,CARDTYPE,generalstat,elitecustomerno  from CAPSMAIN where "
						+ "CREDITCARDNO='" + debit + "'";

	
				stmt = conn.createStatement();
				// stmt = conn.prepareStatement(sSQL);
				DSR_MR.mLogger.debug("sSQL ::" + sSQL);

				result = stmt.executeQuery(sSQL);
				DSR_MR.mLogger.debug("result stmt::" + result);
				DSR_MR.mLogger.debug("lstDecisions size" + result.getFetchSize());
				if (result.getFetchSize() != 0) {
					String value = "";
					String CRNNO = "";
					String MOBILE = "";
					String ASSESSEDINCOME = "";
					String CARDTYPE = "";
					String generalstat = "";
					String elitecustomerno = "";
					String MiddleName = "";
					String LastName = "";
					String ExpD = "";

					iform.clearCombo("DCI_CName");
					iform.clearCombo("DCI_ExpD");
					iform.clearCombo("DCI_CCRNNo");
					iform.clearCombo("DCI_MONO");
					iform.clearCombo("DCI_ADCInc");
					iform.clearCombo("DCI_CT");
					iform.clearCombo("DCI_CAPS_GENSTAT");
					iform.clearCombo("DCI_ELITECUSTNO");
					iform.clearCombo("DCI_CrdtCN");

					while (result.next()) {
						value = result.getString(1);
						DSR_MR.mLogger.debug("value size" + value);
						MiddleName = result.getString(2);
						LastName = result.getString(3);
						// sCustomerName=sFirstName+" "+sMiddleName+" "+sLastName;
						ExpD = result.getString(4);
						CRNNO = result.getString(5);
						MOBILE = result.getString(6);
						ASSESSEDINCOME = new Integer(result.getInt(7)).toString();
						CARDTYPE = result.getString(8);
						generalstat = result.getString(9);
						DSR_MR.mLogger.debug("generalstat size" + generalstat);
						elitecustomerno = result.getString(10);
						DSR_MR.mLogger.debug("elitecustomerno size" + elitecustomerno);

						// iform.addItemInCombo("BTD_OBC_BN",value,value);
						iform.setValue("DCI_CName", value + " " + MiddleName + " " + LastName);
						iform.setValue("DCI_ExpD", ExpD);
						iform.setValue("DCI_ExpD", "Masked");
						iform.setValue("DCI_CCRNNo", CRNNO);
						iform.setValue("DCI_MONO", MOBILE);
						iform.setValue("DCI_ADCInc", ASSESSEDINCOME);
						iform.setValue("DCI_CT", CARDTYPE);
						iform.setValue("DCI_CAPS_GENSTAT", generalstat);
						iform.setValue("DCI_ELITECUSTNO", elitecustomerno);
						iform.setValue("DCI_CrdtCN", debit);
						strReturn = "Fetch Card Details successfully";
					}

									} else {
					strReturn = "Given Card Details is not Present";
				}

			} else {
				strReturn = "Invalid Crad Number format";
			}
			if (result != null) {
				result.close();
				result = null;
				DSR_MR.mLogger.debug("resultset Successfully closed");
			}
			if (stmt != null) {
				stmt.close();
				stmt = null;
				DSR_MR.mLogger.debug("Stmt Successfully closed");
			}
			if (conn != null) {
				conn.close();
				conn = null;
				DSR_MR.mLogger.debug("Conn Successfully closed");
			}
		}
		
		catch (java.sql.SQLException e) {
		DSR_MR.mLogger.debug(e.toString());
		if (e.getClass().toString().equalsIgnoreCase("Class javax.naming.NameNotFoundException"))
			DSR_MR.mLogger.debug("<script>alert(\"Data Source For CAPS System Not Found\")</script>");

		else if (e.toString().indexOf("Operation timed out: connect:could be due to invalid address") != -1)
			DSR_MR.mLogger.debug("<script>alert(\"Unable to connect to CAPS System\")</script>");

		else {
			DSR_MR.mLogger.debug("<script>alert(\"Unable to connect to CAPS System\")</script>");
		}

		}
		
		
		} 
		else if (controlName.equalsIgnoreCase("PrintButton")) {
			

			 Object localJSObject = "";
			 DSR_MR.mLogger.debug("Print Button inside");
			 DSR_MR.mLogger.debug("localJSObject ::"+localJSObject.toString());
			String str2 = "";
			String str3 = "";
			String str4 = "";
			str2 = ((String) iform.getValue("Cards_Remarks")).replace("&", "ampersand");
			str2 = str2.replace("=", "equalsopt");
			str2 = str2.replace("%", "percentageopt");
			//str3 = ((String) iform.getValue("BA_REMARKS")).replace("&", "ampersand");
			str3 = ((String) iform.getValue("BA_REMARKS")).replace("&", "ampersand");
            str3 = str3.replace("=", "equalsopt");
            str3 = str3.replace("%", "percentageopt");
			str4 = ((String) iform.getValue("REMARKS")).replace("&", "ampersand");
			str4 = str4.replace("=", "equalsopt");
			str4 = str4.replace("%", "percentageopt");
			DSR_MR.mLogger.debug("arrayOfString ::"+str2+ " "+ str3 + " "+str4);
			String[] arrayOfString = new String[1];
			 arrayOfString[0] = ("DCI_DebitCN=" +
			 ((String)iform.getValue("DCI_DebitCN")) + "&" + "DCI_CName="
			 + ((String)iform.getValue("DCI_CName")) + "&" + "DCI_ExpD="
			 + ((String)iform.getValue("DCI_ExpD")) + "&" + "DCI_CCRNNo="
			 + ((String)iform.getValue("DCI_CCRNNo")) + "&" + "DCI_ExtNo=" +
			 ((String)iform.getValue("DCI_ExtNo")) + "&" + "DCI_SC=" +
			 ((String)iform.getValue("DCI_SC")) + "&" + "DCI_MONO=" +
			 ((String)iform.getValue("DCI_MONO")) + "&" + "DCI_ADCInc=" +
			 ((String)iform.getValue("DCI_ADCInc")) + "&" + "DCI_CAPS_GENSTAT=" +
			 ((String)iform.getValue("DCI_CAPS_GENSTAT")) + "&" +
			 "DCI_ELITECUSTNO=" + ((String)iform.getValue("DCI_ELITECUSTNO")) + "&"
			 + "DCI_CT=" + ((String)iform.getValue("DCI_CT")) + "&" +
			 "VD_TINCheck=" + ((String)iform.getValue("VD_TINCheck")) + "&" +
			 "VD_MoMaidN=" + ((String)iform.getValue("VD_MoMaidN")) + "&" + "VD_DOB=" +
			 ((String)iform.getValue("VD_DOB")) + "&" + "VD_StaffId=" +
			 ((String)iform.getValue("VD_StaffId")) + "&" + "VD_PassNo=" +
			 ((String)iform.getValue("VD_PassNo")) + "&" + "VD_POBox=" +
			 ((String)iform.getValue("VD_POBox")) + "&" + "VD_Oth=" +
			 ((String)iform.getValue("VD_Oth")) + "&" + "VD_MRT=" +
			 ((String)iform.getValue("VD_MRT")) + "&" + "VD_EDC=" +
			 ((String)iform.getValue("VD_EDC")) + "&" + "VD_NOSC=" +
			 ((String)iform.getValue("VD_NOSC")) + "&" + "VD_TELNO=" +
			 ((String)iform.getValue("VD_TELNO")) + "&" + "VD_SD=" +
			 ((String)iform.getValue("VD_SD")) + "&" + "wi_name=" +
			 ((String)iform.getValue("wi_name")) + "&" + "processname=DSR_MR" + "&"
			 + "IntroductionDateTime=" + (String)iform.getValue("IntroductionDateTime") + "&"  
             + "BU_UserName=" + iform.getValue("IntroducedBy") + "&" 
			 + "Cards_Decision=" + ((String)iform.getValue("Cards_Decision")) + "&"
			 + "Cards_Remarks=" + str2 + "&"  + "BA_Decision=" + ((String)iform.getValue("BA_Decision")) + "&"
			 + "BA_Remarks=" + str3 + "&" + "REMARKS=" + str4);
			 DSR_MR.mLogger.debug("arrayOfString ::"+arrayOfString[0]);
			 localJSObject = arrayOfString[0];
			 DSR_MR.mLogger.debug("localJSObject ::"+localJSObject.toString());
			// ((JSObject) localJSObject).call("callPrintJSPDSRBT", arrayOfString);
			 DSR_MR.mLogger.debug("localJSObject ::"+localJSObject.toString());
			 strReturn = localJSObject.toString();
			 
			 
		}
		else if (controlName.equalsIgnoreCase("VD_TINCheck")) 
		{
			String msg = "";
			if (iform.getValue("VD_TINCheck").toString().equals("true")) {
				DSR_MR.mLogger.debug("VD_TINCheck ::");
				iform.setStyle("VD_MoMaidN", "disable", "false");
				iform.setStyle("VD_MoMaidN", "disable", "false");
				iform.setStyle("VD_POBox", "disable", "false");
				iform.setStyle("VD_TELNO", "disable", "false");
				iform.setStyle("VD_PassNo", "disable", "false");
				iform.setStyle("VD_MRT", "disable", "false");
				iform.setStyle("VD_Oth", "disable", "false");
				iform.setStyle("VD_SD", "disable", "false");
				iform.setStyle("VD_EDC", "disable", "false");
				iform.setStyle("VD_StaffId", "disable", "false");
				iform.setStyle("VD_DOB", "disable", "false");
				iform.setStyle("VD_NOSC", "disable", "false");
				msg= "tincheck is true.";
				
			}
			else if (iform.getValue("VD_TINCheck").toString().equals("false")) {
				//alert("inside VD_TINCheck");
				iform.setStyle("VD_MoMaidN", "disable", "true");
				iform.setStyle("VD_POBox", "disable", "true");
				iform.setStyle("VD_TELNO", "disable", "true");
				iform.setStyle("VD_PassNo", "disable", "true");
				iform.setStyle("VD_MRT", "disable", "true");
				iform.setStyle("VD_Oth", "disable", "true");
				iform.setStyle("VD_SD", "disable", "true");
				iform.setStyle("VD_EDC", "disable", "true");
				iform.setStyle("VD_StaffId", "disable", "true");
				iform.setStyle("VD_DOB", "disable", "true");
				iform.setStyle("VD_NOSC", "disable", "true");
				msg= "tincheck is false.";
			}
				
				
		}
	
		
	
	}
		catch(Exception exc)
		{
			DSR_MR.printException(exc);
			DSR_MR.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception 2 - "+exc);
		}
		return strReturn;
	}

	public String validateCCNo(String paramString1) {

		String str = paramString1.replaceAll("-", "");
		int[] arrayOfInt = new int[str.length()];
		int i = 0;
		int j = 0;
		for (i = 0; i < str.length(); i++) {
			arrayOfInt[i] = Integer.parseInt(str.charAt(i) + "");
		}
		for (i = arrayOfInt.length - 2; i >= 0; i -= 2) {
			arrayOfInt[i] *= 2;
			if (arrayOfInt[i] > 9) {
				arrayOfInt[i] -= 9;
			}
		}
		for (i = 0; i < arrayOfInt.length; i++) {
			j += arrayOfInt[i];
		}

		if (j % 10 == 0) {
			return "ValidCard";
		}

		return "Invalid debit Card No. Format";
	}
	
	public void setFormDetail(IFormReference iform) {
		//((Object) iform).setControlValue("","");
		 DSR_MR.mLogger.debug("setFormDetail inside method=====");
	    if (!iform.getValue("DCI_CName").equals(""))
	      try
	      {
	        String str1 = (String) iform.getValue("cardDetails");
	        if (!str1.equals("")) {
	          CAPDataHT.clear();
	          int i = 0;
	          int j = 0;
	          int k = str1.indexOf("!");
	          int m = 0;
	          String str2 = "";
	          String str3 = "";
	          String str4 = "";
	          j = Integer.parseInt(str1.substring(0, str1.indexOf("@")));
	          str1 = str1.substring(str1.indexOf("@") + 1, str1.length());
	          for (m = 1; m <= j; m++)
	          {
	            if (m == 1)
	            {
	              i = -1;
	              k = str1.indexOf("!");
	            }
	            else
	            {
	              i = k;
	              k = str1.indexOf("!", i + 1);
	            }
	            DSR_MR.mLogger.debug("saaa=======" + k);
	            str2 = str1.substring(i + 1, k);

	            CAPDataHT.put("RAKBankCard" + m, str2);
	            DSR_MR.mLogger.debug("RAKBankCard" + m + "----" + str2);
	            i = k;
	            k = str1.indexOf("!", i + 1);
	            str3 = str1.substring(i + 1, k);
	            CAPDataHT.put("CardType" + m, str3);
	            DSR_MR.mLogger.debug("CardType" + m + "-----" + str3);
	            i = k;
	            k = str1.indexOf("!", i + 1);
	            str4 = str1.substring(i + 1, k);
	            CAPDataHT.put("ExpDate" + m, str4);
	            DSR_MR.mLogger.debug("ExpDate" + m + "---" + str4);
	          }

	          String str5 = (String) iform.getValue("BTD_RBC_RBCN1");
	          String str6 = (String) iform.getValue("BTD_RBC_RBCN2");
	          String str7 = (String) iform.getValue("BTD_RBC_RBCN3");
	          iform.clearCombo("BTD_RBC_RBCN1");
	          iform.clearCombo("BTD_RBC_RBCN2");
	          iform.clearCombo("BTD_RBC_RBCN3");
	          for (m = 1; m <= j; m++)
	          {
	        	 iform.addItemInCombo("BTD_RBC_RBCN1", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
	        	 iform.addItemInCombo("BTD_RBC_RBCN2", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
	        	 iform.addItemInCombo("BTD_RBC_RBCN3", CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(0, 4) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(4, 8) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(8, 12) + "-" + CAPDataHT.get(new StringBuilder().append("RAKBankCard").append(m).toString()).toString().substring(12, 16));
	          }
	          if (!str5.equals(""))
	        	  iform.setValue("BTD_RBC_RBCN1", str5.substring(0, 4) + "-" + str5.substring(4, 8) + "-" + str5.substring(8, 12) + "-" + str5.substring(12, 16));
	          else
	        	  iform.setValue("BTD_RBC_RBCN1", "");
	          if (!str6.equals(""))
	        	  iform.setValue("BTD_RBC_RBCN2", str6.substring(0, 4) + "-" + str6.substring(4, 8) + "-" + str6.substring(8, 12) + "-" + str6.substring(12, 16));
	           else
	        	   iform.setValue("BTD_RBC_RBCN2", "");
	           if (!str7.equals(""))
	        	   iform.setValue("BTD_RBC_RBCN3", str7.substring(0, 4) + "-" + str7.substring(4, 8) + "-" + str7.substring(8, 12) + "-" + str7.substring(12, 16));
	           else
	        	   iform.setValue("BTD_RBC_RBCN3", "");
	           DSR_MR.mLogger.debug("tetet443434etew==4545663-");
	         }
	 
	         //lockCAPSFrm();
	       } catch (Exception localException) {
	         DSR_MR.mLogger.debug("card exception at form load==" + localException.toString());
	       }
	   }

	

}
