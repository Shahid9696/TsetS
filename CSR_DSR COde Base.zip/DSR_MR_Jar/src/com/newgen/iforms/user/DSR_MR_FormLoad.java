package com.newgen.iforms.user;

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

public class DSR_MR_FormLoad extends DSR_MRCommon
{
	public String formLoadEvent(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn=""; 
	
		DSR_MR.mLogger.debug("This is DSR_MR_FormLoad_Event"+event+" controlName :"+controlName);
		
		//DSR_OCC.mLogger.debug("SELECT DECISION FROM USR_0_DSR_OCC_DECISION_MASTER WHERE WORKSTEP_NAME= '"+iform.getActivityName()"' and ISACTIVE='Y'");
				
		if (controlName.equalsIgnoreCase("BranchName") && event.equalsIgnoreCase("FormLoad") )
		{
			String actname = iform.getActivityName();
			//DSR_OCC.mLogger.debug(actname);
			List lstDecisions = iform.getDataFromDB("select BRANCHNAME,branchid from rb_branch_details");
			
			String value="";
			
			DSR_MR.mLogger.debug(lstDecisions);
			
			 iform.clearCombo("BTD_OBC_BN");
			
			for(int i=0;i<lstDecisions.size();i++)
			 {
				List<String> arr1=(List)lstDecisions.get(i);
				value=arr1.get(0);
				iform.addItemInCombo("BTD_OBC_BN",value,value);
				strReturn="Brnach vakue loaded";
			 }		
		}
		
			
		else if("DuplicateWI".equals(controlName))
		{
			try {
				DSR_MR.mLogger.debug("Duplicate WIs");
				DSR_MR.mLogger.debug("WI Name duplicate is "+getWorkitemName());
				DSR_MR.mLogger.debug("CIF id is "+iform.getValue("CIF_ID"));
				String strQuery="SELECT WI_NAME,CREATED_TIME, CREATED_BY, SOL_ID  FROM RB_DSR_OCC_EXTTABLE WHERE CIF_ID='"+iform.getValue("CIF_ID")+"' AND WI_NAME NOT IN ('"+getWorkitemName()+"')";
				List<List<String>> lstDuplicateWIs = iform.getDataFromDB(strQuery);
				
				DSR_MR.mLogger.debug("strQuery "+strQuery);
				JSONArray jsonArray=new JSONArray();
				String value="";
				DSR_MR.mLogger.debug("lstDuplicateWIs.size() "+lstDuplicateWIs.size());
				for(int i=0;i<lstDuplicateWIs.size();i++)
				{
					//PC.mLogger.debug(" "+memoPad);
					JSONObject obj=new JSONObject();
					List<String> arr=(List)lstDuplicateWIs.get(i);
					value=arr.get(0);
					DSR_MR.mLogger.debug("WI is "+value);
					obj.put("Work-Item Number", value);
					value=arr.get(1);
					//DSR_OCC.mLogger.debug("Date format Sajan "+value);
					//Date date1= new SimpleDateFormat("EE dd/MMM/yyyy HH:mm:ss",Locale.ENGLISH).parse(value);
					Date date1= new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss").parse(value);
					DSR_MR.mLogger.debug("date1 "+date1);
					SimpleDateFormat sdf1=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
					DSR_MR.mLogger.debug("Initiated date is "+sdf1.format(date1).toString());
					
					value=sdf1.format(date1).toString();
					obj.put("Initiated Date", value);
					value=arr.get(2);
					DSR_MR.mLogger.debug("Initiated by is "+value);
					obj.put("Initiated By", value);
					value=arr.get(3);
					DSR_MR.mLogger.debug("Sol id is "+value);
					obj.put("Sol Id", value);
					jsonArray.add(obj);
				}
				DSR_MR.mLogger.debug("JSON array is "+jsonArray.toString());
				iform.addDataToGrid("Q_USR_0_DSR_OCC_DUPLICATE_WI", jsonArray);
				strReturn=strReturn+lstDuplicateWIs.size();
			} catch (Exception e) {
				DSR_MR.mLogger.debug("Exception in Duplicate WorkItem" + e.getMessage());
			}
		}
		
		return strReturn;
	}
	
}
