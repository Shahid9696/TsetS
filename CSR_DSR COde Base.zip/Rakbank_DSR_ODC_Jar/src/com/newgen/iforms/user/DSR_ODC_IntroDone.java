package com.newgen.iforms.user;

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

public class DSR_ODC_IntroDone extends DSR_ODCCommon
{
	public String onIntroduceDone(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn="";
		DSR_ODC.mLogger.debug("This is DSR_ODC_IntroDone_Event");
		if("InsertIntoHistory".equals(controlName))
		{
			try {
				DSR_ODC.mLogger.debug("Reject Reasons Grid Length is "+data);
				String strRejectReasons="";
				for(int p=0;p<Integer.parseInt(data);p++)
				{
					if(strRejectReasons=="")	
						strRejectReasons=iform.getTableCellValue("REJECT_REASON_GRID",p,0);
					else
						strRejectReasons=strRejectReasons+"#"+iform.getTableCellValue("REJECT_REASON_GRID",p,0);
				}
				
				DSR_ODC.mLogger.debug("Final reject reasons are "+strRejectReasons);
				JSONArray jsonArray=new JSONArray();
				JSONObject obj=new JSONObject();
				Calendar cal = Calendar.getInstance();
			   // SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");			   
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:MM:ss");
			    String strDate = sdf.format(cal.getTime());
			    
				obj.put("Date Time",strDate);
				obj.put("Workstep",iform.getActivityName());
				obj.put("User Name", iform.getUserName());
				obj.put("Decision",iform.getValue("q_Decision"));
				obj.put("Reject Reasons", strRejectReasons);
				obj.put("Remarks", iform.getValue("REMARKS"));
				
			
				DSR_ODC.mLogger.debug("Decision" +iform.getValue("q_Decision"));
				
				if("Introduction".equalsIgnoreCase(iform.getActivityName()))
					obj.put("Entry Date Time",iform.getValue("CreatedDateTime"));
				else
					obj.put("Entry Date Time",iform.getValue("EntryDateTime"));
				jsonArray.add(obj);
				iform.addDataToGrid("Q_USR_0_DSR_ODC_WIHISTORY", jsonArray);
				
				DSR_ODC.mLogger.debug("Created Date Time"+iform.getValue("CreatedDateTime"));
				DSR_ODC.mLogger.debug("Entry Date Time"+iform.getValue("EntryDateTime"));
			
				
			} catch (Exception e) {
				DSR_ODC.mLogger.debug("Exception in check if system Check Required non borrowing" + e.getMessage());
			}
		}
		return strReturn;
	}
	public String triggerMailSMS(IFormReference iform, String controlName,String event, String data) {
		try {
			DSR_ODC.mLogger.debug("Inside triggerMailSms");
			String activityName = iform.getActivityName();
			DSR_ODC.mLogger.debug("activityName---------->"+activityName);
		//for mail/sms trigger, added by Mirza 02-05-23
		String stage = "";
		DSR_ODC.mLogger.debug("Setting stage");
		if (iform.getActivityName().equalsIgnoreCase("Introduction"))
		{
			String Decision = (String) iform.getValue("Decision");
			if (Decision.equalsIgnoreCase("Introduce"))
				stage = "Introduction";
			else if (Decision.equalsIgnoreCase("Pending"))
				stage = "Pending";
		}
		/*else if (iform.getActivityName().equalsIgnoreCase("Branch_Approver")) {
			String Decision = (String) iform.getValue("BA_Decision");
			DSR_ODC.mLogger.debug("Decision------->"+Decision);
			 if (Decision.equalsIgnoreCase("BA_D")) {
				stage = "RejectFinalDiscard";
			 DSR_ODC.mLogger.debug("stage----->"+stage);
			 }
		}*/
		else if (iform.getActivityName().equalsIgnoreCase("CARDS")){
			String Decision = (String) iform.getValue("Cards_Decision");
			DSR_ODC.mLogger.debug("Decision----->"+Decision);
			if (Decision.equals("CARDS_BR")) {
				stage = "RejectRTS";
			 DSR_ODC.mLogger.debug("stage----->"+stage);
			 }
			else if (Decision.equalsIgnoreCase("CARDS_D")) {
				stage = "RejectFinalDiscard";
				DSR_ODC.mLogger.debug("stage----->"+stage);
			}
			else if (Decision.equalsIgnoreCase("CARDS_E")) {
				String subProcessName = (String)iform.getValue("request_type");
				DSR_ODC.mLogger.debug("subProcessName----->"+subProcessName);
				if(subProcessName.equalsIgnoreCase("Card Replacement") || subProcessName.equalsIgnoreCase("Early Card Renewal") || subProcessName.equalsIgnoreCase("Card Delivery Request"))
				{
					String SRO = (String)iform.getValue("Cards_SRONo");
					if(SRO.equalsIgnoreCase(null) || SRO.equalsIgnoreCase("") || SRO.equalsIgnoreCase("NULL")) 
					{
						stage = "Completed";
						DSR_ODC.mLogger.debug("stage----->"+stage);	
					}
					else 
					{
						DSR_ODC.mLogger.debug("SRO TO BE RAISED");
					}
				}
				else if(!(subProcessName.equalsIgnoreCase("Card Replacement") || subProcessName.equalsIgnoreCase("Early Card Renewal") || subProcessName.equalsIgnoreCase("Card Delivery Request")))
				{
					stage = "Completed";
					DSR_ODC.mLogger.debug("stage----->"+stage);
				}
			}
		}
		else if(iform.getActivityName().equalsIgnoreCase("Pending")) {
			String Decision = (String) iform.getValue("Pending_Decision");
			DSR_ODC.mLogger.debug("Decision----->"+Decision);
			if (Decision.equalsIgnoreCase("P_Discard")) {
				stage = "PendingCancel";
			 DSR_ODC.mLogger.debug("stage----->"+stage);
			}
		}
		else if(iform.getActivityName().equalsIgnoreCase("Branch_Return")) {
			String Decision = (String) iform.getValue("BR_Decision");
			if (Decision.equalsIgnoreCase("Discard")) 
			{
			stage = "RejectFinalDiscard";
			DSR_ODC.mLogger.debug("stage----->"+stage);
			}
		}
		if(stage!="")
		{
			String mailRes = DSR_ODC_Email.mailTrigger(iform, stage, data);
			String SMSRes = DSR_ODC_Email.sendSMS(iform, stage, data);
			DSR_ODC.mLogger.debug("MailResponse------>"+mailRes+"SMSResponse----->"+SMSRes);
			if(mailRes.equalsIgnoreCase("true") || SMSRes.equalsIgnoreCase("true")) {
				DSR_ODC.mLogger.debug("Mail/SMS Triggered");
				return "True-MailSms Triggered successfully";
				}
			}
		else
			return "stage not found";
		}catch (Exception e) {
			DSR_ODC.mLogger.debug("Exception in mailSMS trigger" + e.getMessage());
		}
		return "False-Some error in triggering MailSMS Service";
	}
	//end
}