package com.newgen.iforms.user;


import java.util.List;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.omni.jts.cmgr.XMLParser;

public class DSR_ODC_Click {

	public String clickEvent(IFormReference iform, String controlName, String data)
	{
		String strReturn = ""; 
        DSR_ODC.mLogger.debug("inside CSR_ODC_click,controlName: "+controlName);
         if(controlName.equals("CAPSMAIN_Query"))
             return new DSR_ODCIntegration().onclickevent(iform, controlName, data);
         else if(controlName.equals("PrintButton"))
             return new DSR_ODCIntegration().onclickevent(iform, controlName, data);
         else if (controlName.equalsIgnoreCase("RaiseSRO"))
            {
        	    String Query = "select processdefid from processdeftable where processname = 'SRO'";
				List<List<String>> Query_data = iform.getDataFromDB(Query);
				String processDEFID = Query_data.get(0).get(0);
				DSR_ODC.mLogger.debug("CustMail----------->" + processDEFID);
				String processDefIdSRO = processDEFID;
                String paramForSRO = data;
                DSR_ODC.mLogger.debug("paramForSRO : "+paramForSRO);
                String attributeTagSRO = ""; 
                String wfuploadInputXMLSRO = ""; 
                String wfuploadOutputXMLSRO = ""; 
                String WINumberSRO = "";
                attributeTagSRO = attributeTagSRO + "Service_Request_Type" + (char)21 +paramForSRO.split("~")[0]+(char)25;
                attributeTagSRO = attributeTagSRO + "Team" + (char)21 +paramForSRO.split("~")[1]+(char)25;
                attributeTagSRO = attributeTagSRO + "Remarks" + (char)21 +paramForSRO.split("~")[2]+(char)25;

                wfuploadInputXMLSRO = DSR_ODCCommon.getWFUploadWorkItemXML(iform, processDefIdSRO, attributeTagSRO);
                DSR_ODC.mLogger.debug("wfuploadInputXMLSRO : "+wfuploadInputXMLSRO);
                wfuploadOutputXMLSRO = DSR_ODCCommon.ExecuteQueryOnServer(iform,wfuploadInputXMLSRO);
                DSR_ODC.mLogger.debug("wfuploadOutputXMLSRO : "+wfuploadOutputXMLSRO);
                if(wfuploadOutputXMLSRO.indexOf("<MainCode>0</MainCode>")>-1){
                    DSR_ODC.mLogger.debug("WFUpload for SRO is successfull");
                    DSR_ODC.mLogger.debug("WFUpload for SRO is successfull 2");
                    XMLParser xmlobj = new XMLParser(wfuploadOutputXMLSRO);
                    WINumberSRO = xmlobj.getValueOf("ProcessInstanceId");
                    DSR_ODC.mLogger.debug("WINumberSRO : "+WINumberSRO);
                    strReturn = WINumberSRO+"~"+"WI Created";
                }else {
                    DSR_ODC.mLogger.debug("WFUpload for SRB is failed");
                    strReturn = WINumberSRO+"~"+"WI Not Created";
                }
            }
         else
             return "";    

         DSR_ODC.mLogger.debug("strReturn for SRO raised : "+strReturn);
         return strReturn;
    	
	}
}
