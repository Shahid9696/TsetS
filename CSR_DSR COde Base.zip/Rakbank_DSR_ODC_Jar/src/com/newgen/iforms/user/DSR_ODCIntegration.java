package com.newgen.iforms.user;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.mvcbeans.model.wfobjects.WDGeneralData;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Iterator;
import java.util.Map.Entry;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;

import netscape.javascript.JSObject;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.CharacterData;
	
	public class DSR_ODCIntegration extends DSR_ODCCommon 
	{		
		LinkedHashMap<String,String> executeXMLMapMain = new LinkedHashMap<String,String>();
		public static String XMLLOG_HISTORY="NG_DSR_ODC_XMLLOG_HISTORY";

	public String onclickevent(IFormReference iformObj,String control,String StringData)
	{
		String MQ_response="";
		String MQ_response_Entity ="";
		String strReturn="false";
		HashMap CAPDataHT = new HashMap();
		
		try
		{
			DSR_ODC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Inside onclickevent function");
			if(control.equals("CAPSMAIN_Query"))
			{
				String str1 = "Select LTRIM(RTRIM(FirstName)), LTRIM(RTRIM(MiddleName)), LTRIM(RTRIM(LastName)), substring(format(EXPIRYDATE,'dd/mm/yy'),4,LEN(format(EXPIRYDATE,'dd/mm/yy'))), CRNNO, MOBILE,ASSESSEDINCOME,CARDTYPE,generalstat,elitecustomerno  from rak_bpm.dbo.CAPSMAIN where  CREDITCARDNO='" + iformObj.getValue("CardNo_Text").toString().replaceAll("-", "") + "'";
				String str3 = "";
				String str4 = "";
				String str5 = "";
				String str6 = "";
				String str7 = "";
				String str8 = "";
				String str9 = "";
				String str10 = "";
				String str11 = "";
				String str12 = "";
				DSR_ODC.mLogger.debug("str1 :"+str1);
				List lstDecisions = iformObj.getDataFromDB(str1);
				DSR_ODC.mLogger.debug("lstDecisions :"+lstDecisions);
				if (lstDecisions != null)
				{
					for(int i=0;i<lstDecisions.size();i++)
					{
						DSR_ODC.mLogger.debug(" loop i :"+i);
						List<String> arr1=(List)lstDecisions.get(i);
						str3=arr1.get(0);
						str4=arr1.get(1);
						str5=arr1.get(2);
						str6=arr1.get(3);
						str7=arr1.get(4);
						str8=arr1.get(5);
						str9=arr1.get(6);
						str10=arr1.get(7);
						str11=arr1.get(8);
						str12=arr1.get(9);
					}

					setControlValue("DCI_CName", str3 + " " + str4 + " " + str5);
					setControlValue("DCI_ExpD", str6);
					setControlValue("DCI_ExpD", "Masked");
					//setControlValue("DCI_CCRNNo", str7);
					setControlValue("DCI_MONO", str8);
					//setControlValue("CCI_AccInc", str9);
					setControlValue("DCI_CT", str10);
					setControlValue("DCI_CAPS_GENSTAT", str11);
					setControlValue("DCI_ELITECUSTNO", str12);
					strReturn="Data Loaded";
				}					
			}	
			else if(control.equals("PrintButton"))
			{
				DSR_ODC.mLogger.debug("inside Print_Button :");
				
				

				 Object localJSObject = "";
				 DSR_ODC.mLogger.debug("Print Button inside");
				 DSR_ODC.mLogger.debug("localJSObject ::"+localJSObject.toString());
				String str2 = "";
				String str3 = "";
				String str4 = "";
				String str5 = "";
				str2 = ((String) iformObj.getValue("Cards_Remarks")).replace("&", "ampersand");
				str2 = str2.replace("=", "equalsopt");
				str2 = str2.replace("%", "percentageopt");
				str3 = ((String) iformObj.getValue("BA_Remarks")).replace("&", "ampersand");
				str3 = str3.replace("=", "equalsopt");
				str3 = str3.replace("%", "percentageopt");
	            str4 = ((String) iformObj.getValue("REMARKS")).replace("&", "ampersand");
				str4 = str4.replace("=", "equalsopt");
				str4 = str4.replace("%", "percentageopt");
				
				str5 = ((String) iformObj.getValue("BR_Remarks")).replace("&", "ampersand");
				str5 = str5.replace("=", "equalsopt");
				str5 = str5.replace("%", "percentageopt");
				
				DSR_ODC.mLogger.debug("arrayOfString ::"+str2+ " "+ str3 + " "+str4);
				String[] arrayOfString = new String[1];
				 arrayOfString[0] = ("DCI_DebitCN=" +
				 ((String)iformObj.getValue("DCI_DebitCN")) + "&" + "DCI_CName="
				 + ((String)iformObj.getValue("DCI_CName")) + "&" + "DCI_ExpD="
				 + ((String)iformObj.getValue("DCI_ExpD")) + "&" + "DCI_CCRNNo="
				 + ((String)iformObj.getValue("DCI_CCRNNo")) + "&" + "DCI_ExtNo=" +
				 ((String)iformObj.getValue("DCI_ExtNo")) + "&" + "DCI_SC=" +
				 ((String)iformObj.getValue("DCI_SC")) + "&" + "DCI_MONO=" +
				 ((String)iformObj.getValue("DCI_MONO")) + "&" + "DCI_AccInc=" +
				 ((String)iformObj.getValue("DCI_AccInc")) + "&" + "DCI_CAPS_GENSTAT=" +
				 ((String)iformObj.getValue("DCI_CAPS_GENSTAT")) + "&" +
				 "DCI_ELITECUSTNO=" + ((String)iformObj.getValue("DCI_ELITECUSTNO")) + "&"
				 + "DCI_CT=" + ((String)iformObj.getValue("DCI_CT")) + "&" +
				 "VD_TINCheck=" + ((String)iformObj.getValue("VD_TINCheck")) + "&" +
				 "VD_MoMaidN=" + ((String)iformObj.getValue("VD_MoMaidN")) + "&" + "VD_DOB=" +
				 ((String)iformObj.getValue("VD_DOB")) + "&" + "VD_StaffId=" +
				 ((String)iformObj.getValue("VD_StaffId")) + "&" + "VD_PassNo=" +
				 ((String)iformObj.getValue("VD_PassNo")) + "&" + "VD_POBox=" +
				 ((String)iformObj.getValue("VD_POBox")) + "&" + "VD_Oth=" +
				 ((String)iformObj.getValue("VD_Oth")) + "&" + "VD_MRT=" +
				 ((String)iformObj.getValue("VD_MRT")) + "&" + "VD_EDC=" +
				 ((String)iformObj.getValue("VD_EDC")) + "&" + "VD_NOSC=" +
				 ((String)iformObj.getValue("VD_NOSC")) + "&" + "VD_TELNO=" +
				 ((String)iformObj.getValue("VD_TELNO")) + "&" + "VD_SD=" +
				 ((String)iformObj.getValue("VD_SD")) + "&" + "REASON_HOTLIST="+
	                         ((String)iformObj.getValue("REASON_HOTLIST")) + "&" + "HOST_OTHER="+ 
				 ((String)iformObj.getValue("HOST_OTHER")) + "&" + "EMAIL_FROM="+
				 ((String)iformObj.getValue("EMAIL_FROM")) + "&" + "EMBOSING_NAME="+
				 ((String)iformObj.getValue("EMBOSING_NAME")) + "&" + "CB_DATETIME="+
				 ((String)iformObj.getValue("CB_DATETIME")) + "&" + "PLACE="+
				 ((String)iformObj.getValue("PLACE")) + "&" + "AVAILABLE_BALANCE="+
				 ((String)iformObj.getValue("AVAILABLE_BALANCE")) + "&" + "C_STATUS_B_BLOCK="+
				 ((String)iformObj.getValue("C_STATUS_B_BLOCK")) + "&" + "C_STATUS_A_BLOCK="+
				 ((String)iformObj.getValue("C_STATUS_A_BLOCK")) + "&" + "ACTION_TAKEN="+
				 ((String)iformObj.getValue("ACTION_TAKEN")) + "&" + "ACTION_OTHER="+
				 ((String)iformObj.getValue("ACTION_OTHER")) + "&" + "DELIVER_TO="+
				 ((String)iformObj.getValue("DELIVER_TO")) + "&" + "BRANCH="+
				 ((String)iformObj.getValue("BRANCH")) + "&" + "BRANCH_NAME="+
				 ((String)iformObj.getValue("BRANCH_NAME")) + "&" + "wi_name=" +
				 ((String)iformObj.getValue("wi_name")) + "&" + "processname=DSR_ODC" + "&"
				 + "IntroductionDateTime=" + (String)iformObj.getValue("CreatedDateTime") + "&"  
	                         + "BU_UserName=" + iformObj.getValue("IntroducedBy") + "&" 
				 + "Cards_Decision=" + ((String)iformObj.getValue("Cards_Decision")) + "&" 
				 + "Cards_Remarks=" + str2 + "&" 
	                         + "BA_Decision=" + ((String)iformObj.getValue("BA_Decision")) + "&"
				 + "BA_Remarks=" + str3 + "&" + "REMARKS=" + str4
				 + "&"
				 + "Re_Issue_of_PIN=" + (String)iformObj.getValue("request_type") + "&" + "Card_Replacement=" + (String)iformObj.getValue("request_type")
				 + "&"
				 + "Early_Card_Renewal=" + (String)iformObj.getValue("request_type") + "&" + "Transaction_Dispute=" + (String)iformObj.getValue("request_type")
				 + "&"
				 + "Card_Delivery_Request=" + (String)iformObj.getValue("request_type") + "&" + "oth_cdr_CDT=" + (String)iformObj.getValue("oth_cdr_CDT")
				 + "&"
				 + "oth_cdr_BN=" + (String)iformObj.getValue("CDR_BRANCH") + "&" + "oth_cdr_RR=" + (String)iformObj.getValue("oth_cdr_RR")
				 + "&"
				 + "oth_td_RNO=" + (String)iformObj.getValue("oth_td_RNO") + "&" + "oth_td_Amount=" + (String)iformObj.getValue("oth_td_Amount")
				 + "&"
				 + "oth_td_RR=" + (String)iformObj.getValue("oth_td_RR") + "&" + "oth_ecr_RB=" + (String)iformObj.getValue("oth_ecr_RB")
				 + "&"
				 + "oth_ecr_dt=" + (String)iformObj.getValue("oth_ecr_dt") + "&" + "oth_ecr_bn=" + (String)iformObj.getValue("ECR_BRANCH")
				 + "&"
				 + "oth_ecr_RR=" + (String)iformObj.getValue("oth_ecr_RR") + "&" + "oth_cr_reason=" + (String)iformObj.getValue("oth_cr_reason")
				 + "&"
				 + "oth_cr_OPS=" + (String)iformObj.getValue("oth_cr_OPS") + "&" + "oth_cr_DC=" + (String)iformObj.getValue("oth_cr_DC")
				 + "&"
				 + "oth_cr_BN=" + (String)iformObj.getValue("CR_BRANCH") + "&" + "oth_cr_RR=" + (String)iformObj.getValue("oth_cr_RR")
				 + "&"
				 + "oth_rip_reason=" + (String)iformObj.getValue("oth_rip_reason") + "&" + "oth_rip_DC=" + (String)iformObj.getValue("oth_rip_DC")
				 + "&"
				 + "oth_rip_BN=" + (String)iformObj.getValue("RIP_BRANCH") + "&" + "oth_rip_RR=" + (String)iformObj.getValue("oth_rip_RR")
				 + "&" + "BR_Remarks=" + str5);
				 DSR_ODC.mLogger.debug("arrayOfString ::"+arrayOfString[0]);
				 localJSObject = arrayOfString[0];
				 DSR_ODC.mLogger.debug("localJSObject ::"+localJSObject.toString());
				// ((JSObject) localJSObject).call("callPrintJSPCSRBT", arrayOfString);
				 DSR_ODC.mLogger.debug("localJSObject ::"+localJSObject.toString());
				 strReturn = localJSObject.toString();
				 
			}			
		}		
		catch(Exception exc)
		{
			DSR_ODC.printException(exc);
			DSR_ODC.mLogger.debug("WINAME : "+getWorkitemName()+", WSNAME: "+getActivityName()+", Exception 2 - "+exc);
		}	
		return strReturn;
	}
	
	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
		   CharacterData cd = (CharacterData) child;
		   return cd.getData();
		}
		return "NO_DATA";
	}
	
	
}


